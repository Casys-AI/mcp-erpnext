/**
 * Pure Preact presentation primitives for native applications and MCP Apps.
 *
 * Unlike `@mcpview/components/preact`, this entry point does not import the MCP
 * Apps lifecycle, iframe transport, surface registry, or postMessage bridge.
 *
 * Import as `@mcpview/components/preact/components`.
 *
 * @module
 */
import "./_dnt.polyfills.js";
export { Badge, BadgeGroup, Button, Card, CodeBlock, CrossSelection, DataTable, EmptyState, InlineCode, KeyValueList, Message, Metric, MetricGrid, NoticeGroup, renderStatusMessage, Row, Skeleton, Stack, StateMessage, TextInput, Toolbar, } from "./src/preact/components.js";
export type { BadgeGroupProps, BadgeProps, ButtonProps, CardProps, CodeBlockProps, CrossSelectionProps, DataTableColumn, DataTableDisclosure, DataTableProps, EmptyStateProps, InlineCodeProps, KeyValueItem, KeyValueLayout, KeyValueListProps, MessageProps, MetricGridProps, MetricItem, MetricProps, NoticeGroupProps, PresentationTone, RowProps, SkeletonProps, StackProps, StateMessageProps, StatusMessageMount, TextInputProps, ToolbarProps, } from "./src/preact/components.js";
export { ArtifactRow, DrillHint, LimitGauge, PATH_BAR_DEFAULT_MAX_VISIBLE, PathBar, Slot3D, StaleBanner, TreeList, TypeBadge, } from "./src/preact/structural.js";
export type { ArtifactFingerprint, ArtifactRowProps, ArtifactVerification, DrillHintDirection, DrillHintProps, LimitGaugeLimit, LimitGaugeProps, PathBarItem, PathBarProps, Slot3DProps, StaleBannerAction, StaleBannerProps, TreeListNode, TreeListProps, TypeBadgeProps, ViewKind, } from "./src/preact/structural.js";
export { IntervalPlot, SeriesChart, Sparkline } from "./src/preact/plots.js";
export type { IntervalPlotInterval, IntervalPlotProps, SeriesChartCursor, SeriesChartProps, SeriesChartReadout, SeriesChartSeries, SeriesChartSummaryItem, SeriesChartTone, SeriesPoint, SparklineProps, } from "./src/preact/plots.js";
export { CollectionCard, ElementBody, ElementIdent, ElementLimit, ElementProvenance, ElementReading, ElementSection, ElementVerdict, SemanticElement, SemanticList, } from "./src/preact/semantic-element.js";
export type { CollectionCardProps, ElementBodyProps, ElementIdentProps, ElementLimitProps, ElementProvenanceProps, ElementReadingProps, ElementSectionProps, ElementVerdictProps, SemanticElementDensity, SemanticElementProps, SemanticListProps, } from "./src/preact/semantic-element.js";
export { Disclosure, FocusedView } from "./src/preact/focused-view.js";
export type { DisclosureProps, FocusedViewProps } from "./src/preact/focused-view.js";
export { SnippetLibrary } from "./src/preact/snippet-library.js";
export type { SnippetLibraryEntry, SnippetLibraryLabels, SnippetLibraryProps, SnippetLibrarySource, } from "./src/preact/snippet-library.js";
//# sourceMappingURL=preact-components.d.ts.map