/** Lightweight Preact controls for drill-down and context pinning. @module */
import "./_dnt.polyfills.js";
export { ContextPinButton, DisclosureChevron } from "./src/preact/interaction-controls.js";
export type { ContextPinButtonProps, DisclosureChevronProps, } from "./src/preact/interaction-controls.js";
export { installMcpViewInteractionStyles, MCP_VIEW_INTERACTION_CSS, } from "./src/interaction-styles.js";
//# sourceMappingURL=preact-controls.d.ts.map