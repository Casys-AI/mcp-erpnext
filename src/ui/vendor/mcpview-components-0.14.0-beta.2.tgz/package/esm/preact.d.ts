/**
 * Preact integration for componentized `@mcpview/components` Apps.
 *
 * Import as `@mcpview/components/preact`.
 *
 * @module
 */
import "./_dnt.polyfills.js";
export * from "./src/preact/mod.js";
//# sourceMappingURL=preact.d.ts.map