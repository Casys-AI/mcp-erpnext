/** Small, framework-neutral UI components reusable across MCP Apps. */
import { defineViewComponent, type ViewComponentDefinition, type ViewComponentEventPorts, type ViewComponentMountContext } from "./components.js";
export type ComponentTone = "neutral" | "info" | "success" | "warning" | "danger";
export interface StatusComponentValue {
    readonly label: string;
    readonly detail?: string;
    readonly tone?: ComponentTone;
}
export interface MetricComponentValue {
    readonly id: string;
    readonly label: string;
    readonly value: string | number;
    readonly unit?: string;
    readonly detail?: string;
}
export interface KeyValueComponentValue {
    readonly key: string;
    readonly label: string;
    readonly value: string | number | boolean | null;
}
interface PrimitiveConfig<TData, TValue> {
    readonly title: string;
    readonly description?: string;
    readonly events?: ViewComponentEventPorts;
    readonly select: (data: TData) => TValue;
}
/** One compact status block with a semantic tone and optional detail. */
export declare function defineStatusComponent<TData, TAppContext = unknown>(config: PrimitiveConfig<TData, StatusComponentValue>): ViewComponentDefinition<TData, TAppContext>;
/** Responsive metric cards; formatting remains owned by the domain selector. */
export declare function defineMetricGridComponent<TData, TAppContext = unknown>(config: PrimitiveConfig<TData, readonly MetricComponentValue[]>): ViewComponentDefinition<TData, TAppContext>;
/** Semantic definition list for provenance, identity, and other compact facts. */
export declare function defineKeyValueComponent<TData, TAppContext = unknown>(config: PrimitiveConfig<TData, readonly KeyValueComponentValue[]>): ViewComponentDefinition<TData, TAppContext>;
/** A custom component factory with the same descriptor convention as primitives. */
export declare function defineCustomComponent<TData, TAppContext = unknown>(config: {
    readonly title: string;
    readonly description?: string;
    readonly events?: ViewComponentEventPorts;
    readonly mount: (target: HTMLElement, context: ViewComponentMountContext<TData, TAppContext>) => ReturnType<ReturnType<typeof defineViewComponent<TData, TAppContext>>["mount"]>;
}): ViewComponentDefinition<TData, TAppContext>;
export {};
//# sourceMappingURL=component-primitives.d.ts.map