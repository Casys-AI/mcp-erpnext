/** Renderer-neutral component catalog and surface runtime for MCP Apps. */
import type { AppContext } from "@mcpview/view";
import { type AdvertisedComponentCatalog, type ComponentSurface, type JsonValue, type ViewComponentDescriptor } from "@mcpview/contracts";
export { CASYS_COMPONENT_CATALOG_CAPABILITY_KEY, CASYS_SURFACE_CONTEXT_KEY, readSurfaceContext, } from "@mcpview/contracts";
export type { AdvertisedComponentCatalog, ComponentSurface, ComponentSurfaceItem, ComponentSurfaceLayout, JsonValue, SurfaceContext, SurfaceGap, SurfaceLayoutType, ViewComponentDescriptor, ViewComponentEventPorts, } from "@mcpview/contracts";
export type McpViewHostContext = AppContext<unknown>["hostContext"];
export type ComponentCleanup = () => void | Promise<void>;
export interface ViewComponentMountContext<TData, TAppContext> {
    readonly data: TData;
    readonly props: Readonly<Record<string, JsonValue>>;
    readonly instanceId: string;
    readonly appContext: TAppContext;
    readonly hostContext: McpViewHostContext;
}
export interface ViewComponentDefinition<TData = unknown, TAppContext = unknown> {
    readonly descriptor: ViewComponentDescriptor;
    mount(target: HTMLElement, context: ViewComponentMountContext<TData, TAppContext>): void | ComponentCleanup | Promise<void | ComponentCleanup>;
}
export interface ViewComponentRegistry<TData = unknown, TAppContext = unknown> {
    readonly components: Readonly<Record<string, ViewComponentDefinition<TData, TAppContext>>>;
    /** Omit for component-only Apps that are meaningful only inside a host composition. */
    readonly defaultSurface?: ComponentSurface;
}
export interface MountedComponentSurface {
    readonly surface: ComponentSurface;
    dispose(): Promise<void>;
}
export interface MountComponentSurfaceOptions<TData, TAppContext> {
    readonly root: HTMLElement;
    readonly registry: ViewComponentRegistry<TData, TAppContext>;
    readonly data: TData;
    readonly appContext: TAppContext;
    readonly hostContext: McpViewHostContext;
    /** Explicit surface wins; otherwise the negotiated or default surface is used. */
    readonly surface?: ComponentSurface;
}
export declare function defineViewComponent<TData = unknown, TAppContext = unknown>(definition: ViewComponentDefinition<TData, TAppContext>): ViewComponentDefinition<TData, TAppContext>;
export declare function defineComponentRegistry<TData = unknown, TAppContext = unknown>(registry: ViewComponentRegistry<TData, TAppContext>): ViewComponentRegistry<TData, TAppContext>;
export declare function defineComponentSurface(surface: ComponentSurface): ComponentSurface;
/** Build the serializable value advertised in `AppConfig.capabilities.experimental`. */
export declare function componentCatalogCapabilities<TData, TAppContext>(registry: ViewComponentRegistry<TData, TAppContext>): Record<string, object>;
export declare function advertisedComponentCatalog<TData, TAppContext>(registry: ViewComponentRegistry<TData, TAppContext>): AdvertisedComponentCatalog;
/** Expose only surface identity/status for CSS and diagnostics, never component internals. */
export declare function applySurfaceContext(hostContext: McpViewHostContext, target: {
    dataset: Record<string, string | undefined>;
}): void;
export declare function activeComponentSurface<TData, TAppContext>(registry: ViewComponentRegistry<TData, TAppContext>, hostContext: McpViewHostContext): ComponentSurface | undefined;
/** Mount one declarative surface and return deterministic aggregate cleanup. */
export declare function mountComponentSurface<TData, TAppContext>(options: MountComponentSurfaceOptions<TData, TAppContext>): Promise<MountedComponentSurface>;
//# sourceMappingURL=components.d.ts.map