import { type TranslatorSelector } from "./i18n.js";
import type { ContextBasketLabels } from "./preact/context-basket.js";
/** Interface text only; selection labels and group summaries remain caller data. */
export declare const CONTEXT_BASKET_MESSAGES_EN: {
    readonly active: "Active context";
    readonly items: "Context items";
    readonly remove: "Remove {label} from context";
    readonly clearAll: "Clear context";
    readonly pending: "Updating context…";
    readonly error: "Context update failed";
    readonly retry: "Retry";
    readonly evicted: "Removed oldest item: {label}";
};
export type ContextBasketMessages = {
    readonly [Key in keyof typeof CONTEXT_BASKET_MESSAGES_EN]: string;
};
export declare const CONTEXT_BASKET_MESSAGES_FR: ContextBasketMessages;
export declare const contextBasketMessages: TranslatorSelector<keyof ContextBasketMessages>;
/** Optional EN/FR kit labels. Pass your own labels to customize any interface text. */
export declare function contextBasketLabels(locale?: string): ContextBasketLabels;
//# sourceMappingURL=context-basket-labels.d.ts.map