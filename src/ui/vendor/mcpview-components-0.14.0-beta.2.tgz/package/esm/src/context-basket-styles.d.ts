/** Optional plain CSS for the controlled context basket; uses the shared theme tokens. */
export declare const MCP_VIEW_CONTEXT_BASKET_CSS: string;
/**
 * Optional row/card selection treatment. Set data-context-state from
 * useActiveContext().selectionState(item); shared light/dark theme tokens apply.
 */
export declare const MCP_VIEW_CONTEXT_SELECTION_CSS: string;
//# sourceMappingURL=context-basket-styles.d.ts.map