export declare const MCP_VIEW_FONTS_CSS: string;
//# sourceMappingURL=fonts-data.d.ts.map