/** Opt-in embedded webfaces for the shared theme. */
import { MCP_VIEW_FONT_FAMILIES, type McpViewFontFamily } from "./font-families.js";
import { MCP_VIEW_FONTS_CSS } from "./fonts-data.js";
import type { McpViewThemeDocument } from "./theme.js";
export { MCP_VIEW_FONT_FAMILIES, MCP_VIEW_FONTS_CSS, type McpViewFontFamily };
export declare const MCP_VIEW_FONTS_STYLE_ID = "mcp-view-fonts";
/**
 * Install the embedded `@font-face` rules once per document. Independent of
 * `installMcpViewTheme`: call both, in either order, for a fully offline viewer.
 */
export declare function installMcpViewFonts(target?: McpViewThemeDocument): HTMLStyleElement;
//# sourceMappingURL=fonts.d.ts.map