/** Small, renderer-neutral message dictionaries. Never translates domain data. */
export type MessageValues = Readonly<Record<string, string | number>>;
export type Translator<Key extends string> = (key: Key, values?: MessageValues) => string;
/** Callable message selector plus the dictionary locale actually chosen for a host locale. */
export interface TranslatorSelector<Key extends string> {
    (locale?: string): Translator<Key>;
    /** Exact registered locale, else the matched parent, else the canonical default. */
    locale(hostLocale?: string): string;
}
export interface MessageCatalog<Key extends string> {
    readonly defaultLocale?: string;
    readonly messages: Readonly<Record<Key, string>>;
    readonly translations?: Readonly<Record<string, Partial<Readonly<Record<Key, string>>>>>;
}
/**
 * Select messages by exact locale, then language parents, then the base dictionary.
 * Missing entries fall back independently. Invalid host locales use the base locale.
 * Interpolation is plain text; render the returned value as text, never as HTML.
 * `.locale(hostLocale)` uses that same chain and names the dictionary actually selected.
 */
export declare function createTranslator<Key extends string>(catalog: MessageCatalog<Key>): TranslatorSelector<Key>;
/** Interface wording only: contract states and caller messages remain untouched. */
export declare const MCP_VIEW_MESSAGES_EN: {
    readonly loadingTitle: "Loading";
    readonly loadingMessage: "Waiting for data…";
    readonly emptyTitle: "Empty";
    readonly emptyMessage: "No structured data received.";
    readonly errorTitle: "Error";
    readonly sessionRejectedTitle: "Session rejected";
    readonly resultRejectedTitle: "Result rejected";
    readonly surfaceRequiredTitle: "Surface required";
    readonly surfaceRequiredMessage: "This App exposes components and requires a host-selected surface.";
    readonly surfaceInvalidTitle: "Surface invalid";
    readonly surfaceInvalidMessage: "The {owner} component surface is invalid: {error}";
    readonly surfaceFailedTitle: "Surface failed";
    readonly surfaceFailedMessage: "Component surface failed: {error}";
};
export type McpViewMessages = {
    readonly [Key in keyof typeof MCP_VIEW_MESSAGES_EN]: string;
};
export declare const MCP_VIEW_MESSAGES_FR: McpViewMessages;
/** Extend a locale dictionary through createTranslator; no global locale or mutable registry. */
export declare const mcpViewMessages: TranslatorSelector<keyof McpViewMessages>;
//# sourceMappingURL=i18n.d.ts.map