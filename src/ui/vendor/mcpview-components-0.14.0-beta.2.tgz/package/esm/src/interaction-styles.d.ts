/** Standalone styles for exploration and context controls. No global theme is required. */
export declare const MCP_VIEW_INTERACTION_CSS: string;
/** Install only the interaction styles once in a standalone viewer's document. */
export declare function installMcpViewInteractionStyles(target?: Document): HTMLStyleElement;
//# sourceMappingURL=interaction-styles.d.ts.map