/**
 * Preact hooks over the layout decision. They measure the DOM and query the
 * browser, but they take the host context as a parameter: nothing here
 * imports `@mcpview/view` or the MCP Apps runtime.
 */
import type { RefObject } from "preact";
import { type LayoutHostHints, type ViewerBoundsStyle, type ViewerLayout } from "./viewer-layout.js";
/**
 * The observed width of one container, to choose a layout.
 *
 * The container is measured, not the window: a `matchMedia` on the window
 * would call a 380px panel opened in a full-screen browser "wide". The width
 * is `null` until measured, so a caller can tell an unmeasured root from a
 * real width; the decision reads an unknown width as wide — the usual case —
 * rather than flashing the narrow treatment on every first paint.
 *
 * Measurement runs in `useLayoutEffect` so the content box is known before
 * the browser paints. A `useEffect` + ResizeObserver only would paint `wide`
 * for one frame (`isNarrow(null)` is false) and then the real treatment. The
 * content box matches `contentRect` (clientWidth minus paddings); a
 * border-box `getBoundingClientRect` is 2px too wide on a 1px-border shell
 * and would flash the other way when the observer corrected it.
 */
export declare function useContainerWidth<T extends HTMLElement>(): [RefObject<T>, number | null];
/**
 * Whether the browser reports a coarse pointer — a finger or a stylus.
 *
 * Browser fallback only: `matchMedia` describes the device showing the
 * window, not the context the host gives the iframe. The host's
 * `deviceCapabilities` win whenever they are declared (see `useViewerLayout`).
 *
 * The initial value is read synchronously so the first paint already has the
 * right treatment: a `useState(false)` that is corrected in `useEffect` would
 * first paint `panel` (stacked rows) and then `mobile` (touch table) — two
 * structures, not two densities of the same table.
 */
export declare function useCoarsePointer(): boolean;
export interface UseViewerLayoutOptions {
    /**
     * An explicit treatment: `null` detects. When omitted the page query string
     * is consulted (`?layout=mobile`) so a treatment can be reviewed without the
     * matching device; pass `null` to ignore the URL.
     */
    readonly forced?: ViewerLayout | null;
}
export interface ViewerLayoutState<T extends HTMLElement> {
    /** Attach to the element whose width is the layout's; the shell is the container. */
    readonly ref: RefObject<T>;
    /** The width judged: the host's declared width, else the measured one, else `null`. */
    readonly width: number | null;
    readonly layout: ViewerLayout;
    /** Inline style bounding the root on the host's declared height, if any. */
    readonly boundsStyle: ViewerBoundsStyle | undefined;
}
/**
 * One layout decision for one viewer root: the host's word first, the
 * browser's measure as fallback, an explicit override on top.
 */
export declare function useViewerLayout<T extends HTMLElement>(hints: LayoutHostHints | undefined, options?: UseViewerLayoutOptions): ViewerLayoutState<T>;
//# sourceMappingURL=hooks.d.ts.map