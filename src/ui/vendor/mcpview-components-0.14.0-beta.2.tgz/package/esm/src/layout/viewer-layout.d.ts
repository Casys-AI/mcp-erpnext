/**
 * Responsive layout decision for one MCP App viewer, without Preact or the
 * MCP Apps runtime: every input is a value the caller already holds.
 *
 * A viewer renders inside a host iframe whose width says nothing about the
 * screen, so the decision starts from the width the host grants (or the
 * measured container), never from `matchMedia` on the window. Three
 * treatments exist and they are not a scale of widths: a 380px desktop side
 * panel stacks its rows, a 390px phone keeps its table with 40px touch rows.
 * What separates the two narrow treatments is the pointer, not the space.
 */
/** `wide` keeps every column; `panel` stacks rows; `mobile` keeps a compact touch table. */
export type ViewerLayout = "wide" | "panel" | "mobile";
export declare const VIEWER_LAYOUTS: readonly ViewerLayout[];
/** Below this container width the wide treatment gives way to a narrow one. */
export declare const NARROW_BREAKPOINT = 480;
/**
 * The host-context fields the layout decision reads. Structurally a subset of
 * the MCP Apps `McpUiHostContext`, so `ctx.hostContext` is passed as is; a
 * viewer with its own host-context store passes that store's value instead.
 */
export interface LayoutHostHints {
    readonly deviceCapabilities?: {
        readonly touch?: boolean;
        readonly hover?: boolean;
    };
    readonly containerDimensions?: LayoutContainerDimensions;
}
/** Dimensions a host may announce; each one is optional and only trusted when positive. */
export interface LayoutContainerDimensions {
    readonly width?: number;
    readonly maxWidth?: number;
    readonly height?: number;
    readonly maxHeight?: number;
}
/** The inputs of one layout decision. */
export interface ViewerLayoutInputs {
    /** The width to judge: `null` while nothing has been measured yet. */
    readonly width: number | null;
    /** Whether the viewer is driven by a finger rather than a fine pointer. */
    readonly touch: boolean;
    /** An explicit override (`?layout=`, a host declaration); `null` or `undefined` to detect. */
    readonly forced?: ViewerLayout | null;
}
/** True once a width is known and it is under the breakpoint. */
export declare function isNarrow(width: number | null): boolean;
/** `?layout=mobile` in a query string, for reviewing a treatment without the matching device. */
export declare function layoutFromSearch(search: string): ViewerLayout | null;
/**
 * The width to judge: what the host grants, else what was measured.
 *
 * A declared width describes the room actually given, where a
 * `ResizeObserver` only measures what the iframe happened to take.
 */
export declare function layoutWidth(hints: LayoutHostHints | undefined, measured: number | null): number | null;
/**
 * Whether a finger drives the viewer, by the host's word or the browser's.
 *
 * `touch` alone is not enough: a laptop with a touch screen driven by a mouse
 * declares `touch: true, hover: true` and is no phone. Only a finger without
 * hover justifies 40px targets. When the host says nothing, the browser's
 * coarse-pointer query decides.
 */
export declare function touchInput(hints: LayoutHostHints | undefined, browserCoarsePointer: boolean): boolean;
/**
 * The treatment for these inputs. A tablet under a finger but with room keeps
 * the wide layout: room is what mobile lacks; the finger only chooses between
 * the two narrow treatments.
 */
export declare function resolveViewerLayout(inputs: ViewerLayoutInputs): ViewerLayout;
/** The inline style that bounds a viewer root on the host's declared height. */
export type ViewerBoundsStyle = {
    readonly height: string;
} | {
    readonly maxHeight: string;
};
/**
 * Bound the root on the host's real container instead of `100vh`. Without a
 * declared height the viewer stays intrinsic and lets the host auto-resize.
 */
export declare function viewerBoundsStyle(dimensions: LayoutContainerDimensions | undefined): ViewerBoundsStyle | undefined;
//# sourceMappingURL=viewer-layout.d.ts.map