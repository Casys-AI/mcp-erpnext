/** @jsxImportSource preact */
/** Shared Preact presentation primitives for composable MCP Apps. */
import type { ComponentChildren, JSX } from "preact";
export type PresentationTone = "neutral" | "info" | "success" | "warning" | "danger";
export interface StackProps {
    readonly gap?: "xs" | "sm" | "md" | "lg";
    readonly className?: string;
    readonly children?: ComponentChildren;
}
/** Simple vertical composition primitive; it carries no domain semantics. */
export declare function Stack({ gap, className, children }: StackProps): JSX.Element;
export interface RowProps {
    readonly label?: string;
    readonly responsive?: boolean;
    readonly className?: string;
    readonly children?: ComponentChildren;
}
/** Horizontal fact or control row; its contents and meaning remain caller-owned. */
export declare function Row({ label, responsive, className, children, }: RowProps): JSX.Element;
export interface CardProps {
    readonly title?: ComponentChildren;
    readonly eyebrow?: ComponentChildren;
    readonly actions?: ComponentChildren;
    readonly className?: string;
    readonly children?: ComponentChildren;
}
/** The canonical MCP component container. */
export declare function Card({ title, eyebrow, actions, className, children, }: CardProps): JSX.Element;
export interface BadgeProps {
    readonly tone?: PresentationTone;
    readonly children?: ComponentChildren;
    readonly className?: string;
}
export interface BadgeGroupProps {
    readonly label: string;
    readonly className?: string;
    readonly children?: ComponentChildren;
}
/** Accessible wrapping group for compact status and classification badges. */
export declare function BadgeGroup({ label, className, children, }: BadgeGroupProps): JSX.Element;
/** Compact status or classification label. */
export declare function Badge({ tone, children, className }: BadgeProps): JSX.Element;
export interface MetricItem {
    readonly id: string;
    readonly label: ComponentChildren;
    readonly value: ComponentChildren;
    readonly unit?: ComponentChildren;
    readonly detail?: ComponentChildren;
    readonly tone?: PresentationTone;
}
export interface MetricGridProps {
    readonly items: readonly MetricItem[];
    readonly className?: string;
}
export interface MetricProps extends Omit<MetricItem, "id"> {
    readonly id?: string;
    readonly className?: string;
}
/** One unit-bearing reading. Callers remain responsible for the value and its tone. */
export declare function Metric({ id, label, value, unit, detail, tone, className, }: MetricProps): JSX.Element;
/** Responsive, container-aware metrics with stable semantic slots. */
export declare function MetricGrid({ items, className }: MetricGridProps): JSX.Element;
export interface KeyValueItem {
    readonly id: string;
    readonly label: ComponentChildren;
    readonly value: ComponentChildren;
}
/**
 * `inspector` (default): mono key, value flush right, hairline between rows.
 * `facts`: one aligned label column, each value read right after its label.
 */
export type KeyValueLayout = "inspector" | "facts";
export interface KeyValueListProps {
    readonly items: readonly KeyValueItem[];
    readonly layout?: KeyValueLayout;
    readonly className?: string;
}
/** Provenance and identity facts with safe wrapping for hashes and URIs. */
export declare function KeyValueList({ items, layout, className, }: KeyValueListProps): JSX.Element;
export interface DataTableColumn<TRow> {
    readonly id: string;
    readonly label: ComponentChildren;
    readonly align?: "left" | "right";
    readonly render: (row: TRow) => ComponentChildren;
}
export interface DataTableDisclosure {
    /** Localized accessible action, including the row identity. */
    readonly label: string;
    /** Supply only for locally expandable details. */
    readonly expanded?: boolean;
    readonly controls?: string;
    readonly onOpen: () => void;
}
export interface DataTableProps<TRow> {
    readonly label: string;
    readonly rows: readonly TRow[];
    readonly columns: readonly DataTableColumn<TRow>[];
    readonly rowKey: (row: TRow) => string | number;
    readonly selected?: (row: TRow) => boolean;
    readonly onSelect?: (row: TRow) => void;
    /** A row with a disclosure opens on activation. Other rows keep their optional selection action. */
    readonly getDisclosure?: (row: TRow) => DataTableDisclosure | undefined;
    readonly emptyLabel?: string;
    readonly className?: string;
}
/** Accessible compact table; selection behavior is opt-in and keyboard-safe. */
export declare function DataTable<TRow>({ label, rows, columns, rowKey, selected, onSelect, getDisclosure, emptyLabel, className, }: DataTableProps<TRow>): JSX.Element;
export interface ButtonProps {
    readonly type?: "button" | "submit" | "reset";
    readonly pressed?: boolean;
    readonly disabled?: boolean;
    readonly title?: string;
    readonly className?: string;
    readonly onClick?: JSX.MouseEventHandler<HTMLButtonElement>;
    readonly children?: ComponentChildren;
}
/** Small dashboard-safe action, never a product-wide navigation control. */
export declare function Button({ type, pressed, disabled, title, className, onClick, children, }: ButtonProps): JSX.Element;
export interface ToolbarProps {
    readonly label: string;
    readonly className?: string;
    readonly children?: ComponentChildren;
}
export interface TextInputProps {
    readonly label: string;
    readonly value: string;
    readonly placeholder?: string;
    readonly type?: "text" | "search";
    readonly disabled?: boolean;
    readonly className?: string;
    readonly onValueInput?: (value: string) => void;
}
/** Compact controlled text input with a mandatory accessible label. */
export declare function TextInput({ label, value, placeholder, type, disabled, className, onValueInput, }: TextInputProps): JSX.Element;
export interface CodeBlockProps {
    readonly label?: string;
    readonly className?: string;
    readonly children?: ComponentChildren;
}
/** Bounded preformatted content for expressions, source excerpts, and exact text. */
export declare function CodeBlock({ label, className, children }: CodeBlockProps): JSX.Element;
export interface InlineCodeProps {
    readonly title?: string;
    readonly className?: string;
    readonly children?: ComponentChildren;
}
/** Inline exact text with safe wrapping for fingerprints, identifiers, and URIs. */
export declare function InlineCode({ title, className, children, }: InlineCodeProps): JSX.Element;
export declare function Toolbar({ label, className, children, }: ToolbarProps): JSX.Element;
export interface EmptyStateProps {
    readonly children?: ComponentChildren;
    readonly className?: string;
}
export declare function EmptyState({ children, className, }: EmptyStateProps): JSX.Element;
export interface SkeletonProps {
    /** Accessible description of what is still loading. */
    readonly label: string;
    /** Placeholder lines drawn inside the frame. Defaults to three. */
    readonly lines?: number;
    readonly className?: string;
}
/**
 * Frame-first loading placeholder: the structure of a recorded view appears
 * before its values, so nothing shifts once the values arrive.
 */
export declare function Skeleton({ label, lines, className }: SkeletonProps): JSX.Element;
export interface MessageProps {
    readonly tone?: PresentationTone;
    readonly children?: ComponentChildren;
    readonly className?: string;
}
/** Compact inline notice that keeps surrounding values visible. */
export declare function Message({ tone, children, className, }: MessageProps): JSX.Element;
export interface NoticeGroupProps {
    /** Accessible name and visible heading for the group. */
    readonly label: string;
    /** Caller-formatted notices. Nothing is rendered when there are none. */
    readonly items: readonly ComponentChildren[];
    readonly tone?: PresentationTone;
    /** Caller-formatted statement about entries that were left out. */
    readonly omittedLabel?: ComponentChildren;
    readonly className?: string;
}
/**
 * Short notices gathered under one severity heading.
 *
 * Renders nothing when there is nothing to say, so a caller never has to guard
 * the call site. Truncation is stated by the caller: the group displays the
 * notices it was handed and never counts what it was not.
 */
export declare function NoticeGroup({ label, items, tone, omittedLabel, className, }: NoticeGroupProps): JSX.Element | null;
export interface StatusMessageMount {
    readonly title?: ComponentChildren;
    readonly tone?: PresentationTone;
    readonly busy?: boolean;
    readonly className?: string;
    /** Existing host to render into. Without one a detached `div` is created. */
    readonly container?: HTMLElement;
}
/**
 * Render a `StateMessage` into a real DOM node and hand that node back.
 *
 * `defineView` returns a native element, so every viewer built on it has to
 * bridge Preact to the DOM itself. Hand-written bridges drift — the tone, the
 * alert role and the class stop matching between surfaces of the same product.
 * This is that bridge, so one status looks like every other status.
 */
export declare function renderStatusMessage(detail: ComponentChildren, options?: StatusMessageMount): HTMLElement;
export interface CrossSelectionProps {
    readonly label: ComponentChildren;
    readonly value: ComponentChildren;
    readonly status?: ComponentChildren;
    readonly className?: string;
}
/** Read-only projection of a selection coordinated by an owning host. */
export declare function CrossSelection({ label, value, status, className, }: CrossSelectionProps): JSX.Element;
export interface StateMessageProps {
    readonly title?: ComponentChildren;
    readonly tone?: PresentationTone;
    readonly busy?: boolean;
    readonly children?: ComponentChildren;
    readonly className?: string;
}
export declare function StateMessage({ title, tone, busy, children, className, }: StateMessageProps): JSX.Element;
//# sourceMappingURL=components.d.ts.map