/** @jsxImportSource preact */
import type { JSX } from "preact";
/** Minimum presentation identity; the owning controller retains the full payload. */
export interface ContextBasketSelection {
    readonly scopeKey: string;
    readonly item: {
        readonly id: string;
        readonly label: string;
        readonly view?: string;
        readonly value?: string;
    };
}
/** A caller-projected group: identities, membership and summaries remain caller-owned. */
export interface ContextBasketGroup {
    readonly scopeKey: string;
    readonly id: string;
    readonly label: string;
    readonly summary?: string;
    readonly view?: string;
    readonly value?: string;
}
export type ContextBasketEntry<T extends ContextBasketSelection = ContextBasketSelection> = {
    readonly kind: "single";
    readonly selection: T;
} | {
    readonly kind: "group";
    readonly group: ContextBasketGroup;
};
/** Every visible message and accessible name follows the caller's locale. */
export interface ContextBasketLabels {
    readonly active: string;
    readonly items: string;
    readonly remove: (label: string) => string;
    readonly clearAll: string;
    readonly pending: string;
    readonly error: string;
    readonly retry: string;
    readonly evicted: (label: string) => string;
}
export type ContextBasketSlot = "root" | "single" | "activeLabel" | "singleLabel" | "remove" | "trigger" | "chevron" | "popover" | "list" | "item" | "itemContent" | "itemLabel" | "itemDetail" | "clearAll" | "pending" | "spinner" | "error" | "errorLabel" | "eviction" | "pendingLabel" | "retry";
export type ContextMutation = () => unknown | Promise<unknown>;
export interface ActiveContextChipProps<T extends ContextBasketSelection = ContextBasketSelection> {
    readonly selections: readonly T[];
    /** Overrides the visible list, e.g. one entry per group instead of its projected members. */
    readonly entries?: readonly ContextBasketEntry<T>[];
    readonly labels: ContextBasketLabels;
    readonly failed?: boolean;
    readonly pending?: boolean;
    readonly evictedLabel?: string | null;
    readonly onRemove?: (selection: T) => unknown | Promise<unknown>;
    readonly onRemoveGroup?: (group: ContextBasketGroup) => unknown | Promise<unknown>;
    readonly onClear: ContextMutation;
    readonly onRetry?: ContextMutation;
    readonly compact?: boolean;
    readonly popoverAlign?: "start" | "end";
    readonly className?: string;
    readonly classes?: Partial<Record<ContextBasketSlot, string>>;
}
/** Controlled basket. Acknowledged selections and mutation results remain caller-owned. */
export declare function ActiveContextChip<T extends ContextBasketSelection>({ selections, entries, labels, failed, pending, evictedLabel, onRemove, onRemoveGroup, onClear, onRetry, compact, popoverAlign, className, classes, }: ActiveContextChipProps<T>): JSX.Element | null;
//# sourceMappingURL=context-basket.d.ts.map