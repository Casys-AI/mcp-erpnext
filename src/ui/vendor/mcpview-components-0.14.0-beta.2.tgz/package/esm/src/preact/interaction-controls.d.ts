/** @jsxImportSource preact */
/** Controlled presentation for exploring a reading and pinning it to context. */
import type { JSX } from "preact";
export interface ContextPinButtonProps {
    /** Localized accessible action, including its target. */
    readonly label: string;
    readonly pressed: boolean | "mixed";
    /** Draw two strokes for a collection, including when all or none are pinned. */
    readonly group?: boolean;
    readonly disabled?: boolean;
    readonly className?: string;
    readonly onToggle: (shiftKey: boolean) => void;
}
/** Independent action beside a row, card, or active point. The viewer owns its selection. */
export declare function ContextPinButton({ label, pressed, group, disabled, className, onToggle, }: ContextPinButtonProps): JSX.Element;
export interface DisclosureChevronProps {
    readonly expanded: boolean;
    readonly className?: string;
}
/** Decorative leading glyph. The containing button supplies its label, action and expanded state. */
export declare function DisclosureChevron({ expanded, className }: DisclosureChevronProps): JSX.Element;
//# sourceMappingURL=interaction-controls.d.ts.map