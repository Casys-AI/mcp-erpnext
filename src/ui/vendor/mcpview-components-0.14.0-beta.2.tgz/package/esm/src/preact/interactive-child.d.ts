export declare function eventStartedInInteractiveChild(element: HTMLElement, target: EventTarget | null): boolean;
//# sourceMappingURL=interactive-child.d.ts.map