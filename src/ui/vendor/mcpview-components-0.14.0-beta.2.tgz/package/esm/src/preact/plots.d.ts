/** @jsxImportSource preact */
/**
 * Data marks for recorded numeric evidence.
 *
 * Every plot draws exactly the samples, bounds, and wording the caller passes.
 * None of them resamples, interpolates a missing point, formats a number, picks
 * a unit, derives an extremum, or owns pointer state: a cursor is declared by
 * the provider that already resolved the reading behind it.
 */
import type { JSX } from "preact";
import type { PresentationTone } from "./components.js";
/** Plot colors, including the two categorical theme colors. */
export type SeriesChartTone = PresentationTone | "accent" | "brand";
export interface SparklineProps {
    /** Accessible name of the sampled quantity. */
    readonly label: string;
    /** At least two finite samples, already ordered by the caller. */
    readonly values: readonly number[];
    /** Caller-formatted summary, including units. */
    readonly summaryLabel: string;
    /** Inline mark by default; block also displays the supplied label and summary. */
    readonly variant?: "inline" | "block";
    readonly tone?: SeriesChartTone;
    readonly className?: string;
}
/** Compact shape of one recorded series, readable at chip and row density. */
export declare function Sparkline({ label, values, summaryLabel, variant, tone, className, }: SparklineProps): JSX.Element;
export interface SeriesPoint {
    readonly x: number;
    readonly y: number;
}
/**
 * How one series may be drawn.
 *
 * `line` connects consecutive samples, which asserts the quantity existed
 * between them — only true when the series is sampled densely enough for that
 * claim to hold. `bar` draws each recorded sample on its own and claims nothing
 * in between. The provider knows its sampling, so it declares the mark; the
 * chart never infers one from point spacing.
 */
export type SeriesMark = "line" | "bar";
export interface SeriesChartSeries {
    readonly id: string;
    readonly label: string;
    /** Declared, never inferred. A sparse series drawn as a line invents values. */
    readonly mark: SeriesMark;
    /** At least two finite points, already ordered by the caller. */
    readonly points: readonly SeriesPoint[];
    readonly tone?: SeriesChartTone;
}
export interface SeriesChartReadout {
    /** Must name one declared series. */
    readonly seriesId: string;
    /** Caller-formatted value at the cursor, including units. */
    readonly valueLabel: string;
}
export interface SeriesChartCursor {
    /** Position on the shared x scale. The chart resolves nothing itself. */
    readonly x: number;
    /** Caller-formatted position, such as an instant. */
    readonly label: string;
    /**
     * Values the provider actually recorded at that position. A series with no
     * sample there is simply absent: the chart never interpolates between two
     * samples, never snaps to a neighbour, and never fills a gap to look complete.
     */
    readonly readouts: readonly SeriesChartReadout[];
}
export interface SeriesChartSummaryItem {
    readonly id: string;
    /** Caller wording for the extremum, such as min, max, or final. */
    readonly label: string;
    /** Caller-formatted value, including units and where it occurred. */
    readonly valueLabel: string;
}
export interface SeriesChartProps {
    /** Accessible name of the chart. */
    readonly label: string;
    readonly series: readonly SeriesChartSeries[];
    readonly xMin: number;
    readonly xMax: number;
    readonly yMin: number;
    readonly yMax: number;
    /** Show caller-labelled series keys when at least two series are present. */
    readonly legend?: boolean;
    /** Caller-formatted y ticks on the declared shared scale. */
    readonly yTicks?: readonly {
        readonly value: number;
        readonly label: string;
    }[];
    /** Caller-formatted ticks, left to right. */
    readonly axisLabels?: readonly string[];
    /** Caller-computed extrema. The chart never scans the samples for them. */
    readonly summary?: readonly SeriesChartSummaryItem[];
    /** Declared cursor. Omit it and the chart shows no readout. */
    readonly cursor?: SeriesChartCursor;
    /**
     * Pointer position on the shared x scale, or `undefined` once the pointer
     * leaves. The chart reports screen geometry only; which recorded sample that
     * position corresponds to — or that none does — stays the provider's call.
     */
    readonly onScrub?: (x: number | undefined) => void;
    readonly className?: string;
}
/** Multi-series plot on one shared finite scale, with a declared cursor readout. */
export declare function SeriesChart({ label, series, xMin, xMax, yMin, yMax, axisLabels, legend, yTicks, summary, cursor, onScrub, className, }: SeriesChartProps): JSX.Element;
export interface IntervalPlotInterval {
    readonly id: string;
    /** Caller wording for the interval, such as a tolerance class. */
    readonly label: string;
    readonly lower: number;
    readonly upper: number;
    /** Caller-formatted deviations, including units. */
    readonly lowerLabel: string;
    readonly upperLabel: string;
    readonly tone?: PresentationTone;
}
export interface IntervalPlotProps {
    /** Accessible name of the plot. */
    readonly label: string;
    readonly min: number;
    readonly max: number;
    /** Caller wording for the zero reference, such as the nominal size. */
    readonly zeroLabel: string;
    readonly intervals: readonly IntervalPlotInterval[];
    readonly className?: string;
}
/** Caller-declared deviation intervals laid out against a shared zero line. */
export declare function IntervalPlot({ label, min, max, zeroLabel, intervals, className, }: IntervalPlotProps): JSX.Element;
//# sourceMappingURL=plots.d.ts.map