/** @jsxImportSource preact */
/** Generic, domain-neutral presentation shell for one semantic object. */
import type { ComposedSemanticRef } from "@mcpview/contracts";
import type { ComponentChildren, JSX, VNode } from "preact";
import { type CardProps, type PresentationTone } from "./components.js";
export type SemanticElementDensity = "chip" | "row" | "card";
export interface SemanticListProps {
    readonly label: string;
    readonly scrollable?: boolean;
    readonly className?: string;
    readonly children?: ComponentChildren;
}
/** Bounded group for row-density semantic objects; it owns no domain ordering. */
export declare function SemanticList({ label, scrollable, className, children, }: SemanticListProps): JSX.Element;
export interface CollectionCardProps extends Pick<CardProps, "title" | "eyebrow" | "actions" | "className" | "children">, Pick<SemanticListProps, "label" | "scrollable"> {
}
/** Card-hosted SemanticList that keeps a single outer border. */
export declare function CollectionCard({ label, title, eyebrow, actions, scrollable, className, children, }: CollectionCardProps): JSX.Element;
export interface ElementIdentProps {
    readonly label: ComponentChildren;
    readonly detail?: ComponentChildren;
    readonly marker?: ComponentChildren;
    readonly className?: string;
}
/** Required human-facing identity slot. Its content is already resolved by the caller. */
export declare function ElementIdent({ label, detail, marker, className, }: ElementIdentProps): JSX.Element;
export interface ElementReadingProps {
    readonly value: ComponentChildren;
    readonly label?: ComponentChildren;
    readonly unit?: ComponentChildren;
    readonly detail?: ComponentChildren;
    readonly className?: string;
}
/** Resolved measurement or documentary reading; no unit is guessed. */
export declare function ElementReading({ value, label, unit, detail, className, }: ElementReadingProps): JSX.Element;
export interface ElementLimitProps {
    readonly operator: ComponentChildren;
    readonly value: ComponentChildren;
    readonly label?: ComponentChildren;
    readonly unit?: ComponentChildren;
    readonly detail?: ComponentChildren;
    readonly className?: string;
}
/** Caller-declared limit statement; never infers a range, measurement, or verdict. */
export declare function ElementLimit({ operator, value, label, unit, detail, className, }: ElementLimitProps): JSX.Element;
export interface ElementVerdictProps {
    readonly value: ComponentChildren;
    readonly label?: ComponentChildren;
    readonly className?: string;
}
export interface ElementBodyProps {
    readonly children?: ComponentChildren;
    readonly className?: string;
}
/** Optional provider-owned visualization slot, such as a gauge or compact domain plot. */
export declare function ElementBody({ children, className }: ElementBodyProps): JSX.Element;
export interface ElementSectionProps {
    /** Visible heading and accessible name of the group; the caller words it. */
    readonly title: string;
    readonly className?: string;
    readonly children?: ComponentChildren;
}
/**
 * One titled group inside an ElementBody. A datasheet body is sections, not one
 * list: each fact belongs to exactly one, and the section names what its facts are.
 */
export declare function ElementSection({ title, className, children, }: ElementSectionProps): JSX.Element;
/** Caller-authored verdict. Tone remains an explicit SemanticElement concern. */
export declare function ElementVerdict({ value, label, className, }: ElementVerdictProps): JSX.Element;
export interface ElementProvenanceProps {
    readonly value: ComponentChildren;
    readonly label?: ComponentChildren;
    readonly className?: string;
}
/** Exact caller-provided provenance such as a source, revision, or fingerprint. */
export declare function ElementProvenance({ value, label, className, }: ElementProvenanceProps): JSX.Element;
export interface SemanticElementProps {
    /** Structured identity only. This component never resolves or dereferences it. */
    readonly reference: ComposedSemanticRef;
    /** Presentation density. A whole viewer is deliberately not a density. */
    readonly density: SemanticElementDensity;
    /** Explicit visual verdict. Omit when the object has no warranted verdict. */
    readonly tone?: PresentationTone;
    /** Explicit current selection; presentation and accessible state stay kit-owned. */
    readonly selected?: boolean;
    /** Every semantic object must provide a resolved identity slot. */
    readonly ident: VNode<ElementIdentProps>;
    readonly reading?: VNode<ElementReadingProps | ElementLimitProps> | readonly VNode<ElementReadingProps | ElementLimitProps>[];
    readonly body?: VNode<ElementBodyProps> | readonly VNode<ElementBodyProps>[];
    readonly verdict?: VNode<ElementVerdictProps>;
    readonly provenance?: VNode<ElementProvenanceProps>;
    readonly activationLabel?: string;
    readonly onActivate?: (reference: ComposedSemanticRef) => void;
    readonly className?: string;
}
/**
 * Render one semantic object without owning domain vocabulary or reference resolution.
 *
 * The same slots survive chip, row, and card composition. When a tone is explicitly
 * supplied, an inline-start verdict border is invariant across all three densities.
 */
export declare function SemanticElement({ reference, density, tone, selected, ident, reading, body, verdict, provenance, activationLabel, onActivate, className, }: SemanticElementProps): JSX.Element;
//# sourceMappingURL=semantic-element.d.ts.map