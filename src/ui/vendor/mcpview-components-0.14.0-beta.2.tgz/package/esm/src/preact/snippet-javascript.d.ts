type Style = "comment" | "keyword" | "string" | "literal";
type Range = {
    start: number;
    end: number;
    style: Style;
};
/** Offset ranges leave line endings, escape sequences and all other source text untouched. */
export declare function javascriptHighlightRanges(code: string): Range[];
export {};
//# sourceMappingURL=snippet-javascript.d.ts.map