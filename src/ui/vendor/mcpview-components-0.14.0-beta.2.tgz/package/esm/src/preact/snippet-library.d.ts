/** @jsxImportSource preact */
import type { ComponentChildren, JSX } from "preact";
export interface SnippetLibraryEntry {
    /** Stable identifier passed back to the caller in onInspect. */
    readonly id: string;
    readonly name: string;
    readonly description?: string;
}
export interface SnippetLibrarySource {
    readonly name: string;
    readonly description?: string;
    readonly code: string;
    /** Omit to display plain text. */
    readonly language?: "javascript";
}
export interface SnippetLibraryLabels {
    readonly title: string;
    readonly search: string;
    readonly view: string;
    readonly viewNamed: (name: string) => string;
    readonly back: string;
    readonly empty: string;
    readonly noMatch: string;
}
export interface SnippetLibraryProps {
    readonly entries?: readonly SnippetLibraryEntry[];
    readonly source?: SnippetLibrarySource;
    readonly labels: SnippetLibraryLabels;
    readonly busy?: boolean;
    /** Optional navigation shown beside the library title while browsing. */
    readonly headerAction?: ComponentChildren;
    readonly onInspect?: (entry: SnippetLibraryEntry) => void;
    readonly onBack?: () => void;
}
/** Search snippet metadata and present caller-supplied source as exact, selectable text. */
export declare function SnippetLibrary({ entries, source, labels, busy, headerAction, onInspect, onBack, }: SnippetLibraryProps): JSX.Element;
//# sourceMappingURL=snippet-library.d.ts.map