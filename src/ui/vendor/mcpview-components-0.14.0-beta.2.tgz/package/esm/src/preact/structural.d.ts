/** @jsxImportSource preact */
/** Pure presentation structures shared by composable MCP Apps. */
import type { ComponentChildren, JSX } from "preact";
import type { PresentationTone } from "./components.js";
export interface PathBarItem {
    readonly id: string;
    readonly label: ComponentChildren;
    /** Recorded state of that kept level, revealed only by the collapsed disclosure. */
    readonly detail?: ComponentChildren;
}
/** Trailing items kept inline before the leading ones collapse. */
export declare const PATH_BAR_DEFAULT_MAX_VISIBLE = 3;
export interface PathBarProps {
    /** Accessible name for the navigation landmark. */
    readonly label: string;
    /** Ordered path, including the current item. */
    readonly items: readonly PathBarItem[];
    /** Controlled identity of the current item. */
    readonly currentId: string;
    /** Local navigation callback. The component owns no routing state. */
    readonly onSelect: (id: string) => void;
    /** Inline capacity before the leading items collapse. Defaults to three. */
    readonly maxVisible?: number;
    /** Accessible name of the collapsed disclosure. Omit to never collapse. */
    readonly collapsedLabel?: string;
    /** Accessible name of the leading step-out control. Omit to render none. */
    readonly backLabel?: string;
    readonly className?: string;
}
/**
 * Controlled breadcrumb-like navigation without host or MCP side effects.
 *
 * A one-item path renders nothing: the first level has nothing to leave.
 */
export declare function PathBar({ label, items, currentId, onSelect, maxVisible, collapsedLabel, backLabel, className, }: PathBarProps): JSX.Element | null;
/** Where one available drill-down leads. */
export type DrillHintDirection = "in-view" | "to-model";
interface DrillHintBaseProps {
    readonly label: ComponentChildren;
    readonly direction: DrillHintDirection;
    readonly className?: string;
}
interface StaticDrillHintProps extends DrillHintBaseProps {
    readonly onActivate?: undefined;
    readonly actionLabel?: never;
}
interface InteractiveDrillHintProps extends DrillHintBaseProps {
    readonly onActivate: () => void;
    /** Accessible action name, supplied together with the callback. */
    readonly actionLabel: string;
}
export type DrillHintProps = StaticDrillHintProps | InteractiveDrillHintProps;
/**
 * Affordance for one available drill-down.
 *
 * Without a callback the hint degrades to plain text and shows no glyph, so a
 * host that cannot follow it never advertises a step that does not exist.
 */
export declare function DrillHint(props: DrillHintProps): JSX.Element;
/** Shape of one recorded level, so a path never hides what it opens onto. */
export type ViewKind = "list" | "chart" | "record";
export interface TypeBadgeProps {
    readonly kind: ViewKind;
    /** Caller-provided wording. The kit never translates or invents a label. */
    readonly label: ComponentChildren;
    readonly className?: string;
}
/** Names what one level is, next to the path that reached it. */
export declare function TypeBadge({ kind, label, className }: TypeBadgeProps): JSX.Element;
export interface StaleBannerAction {
    readonly label: string;
    readonly onActivate: () => void;
}
export interface StaleBannerProps {
    /** Caller-formatted sentence, including the instant those values were recorded. */
    readonly message: ComponentChildren;
    readonly tone?: PresentationTone;
    readonly action?: StaleBannerAction;
    readonly className?: string;
}
/**
 * Marks the surrounding values as recorded earlier without hiding them.
 *
 * The banner refetches nothing and never replaces a dated value with a gap.
 */
export declare function StaleBanner({ message, tone, action, className, }: StaleBannerProps): JSX.Element;
export interface Slot3DProps {
    /** Accessible name of the reserved area. */
    readonly label: string;
    /** Caller-provided wording for the reserved state. */
    readonly statusLabel: ComponentChildren;
    /** A provider-owned renderer. Without one the slot stays visibly reserved. */
    readonly children?: ComponentChildren;
    readonly className?: string;
}
/** Reserved area for a provider-owned 3D pose. The kit renders no geometry. */
export declare function Slot3D({ label, statusLabel, children, className }: Slot3DProps): JSX.Element;
export interface TreeListNode {
    readonly id: string;
    readonly label: ComponentChildren;
    /** Caller-provided type wording, such as a package, part, or attribute. */
    readonly typeLabel?: ComponentChildren;
    readonly detail?: ComponentChildren;
    /** Caller-computed coverage wording. The kit counts nothing. */
    readonly coverageLabel?: ComponentChildren;
    readonly tone?: PresentationTone;
    readonly children?: readonly TreeListNode[];
}
export interface TreeListProps {
    /** Accessible name for the tree. */
    readonly label: string;
    readonly nodes: readonly TreeListNode[];
    /** Controlled expansion. The component keeps no local disclosure state. */
    readonly expandedIds: readonly string[];
    readonly onToggle: (id: string) => void;
    /** Accessible name shared by every disclosure control. */
    readonly toggleLabel: string;
    readonly selectedId?: string;
    /** Omit to render a read-only tree with no selection affordance. */
    readonly onSelect?: (id: string) => void;
    readonly className?: string;
}
/** Controlled hierarchy with caller-owned type wording and coverage. */
export declare function TreeList({ label, nodes, expandedIds, onToggle, toggleLabel, selectedId, onSelect, className, }: TreeListProps): JSX.Element;
export interface LimitGaugeLimit {
    /** Position of the caller-provided limit on the same finite scale. */
    readonly value: number;
    /** Visible description of that recorded limit. */
    readonly label: string;
}
export interface LimitGaugeProps {
    readonly label: string;
    readonly min: number;
    readonly max: number;
    readonly value: number;
    /** Caller-formatted reading, including its unit when applicable. */
    readonly valueLabel: string;
    /** Caller-provided state text; the gauge never derives a verdict. */
    readonly statusLabel: string;
    readonly tone: PresentationTone;
    readonly limit?: LimitGaugeLimit;
    readonly className?: string;
}
/** Finite meter with an optional caller-supplied limit marker and explicit status text. */
export declare function LimitGauge({ label, min, max, value, valueLabel, statusLabel, tone, limit, className, }: LimitGaugeProps): JSX.Element;
export interface ArtifactFingerprint {
    readonly algorithm: string;
    readonly digest: string;
}
export interface ArtifactVerification {
    /** Literal verification state supplied by the caller. */
    readonly label: ComponentChildren;
    readonly tone: PresentationTone;
}
interface ArtifactRowBaseProps {
    readonly label: ComponentChildren;
    readonly kind?: ComponentChildren;
    readonly uri: string;
    readonly fingerprint?: ArtifactFingerprint;
    /** Caller-formatted byte size or other bounded size description. */
    readonly sizeLabel?: ComponentChildren;
    readonly verification?: ArtifactVerification;
    readonly className?: string;
}
interface StaticArtifactRowProps extends ArtifactRowBaseProps {
    readonly onActivate?: undefined;
    readonly actionLabel?: never;
}
interface InteractiveArtifactRowProps extends ArtifactRowBaseProps {
    readonly onActivate: () => void;
    /** Accessible action name, supplied together with the callback. */
    readonly actionLabel: string;
}
export type ArtifactRowProps = StaticArtifactRowProps | InteractiveArtifactRowProps;
/** Immutable-artifact presentation; verification is displayed, never inferred or performed. */
export declare function ArtifactRow(props: ArtifactRowProps): JSX.Element;
export {};
//# sourceMappingURL=structural.d.ts.map