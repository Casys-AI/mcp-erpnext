/** Preact bindings for result-driven MCP App component surfaces. */
import { type FunctionComponent } from "preact";
import { type JsonValue, type ViewComponentDefinition, type ViewComponentDescriptor } from "../components.js";
import { type SurfaceAppContext, type SurfaceAppHandle, type SurfaceAppOptions, type SurfaceAppRuntime, type SurfaceAppState, type SurfaceStatus } from "../surface-app.js";
export type { SurfaceAppErrorCode, SurfaceAppHandle, SurfaceAppRuntime, SurfaceDisplayState, SurfaceHostAccess, SurfaceLabel, SurfaceMessageKind, SurfaceProjection, SurfaceStatus, SurfaceStatusTone, SurfaceToolResult, SurfaceViewerSession, } from "../surface-app.js";
export { SurfaceAppError } from "../surface-app.js";
export type PreactSurfaceAppState<TData> = SurfaceAppState<TData>;
export type PreactSurfaceContext<TData> = SurfaceAppContext<TData>;
export interface PreactSurfaceComponentProps<TData, TAppContext = PreactSurfaceContext<TData>> {
    readonly data: TData;
    readonly context: TAppContext;
    readonly instanceId: string;
    readonly props: Readonly<Record<string, JsonValue>>;
}
/** Small injection seam for DOM-light unit tests. */
export interface PreactComponentRenderer {
    mount<P extends object>(component: FunctionComponent<P>, props: P, target: HTMLElement): void;
    unmount(target: HTMLElement): void;
}
export declare const preactSurfaceRenderer: PreactComponentRenderer;
/** Turn one Preact component into a renderer-neutral mcp-view component. */
export declare function definePreactComponent<TData, TAppContext = PreactSurfaceContext<TData>>(descriptor: ViewComponentDescriptor, component: FunctionComponent<PreactSurfaceComponentProps<TData, TAppContext>>, renderer?: PreactComponentRenderer): ViewComponentDefinition<TData, TAppContext>;
export interface PreactSurfaceAppOptions<TData, TSession = never> extends Omit<SurfaceAppOptions<TData, TSession>, "renderStatus" | "surfaceClassName"> {
    /** Class of the element wrapping the mounted surface. Default `mcp-view-preact-surface`. */
    readonly surfaceClassName?: string;
    /** Extra class on the rendered `StateMessage`, for viewer-owned styling hooks. */
    readonly statusClassName?: string;
    /** Replace the `StateMessage` bridge with a viewer-owned status renderer. */
    readonly renderStatus?: (status: SurfaceStatus) => Node;
}
/**
 * Start a result-driven MCP App whose statuses render through the Preact
 * `StateMessage`. Everything else is `startSurfaceApp`; the shell keeps the
 * `mcp-view-preact-surface` class 0.5 viewers style.
 */
export declare function startPreactSurfaceApp<TData, TSession = never>(options: PreactSurfaceAppOptions<TData, TSession>, runtime?: SurfaceAppRuntime): Promise<SurfaceAppHandle<TData>>;
//# sourceMappingURL=surface.d.ts.map