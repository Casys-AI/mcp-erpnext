import type { ActiveContextActions, ActiveContextController, ActiveContextState } from "@mcpview/view/context";
export type { ActiveContextReconcileResult } from "@mcpview/view/context";
/** ACK-confirmed basket, provisional row states and actions for the current root. */
export interface ActiveContextHook extends ActiveContextState, ActiveContextActions {
    retry: ActiveContextController["retry"];
    dismissFailure: ActiveContextController["dismissFailure"];
    dismissEviction: ActiveContextController["dismissEviction"];
}
/**
 * Subscribe to a controller owned outside the render tree. Surface remounts only
 * unsubscribe; they never clear, dispose or recreate the App's context queue.
 * Changing scope invalidates old handlers immediately, then queues the root clear.
 */
export declare function useActiveContext(controller: ActiveContextController, scopeKey: string): ActiveContextHook;
//# sourceMappingURL=use-active-context.d.ts.map