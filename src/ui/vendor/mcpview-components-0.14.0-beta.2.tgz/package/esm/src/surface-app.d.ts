/**
 * Result-driven MCP App over one component registry, renderer-neutral.
 *
 * Every componentized viewer repeats the same lifecycle: install the theme,
 * show a status until the host sends a result, project that result into a
 * data model, mount the host-selected surface, remount it when the host
 * context changes, and make sure only the latest mount survives. Copies of
 * that loop drifted — one lost the generation guard in its error path,
 * another buffered recorded sessions by hand. This module is the loop, once.
 * Renderers plug in through `renderStatus`; `startPreactSurfaceApp` binds it
 * to the Preact `StateMessage`.
 */
import { type AppConfig, type AppContext, createMcpApp } from "@mcpview/view";
import { type ComponentSurface, type ViewComponentRegistry } from "./components.js";
import type { ComponentTone } from "./component-primitives.js";
import { type McpViewMessages, type Translator } from "./i18n.js";
export type SurfaceLabel = string | ((locale?: string) => string);
export interface SurfaceAppState<TData> {
    currentData?: TData;
}
export type SurfaceAppContext<TData> = AppContext<SurfaceAppState<TData>>;
/** The host tool result exactly as `createMcpApp` delivers it. */
export type SurfaceToolResult = Parameters<NonNullable<AppConfig<SurfaceAppState<unknown>>["onToolResult"]>>[0];
type HostApp = AppContext<SurfaceAppState<unknown>>["app"];
/** The server reads an App may need while projecting a result or a session. */
export interface SurfaceHostAccess {
    /** Presentation locale at projection time, never an input to domain validation. */
    readonly locale?: string;
    readonly readServerResource: (uri: string) => ReturnType<HostApp["readServerResource"]>;
}
export type SurfaceStatusTone = ComponentTone;
/**
 * What the App displays. `result` mounts the component surface; every other
 * kind renders one status through `renderStatus`. `notice` carries a
 * caller-owned presentation for domain states such as "recorded evidence
 * unresolved" that are neither an error nor an absence of data. `code` is a
 * caller-owned machine identifier, forwarded verbatim to the status.
 * `error` and `notice` `title`/`message` accept `SurfaceLabel` callbacks,
 * resolved on each visible status render; literal strings stay unchanged.
 */
export type SurfaceDisplayState<TData> = {
    readonly kind: "loading";
} | {
    readonly kind: "empty";
} | {
    readonly kind: "error";
    readonly message: SurfaceLabel;
    readonly title?: SurfaceLabel;
    readonly code?: string;
} | {
    readonly kind: "notice";
    readonly message: SurfaceLabel;
    readonly title?: SurfaceLabel;
    readonly tone?: SurfaceStatusTone;
    readonly busy?: boolean;
    readonly code?: string;
} | {
    readonly kind: "result";
    readonly result: TData;
};
export type SurfaceMessageKind = "loading" | "empty" | "error" | "notice" | "surface-required";
/** One status resolved to its presentation, ready for a renderer. */
export interface SurfaceStatus {
    readonly kind: SurfaceMessageKind;
    readonly message: string;
    readonly title?: string;
    readonly tone: SurfaceStatusTone;
    readonly busy: boolean;
    /** Caller-owned identifier from a `notice` or `error` state, never invented. */
    readonly code?: string;
}
export type SurfaceProjection<TInput, TData> = (input: TInput, host: SurfaceHostAccess) => SurfaceDisplayState<TData> | Promise<SurfaceDisplayState<TData>>;
/** Whole-view `viewer.session.apply` handling, installed before the App connects. */
export interface SurfaceViewerSession<TData, TSession> {
    readonly validate: (value: unknown) => value is TSession;
    /** Project one validated session exactly as a tool result would be. */
    readonly toState: SurfaceProjection<TSession, TData>;
    readonly onInvalid?: (value: unknown) => void;
}
export interface SurfaceAppOptions<TData, TSession = never> {
    readonly root: HTMLElement;
    readonly info: {
        readonly name: string;
        readonly version: string;
    };
    readonly registry: ViewComponentRegistry<TData, SurfaceAppContext<TData>>;
    /**
     * Project one host tool result into a display state. Without it the result's
     * structured content (or JSON text) is the data, checked by `validate`.
     *
     * A throw becomes an `error` status and drops the remembered result, like
     * any non-`result` state. To keep the last values visible under a failure,
     * return a `result` state that carries the failure — the scaffold does.
     */
    readonly fromToolResult?: SurfaceProjection<SurfaceToolResult, TData>;
    /** Domain guard for the default projection. Exclusive with `fromToolResult`. */
    readonly validate?: (value: unknown) => value is TData;
    readonly viewerSession?: SurfaceViewerSession<TData, TSession>;
    /**
     * The surface a result owns. A returned surface composes that result as is:
     * neither the host selection nor the registry default is consulted, so a
     * recorded session that replaces the whole read model can compose itself.
     * `undefined` keeps the host flow (host-selected surface, then the registry
     * default). Called on every mount of the result, remounts included.
     */
    readonly surfaceFor?: (data: TData) => ComponentSurface | undefined;
    /** Detail of the `loading` status. Default `Waiting for data…`. */
    readonly loadingLabel?: SurfaceLabel;
    /** Detail of the `empty` status. Default `No structured data received.`. */
    readonly emptyLabel?: SurfaceLabel;
    /**
     * Detail of the `surface-required` status. Default
     * `This App exposes components and requires a host-selected surface.`.
     */
    readonly surfaceRequiredLabel?: SurfaceLabel;
    /** Translate interface wording only; domain messages and codes remain caller-owned. */
    readonly messages?: (locale?: string) => Translator<keyof McpViewMessages>;
    /**
     * Sets `document.documentElement.lang` at boot and when the host locale
     * changes. Pass `messages.locale` from `createTranslator` so the document
     * language identifies the selected dictionary. Omit to leave `lang` as is.
     * Independent of remount policy; not inferred from message callbacks.
     */
    readonly documentLanguage?: (hostLocale?: string) => string;
    /**
     * Opt into in-place theme-only updates when components follow CSS tokens (or
     * observe them, e.g. a 3D scene). Other context changes still remount the surface.
     * Default `remount` preserves components that read the theme only at mount.
     * In-place mode compares non-theme fields structurally so equal JSON snapshots
     * with new object identities do not remount.
     */
    readonly themeUpdates?: "remount" | "in-place";
    /** Class of the element wrapping the mounted surface. Default `mcp-view-surface-shell`. */
    readonly surfaceClassName?: string;
    /**
     * Install the shared mcp-view stylesheet at boot. Default `true`. Only the
     * boot install is skipped: kit primitives still install it when they mount,
     * and the host theme (`createMcpApp`'s `autoTheme`) is unaffected.
     */
    readonly theme?: boolean;
    /** Forwarded to `createMcpApp`; unset keeps its default (`false`). */
    readonly strict?: boolean;
    /** Render one resolved status as the element the router mounts. */
    readonly renderStatus: (status: SurfaceStatus) => Node;
    /** Receives every failure the lifecycle absorbs. Default `console.error`. */
    readonly onError?: (error: unknown) => void;
    /**
     * Runs once when the host tears the App down or `dispose()` runs, before
     * the router disposes the surface. For what the App holds outside its
     * surface — a bridge to the parent page, a subscription — since the handle
     * has no other end-of-life signal. A throw is absorbed through `onError`.
     */
    readonly onTeardown?: () => void | Promise<void>;
}
export interface SurfaceAppHandle<TData> {
    /**
     * Route one display state exactly as a host tool result would be. Rejects
     * with `SURFACE_APP_CLOSED` once the host tore the App down or `dispose()`
     * ran: there is no router left to show anything.
     */
    show(state: SurfaceDisplayState<TData>): Promise<void>;
    /** Manual disposal. Host teardown needs no call. */
    dispose(): Promise<void>;
}
/**
 * Injection seam for tests that cannot open an ext-apps transport. It is not
 * a production extension point: a viewer never passes it.
 */
export interface SurfaceAppRuntime {
    readonly createApp: typeof createMcpApp;
}
export type SurfaceAppErrorCode = "SURFACE_APP_PROJECTION_CONFLICT" | "SURFACE_APP_CLOSED";
/** Options refused at the boundary. Match on `code`, not on `message`. */
export declare class SurfaceAppError extends TypeError {
    readonly code: SurfaceAppErrorCode;
    readonly data: Readonly<Record<string, unknown>>;
    constructor(code: SurfaceAppErrorCode, message: string, data?: Record<string, unknown>);
}
/**
 * Start a result-driven MCP App backed by a component registry.
 *
 * The registry may expose a default surface or be component-only. In the
 * latter case a host-selected surface is required and no artificial
 * standalone composition is invented.
 */
export declare function startSurfaceApp<TData, TSession = never>(options: SurfaceAppOptions<TData, TSession>, runtime?: SurfaceAppRuntime): Promise<SurfaceAppHandle<TData>>;
export {};
//# sourceMappingURL=surface-app.d.ts.map