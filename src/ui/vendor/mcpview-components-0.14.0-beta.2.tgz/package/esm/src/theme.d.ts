/** Shared light-first visual language for composable MCP App components. */
export declare const MCP_VIEW_THEME_STYLE_ID = "mcp-view-theme";
/** Stable CSS custom-property names available to App-local themes. */
export type McpViewThemeTokens = Readonly<{
    text: "--mcp-view-text";
    muted: "--mcp-view-muted";
    quiet: "--mcp-view-quiet";
    border: "--mcp-view-border";
    panel: "--mcp-view-panel";
    subtle: "--mcp-view-subtle";
    accent: "--mcp-view-accent";
    brand: "--mcp-view-brand";
    success: "--mcp-view-success";
    warning: "--mcp-view-warning";
    danger: "--mcp-view-danger";
    fontHeading: "--mcp-view-font-heading";
    fontBody: "--mcp-view-font-body";
    fontMono: "--mcp-view-font-mono";
    radius: "--mcp-view-radius";
    radiusSmall: "--mcp-view-radius-sm";
    gap: "--mcp-view-gap";
    textSecondary: "--mcp-view-text-secondary";
    ghost: "--mcp-view-ghost";
    borderSoft: "--mcp-view-border-soft";
    borderStrong: "--mcp-view-border-strong";
    hover: "--mcp-view-hover";
    track: "--mcp-view-track";
    accentText: "--mcp-view-accent-text";
    brandText: "--mcp-view-brand-text";
    warningText: "--mcp-view-warning-text";
    radiusControl: "--mcp-view-radius-control";
    sizeMicro: "--mcp-view-size-micro";
    sizeChip: "--mcp-view-size-chip";
    sizeMeta: "--mcp-view-size-meta";
    sizeNote: "--mcp-view-size-note";
    sizeData: "--mcp-view-size-data";
    sizeCell: "--mcp-view-size-cell";
    sizeBody: "--mcp-view-size-body";
    sizeLede: "--mcp-view-size-lede";
    sizeCardTitle: "--mcp-view-size-card-title";
    sizeTotal: "--mcp-view-size-total";
    sizeTitle: "--mcp-view-size-title";
    sizeMetric: "--mcp-view-size-metric";
    trackingLabel: "--mcp-view-tracking-label";
    trackingChip: "--mcp-view-tracking-chip";
    trackingEyebrow: "--mcp-view-tracking-eyebrow";
    trackingTitle: "--mcp-view-tracking-title";
    trackingMetric: "--mcp-view-tracking-metric";
}>;
export declare const MCP_VIEW_THEME_TOKENS: McpViewThemeTokens;
export type McpViewThemeToken = McpViewThemeTokens[keyof McpViewThemeTokens];
/**
 * Compact, container-friendly MCP View v2 defaults. Domain components keep
 * their own semantics while sharing tokens, cards, metrics, tables, badges
 * and explicit system states. Every token can be overridden by the host.
 */
export declare const MCP_VIEW_THEME_CSS: string;
export interface McpViewThemeDocument {
    readonly head: Pick<HTMLElement, "append">;
    getElementById(id: string): HTMLElement | null;
    createElement(tagName: "style"): HTMLStyleElement;
}
/** Install the shared theme once in the current MCP App document. */
export declare function installMcpViewTheme(target?: McpViewThemeDocument): HTMLStyleElement;
//# sourceMappingURL=theme.d.ts.map