"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MCP_VIEW_FONTS_STYLE_ID = exports.MCP_VIEW_FONTS_CSS = exports.MCP_VIEW_FONT_FAMILIES = exports.installMcpViewFonts = void 0;
/**
 * Embedded webfaces for the shared theme.
 *
 * Import as `@mcpview/components/fonts`. Opt-in and ~140 KB: a viewer
 * that must render identically inside a host iframe without network access
 * calls `installMcpViewFonts()` next to `installMcpViewTheme()`; one that can
 * rely on system faces leaves this entry out of its bundle.
 *
 * @module
 */
require("./_dnt.polyfills.js");
var fonts_js_1 = require("./src/fonts.js");
Object.defineProperty(exports, "installMcpViewFonts", { enumerable: true, get: function () { return fonts_js_1.installMcpViewFonts; } });
Object.defineProperty(exports, "MCP_VIEW_FONT_FAMILIES", { enumerable: true, get: function () { return fonts_js_1.MCP_VIEW_FONT_FAMILIES; } });
Object.defineProperty(exports, "MCP_VIEW_FONTS_CSS", { enumerable: true, get: function () { return fonts_js_1.MCP_VIEW_FONTS_CSS; } });
Object.defineProperty(exports, "MCP_VIEW_FONTS_STYLE_ID", { enumerable: true, get: function () { return fonts_js_1.MCP_VIEW_FONTS_STYLE_ID; } });
