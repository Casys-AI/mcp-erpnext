"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Responsive viewer layout for `@mcpview/components` Apps.
 *
 * Import as `@mcpview/components/layout`. The decision
 * (`resolveViewerLayout`, `layoutWidth`, `touchInput`, `viewerBoundsStyle`) is
 * pure; the Preact hooks (`useViewerLayout`, `useContainerWidth`,
 * `useCoarsePointer`) measure the DOM but take the host context as a
 * parameter, so this entry loads no MCP Apps runtime.
 *
 * @module
 */
require("./_dnt.polyfills.js");
__exportStar(require("./src/layout/mod.js"), exports);
