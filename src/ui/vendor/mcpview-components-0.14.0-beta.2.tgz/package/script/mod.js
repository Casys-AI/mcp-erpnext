"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mcpViewMessages = exports.MCP_VIEW_MESSAGES_FR = exports.MCP_VIEW_MESSAGES_EN = exports.createTranslator = exports.MCP_VIEW_THEME_TOKENS = exports.MCP_VIEW_THEME_STYLE_ID = exports.MCP_VIEW_THEME_CSS = exports.installMcpViewTheme = exports.defineStatusComponent = exports.defineMetricGridComponent = exports.defineKeyValueComponent = exports.defineCustomComponent = exports.readSurfaceContext = exports.mountComponentSurface = exports.defineViewComponent = exports.defineComponentSurface = exports.defineComponentRegistry = exports.componentCatalogCapabilities = exports.CASYS_SURFACE_CONTEXT_KEY = exports.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY = exports.applySurfaceContext = exports.advertisedComponentCatalog = exports.activeComponentSurface = void 0;
/**
 * `@mcpview/components` — optional presentation runtime for small composable viewers.
 *
 * The root stays renderer-neutral and carries no MCP Apps runtime. Import the
 * App lifecycle from `/surface`, Preact bindings from `/preact` or pure Preact
 * presentation primitives from `/preact/components`.
 *
 * @module
 */
require("./_dnt.polyfills.js");
var components_js_1 = require("./src/components.js");
Object.defineProperty(exports, "activeComponentSurface", { enumerable: true, get: function () { return components_js_1.activeComponentSurface; } });
Object.defineProperty(exports, "advertisedComponentCatalog", { enumerable: true, get: function () { return components_js_1.advertisedComponentCatalog; } });
Object.defineProperty(exports, "applySurfaceContext", { enumerable: true, get: function () { return components_js_1.applySurfaceContext; } });
Object.defineProperty(exports, "CASYS_COMPONENT_CATALOG_CAPABILITY_KEY", { enumerable: true, get: function () { return components_js_1.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY; } });
Object.defineProperty(exports, "CASYS_SURFACE_CONTEXT_KEY", { enumerable: true, get: function () { return components_js_1.CASYS_SURFACE_CONTEXT_KEY; } });
Object.defineProperty(exports, "componentCatalogCapabilities", { enumerable: true, get: function () { return components_js_1.componentCatalogCapabilities; } });
Object.defineProperty(exports, "defineComponentRegistry", { enumerable: true, get: function () { return components_js_1.defineComponentRegistry; } });
Object.defineProperty(exports, "defineComponentSurface", { enumerable: true, get: function () { return components_js_1.defineComponentSurface; } });
Object.defineProperty(exports, "defineViewComponent", { enumerable: true, get: function () { return components_js_1.defineViewComponent; } });
Object.defineProperty(exports, "mountComponentSurface", { enumerable: true, get: function () { return components_js_1.mountComponentSurface; } });
Object.defineProperty(exports, "readSurfaceContext", { enumerable: true, get: function () { return components_js_1.readSurfaceContext; } });
var component_primitives_js_1 = require("./src/component-primitives.js");
Object.defineProperty(exports, "defineCustomComponent", { enumerable: true, get: function () { return component_primitives_js_1.defineCustomComponent; } });
Object.defineProperty(exports, "defineKeyValueComponent", { enumerable: true, get: function () { return component_primitives_js_1.defineKeyValueComponent; } });
Object.defineProperty(exports, "defineMetricGridComponent", { enumerable: true, get: function () { return component_primitives_js_1.defineMetricGridComponent; } });
Object.defineProperty(exports, "defineStatusComponent", { enumerable: true, get: function () { return component_primitives_js_1.defineStatusComponent; } });
var theme_js_1 = require("./src/theme.js");
Object.defineProperty(exports, "installMcpViewTheme", { enumerable: true, get: function () { return theme_js_1.installMcpViewTheme; } });
Object.defineProperty(exports, "MCP_VIEW_THEME_CSS", { enumerable: true, get: function () { return theme_js_1.MCP_VIEW_THEME_CSS; } });
Object.defineProperty(exports, "MCP_VIEW_THEME_STYLE_ID", { enumerable: true, get: function () { return theme_js_1.MCP_VIEW_THEME_STYLE_ID; } });
Object.defineProperty(exports, "MCP_VIEW_THEME_TOKENS", { enumerable: true, get: function () { return theme_js_1.MCP_VIEW_THEME_TOKENS; } });
var i18n_js_1 = require("./src/i18n.js");
Object.defineProperty(exports, "createTranslator", { enumerable: true, get: function () { return i18n_js_1.createTranslator; } });
Object.defineProperty(exports, "MCP_VIEW_MESSAGES_EN", { enumerable: true, get: function () { return i18n_js_1.MCP_VIEW_MESSAGES_EN; } });
Object.defineProperty(exports, "MCP_VIEW_MESSAGES_FR", { enumerable: true, get: function () { return i18n_js_1.MCP_VIEW_MESSAGES_FR; } });
Object.defineProperty(exports, "mcpViewMessages", { enumerable: true, get: function () { return i18n_js_1.mcpViewMessages; } });
