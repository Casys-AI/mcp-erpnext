"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SnippetLibrary = exports.FocusedView = exports.Disclosure = exports.SemanticList = exports.SemanticElement = exports.ElementVerdict = exports.ElementSection = exports.ElementReading = exports.ElementProvenance = exports.ElementLimit = exports.ElementIdent = exports.ElementBody = exports.CollectionCard = exports.Sparkline = exports.SeriesChart = exports.IntervalPlot = exports.TypeBadge = exports.TreeList = exports.StaleBanner = exports.Slot3D = exports.PathBar = exports.PATH_BAR_DEFAULT_MAX_VISIBLE = exports.LimitGauge = exports.DrillHint = exports.ArtifactRow = exports.Toolbar = exports.TextInput = exports.StateMessage = exports.Stack = exports.Skeleton = exports.Row = exports.renderStatusMessage = exports.NoticeGroup = exports.MetricGrid = exports.Metric = exports.Message = exports.KeyValueList = exports.InlineCode = exports.EmptyState = exports.DataTable = exports.CrossSelection = exports.CodeBlock = exports.Card = exports.Button = exports.BadgeGroup = exports.Badge = void 0;
/**
 * Pure Preact presentation primitives for native applications and MCP Apps.
 *
 * Unlike `@mcpview/components/preact`, this entry point does not import the MCP
 * Apps lifecycle, iframe transport, surface registry, or postMessage bridge.
 *
 * Import as `@mcpview/components/preact/components`.
 *
 * @module
 */
require("./_dnt.polyfills.js");
var components_js_1 = require("./src/preact/components.js");
Object.defineProperty(exports, "Badge", { enumerable: true, get: function () { return components_js_1.Badge; } });
Object.defineProperty(exports, "BadgeGroup", { enumerable: true, get: function () { return components_js_1.BadgeGroup; } });
Object.defineProperty(exports, "Button", { enumerable: true, get: function () { return components_js_1.Button; } });
Object.defineProperty(exports, "Card", { enumerable: true, get: function () { return components_js_1.Card; } });
Object.defineProperty(exports, "CodeBlock", { enumerable: true, get: function () { return components_js_1.CodeBlock; } });
Object.defineProperty(exports, "CrossSelection", { enumerable: true, get: function () { return components_js_1.CrossSelection; } });
Object.defineProperty(exports, "DataTable", { enumerable: true, get: function () { return components_js_1.DataTable; } });
Object.defineProperty(exports, "EmptyState", { enumerable: true, get: function () { return components_js_1.EmptyState; } });
Object.defineProperty(exports, "InlineCode", { enumerable: true, get: function () { return components_js_1.InlineCode; } });
Object.defineProperty(exports, "KeyValueList", { enumerable: true, get: function () { return components_js_1.KeyValueList; } });
Object.defineProperty(exports, "Message", { enumerable: true, get: function () { return components_js_1.Message; } });
Object.defineProperty(exports, "Metric", { enumerable: true, get: function () { return components_js_1.Metric; } });
Object.defineProperty(exports, "MetricGrid", { enumerable: true, get: function () { return components_js_1.MetricGrid; } });
Object.defineProperty(exports, "NoticeGroup", { enumerable: true, get: function () { return components_js_1.NoticeGroup; } });
Object.defineProperty(exports, "renderStatusMessage", { enumerable: true, get: function () { return components_js_1.renderStatusMessage; } });
Object.defineProperty(exports, "Row", { enumerable: true, get: function () { return components_js_1.Row; } });
Object.defineProperty(exports, "Skeleton", { enumerable: true, get: function () { return components_js_1.Skeleton; } });
Object.defineProperty(exports, "Stack", { enumerable: true, get: function () { return components_js_1.Stack; } });
Object.defineProperty(exports, "StateMessage", { enumerable: true, get: function () { return components_js_1.StateMessage; } });
Object.defineProperty(exports, "TextInput", { enumerable: true, get: function () { return components_js_1.TextInput; } });
Object.defineProperty(exports, "Toolbar", { enumerable: true, get: function () { return components_js_1.Toolbar; } });
var structural_js_1 = require("./src/preact/structural.js");
Object.defineProperty(exports, "ArtifactRow", { enumerable: true, get: function () { return structural_js_1.ArtifactRow; } });
Object.defineProperty(exports, "DrillHint", { enumerable: true, get: function () { return structural_js_1.DrillHint; } });
Object.defineProperty(exports, "LimitGauge", { enumerable: true, get: function () { return structural_js_1.LimitGauge; } });
Object.defineProperty(exports, "PATH_BAR_DEFAULT_MAX_VISIBLE", { enumerable: true, get: function () { return structural_js_1.PATH_BAR_DEFAULT_MAX_VISIBLE; } });
Object.defineProperty(exports, "PathBar", { enumerable: true, get: function () { return structural_js_1.PathBar; } });
Object.defineProperty(exports, "Slot3D", { enumerable: true, get: function () { return structural_js_1.Slot3D; } });
Object.defineProperty(exports, "StaleBanner", { enumerable: true, get: function () { return structural_js_1.StaleBanner; } });
Object.defineProperty(exports, "TreeList", { enumerable: true, get: function () { return structural_js_1.TreeList; } });
Object.defineProperty(exports, "TypeBadge", { enumerable: true, get: function () { return structural_js_1.TypeBadge; } });
var plots_js_1 = require("./src/preact/plots.js");
Object.defineProperty(exports, "IntervalPlot", { enumerable: true, get: function () { return plots_js_1.IntervalPlot; } });
Object.defineProperty(exports, "SeriesChart", { enumerable: true, get: function () { return plots_js_1.SeriesChart; } });
Object.defineProperty(exports, "Sparkline", { enumerable: true, get: function () { return plots_js_1.Sparkline; } });
var semantic_element_js_1 = require("./src/preact/semantic-element.js");
Object.defineProperty(exports, "CollectionCard", { enumerable: true, get: function () { return semantic_element_js_1.CollectionCard; } });
Object.defineProperty(exports, "ElementBody", { enumerable: true, get: function () { return semantic_element_js_1.ElementBody; } });
Object.defineProperty(exports, "ElementIdent", { enumerable: true, get: function () { return semantic_element_js_1.ElementIdent; } });
Object.defineProperty(exports, "ElementLimit", { enumerable: true, get: function () { return semantic_element_js_1.ElementLimit; } });
Object.defineProperty(exports, "ElementProvenance", { enumerable: true, get: function () { return semantic_element_js_1.ElementProvenance; } });
Object.defineProperty(exports, "ElementReading", { enumerable: true, get: function () { return semantic_element_js_1.ElementReading; } });
Object.defineProperty(exports, "ElementSection", { enumerable: true, get: function () { return semantic_element_js_1.ElementSection; } });
Object.defineProperty(exports, "ElementVerdict", { enumerable: true, get: function () { return semantic_element_js_1.ElementVerdict; } });
Object.defineProperty(exports, "SemanticElement", { enumerable: true, get: function () { return semantic_element_js_1.SemanticElement; } });
Object.defineProperty(exports, "SemanticList", { enumerable: true, get: function () { return semantic_element_js_1.SemanticList; } });
var focused_view_js_1 = require("./src/preact/focused-view.js");
Object.defineProperty(exports, "Disclosure", { enumerable: true, get: function () { return focused_view_js_1.Disclosure; } });
Object.defineProperty(exports, "FocusedView", { enumerable: true, get: function () { return focused_view_js_1.FocusedView; } });
var snippet_library_js_1 = require("./src/preact/snippet-library.js");
Object.defineProperty(exports, "SnippetLibrary", { enumerable: true, get: function () { return snippet_library_js_1.SnippetLibrary; } });
// The stylesheet and its types ship from the package root with
// `installMcpViewTheme`, never from this entry. Re-exporting them here handed
// the whole sheet to every caller that only wanted one component: the theme is
// an explicit install, so it must cost an explicit import.
