"use strict";
/** Small, framework-neutral UI components reusable across MCP Apps. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.defineStatusComponent = defineStatusComponent;
exports.defineMetricGridComponent = defineMetricGridComponent;
exports.defineKeyValueComponent = defineKeyValueComponent;
exports.defineCustomComponent = defineCustomComponent;
const components_js_1 = require("./components.js");
const theme_js_1 = require("./theme.js");
/** One compact status block with a semantic tone and optional detail. */
function defineStatusComponent(config) {
    return (0, components_js_1.defineViewComponent)({
        descriptor: descriptor(config),
        mount(target, context) {
            const value = config.select(context.data);
            (0, theme_js_1.installMcpViewTheme)(target.ownerDocument);
            target.dataset.primitive = "status";
            target.dataset.tone = value.tone ?? "neutral";
            const label = element("strong", value.label);
            label.style.fontSize = "1rem";
            target.append(label);
            if (value.detail)
                target.append(element("span", value.detail));
            applyCard(target);
            target.style.display = "flex";
            target.style.alignItems = "center";
            target.style.justifyContent = "space-between";
            target.style.gap = "0.75rem";
            target.classList.add("mcp-view-card", "mcp-view-row");
        },
    });
}
/** Responsive metric cards; formatting remains owned by the domain selector. */
function defineMetricGridComponent(config) {
    return (0, components_js_1.defineViewComponent)({
        descriptor: descriptor(config),
        mount(target, context) {
            (0, theme_js_1.installMcpViewTheme)(target.ownerDocument);
            target.dataset.primitive = "metric-grid";
            target.classList.add("mcp-view-metrics");
            target.style.display = "grid";
            target.style.gridTemplateColumns = "repeat(auto-fit, minmax(9rem, 1fr))";
            target.style.gap = "0.5rem";
            for (const metric of config.select(context.data)) {
                const card = document.createElement("article");
                card.dataset.metric = metric.id;
                applyCard(card);
                card.classList.add("mcp-view-metric");
                const label = element("span", metric.label);
                label.classList.add("mcp-view-metric-label");
                label.style.fontSize = "0.75rem";
                label.style.opacity = "0.72";
                const value = element("strong", String(metric.value));
                value.classList.add("mcp-view-metric-value");
                value.style.fontSize = "1.25rem";
                value.style.overflowWrap = "anywhere";
                card.append(label, value);
                if (metric.unit) {
                    const unit = element("span", metric.unit);
                    unit.classList.add("mcp-view-metric-unit");
                    card.append(unit);
                }
                if (metric.detail) {
                    const detail = element("small", metric.detail);
                    detail.style.opacity = "0.72";
                    card.append(detail);
                }
                card.style.display = "grid";
                card.style.gap = "0.2rem";
                target.append(card);
            }
        },
    });
}
/** Semantic definition list for provenance, identity, and other compact facts. */
function defineKeyValueComponent(config) {
    return (0, components_js_1.defineViewComponent)({
        descriptor: descriptor(config),
        mount(target, context) {
            (0, theme_js_1.installMcpViewTheme)(target.ownerDocument);
            target.dataset.primitive = "key-value";
            const list = document.createElement("dl");
            list.style.display = "grid";
            list.style.gridTemplateColumns = "minmax(7rem, auto) minmax(0, 1fr)";
            list.style.gap = "0.4rem 0.75rem";
            list.style.margin = "0";
            for (const item of config.select(context.data)) {
                const term = element("dt", item.label);
                term.dataset.key = item.key;
                term.style.opacity = "0.72";
                const detail = element("dd", item.value === null ? "—" : String(item.value));
                detail.style.margin = "0";
                detail.style.overflowWrap = "anywhere";
                list.append(term, detail);
            }
            target.append(list);
            applyCard(target);
        },
    });
}
/** A custom component factory with the same descriptor convention as primitives. */
function defineCustomComponent(config) {
    return (0, components_js_1.defineViewComponent)({
        descriptor: descriptor(config),
        mount: config.mount,
    });
}
function descriptor(config) {
    return {
        title: config.title,
        ...(config.description ? { description: config.description } : {}),
        ...(config.events ? { events: config.events } : {}),
    };
}
function element(tag, text) {
    const node = document.createElement(tag);
    node.textContent = text;
    return node;
}
function applyCard(target) {
    target.classList.add("mcp-view-card");
    target.style.padding = "0.75rem";
    target.style.border = "1px solid var(--color-border, rgba(127, 127, 127, 0.28))";
    target.style.borderRadius = "0.5rem";
    target.style.background = "var(--color-background-secondary, rgba(127, 127, 127, 0.08))";
    target.style.minWidth = "0";
}
