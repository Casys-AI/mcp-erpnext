"use strict";
/** Renderer-neutral component catalog and surface runtime for MCP Apps. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.readSurfaceContext = exports.CASYS_SURFACE_CONTEXT_KEY = exports.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY = void 0;
exports.defineViewComponent = defineViewComponent;
exports.defineComponentRegistry = defineComponentRegistry;
exports.defineComponentSurface = defineComponentSurface;
exports.componentCatalogCapabilities = componentCatalogCapabilities;
exports.advertisedComponentCatalog = advertisedComponentCatalog;
exports.applySurfaceContext = applySurfaceContext;
exports.activeComponentSurface = activeComponentSurface;
exports.mountComponentSurface = mountComponentSurface;
const contracts_1 = require("@mcpview/contracts");
var contracts_2 = require("@mcpview/contracts");
Object.defineProperty(exports, "CASYS_COMPONENT_CATALOG_CAPABILITY_KEY", { enumerable: true, get: function () { return contracts_2.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY; } });
Object.defineProperty(exports, "CASYS_SURFACE_CONTEXT_KEY", { enumerable: true, get: function () { return contracts_2.CASYS_SURFACE_CONTEXT_KEY; } });
Object.defineProperty(exports, "readSurfaceContext", { enumerable: true, get: function () { return contracts_2.readSurfaceContext; } });
function defineViewComponent(definition) {
    const descriptor = normalizedDescriptor(definition.descriptor);
    if (typeof definition.mount !== "function") {
        throw new TypeError("View component must declare a mount function");
    }
    return Object.freeze({ ...definition, descriptor });
}
function defineComponentRegistry(registry) {
    const entries = Object.entries(registry.components ?? {});
    if (entries.length === 0) {
        throw new TypeError("Component registry must declare at least one component");
    }
    for (const [id, component] of entries) {
        validateComponentId(id, "Component registry key");
        validateDescriptor(component.descriptor);
        if (typeof component.mount !== "function") {
            throw new TypeError(`Component ${JSON.stringify(id)} must declare a mount function`);
        }
    }
    const surface = registry.defaultSurface === undefined
        ? undefined
        : defineComponentSurface(registry.defaultSurface);
    if (surface) {
        validateSurfaceComponents(surface, new Set(entries.map(([id]) => id)));
    }
    Object.freeze(registry.components);
    return Object.freeze({
        ...registry,
        ...(surface ? { defaultSurface: surface } : {}),
    });
}
function defineComponentSurface(surface) {
    validateLayout(surface?.layout);
    if (!Array.isArray(surface?.components) || surface.components.length === 0) {
        throw new TypeError("Component surface must contain at least one component");
    }
    const instanceIds = new Set();
    const components = surface.components.map((item) => {
        validateComponentId(item.id, "Surface component id");
        validateComponentId(item.component, "Surface component key");
        if (instanceIds.has(item.id)) {
            throw new TypeError(`Duplicate surface component id ${JSON.stringify(item.id)}`);
        }
        instanceIds.add(item.id);
        if (item.area !== undefined && !/^[A-Za-z][A-Za-z0-9_-]*$/.test(item.area)) {
            throw new TypeError(`Invalid surface grid area ${JSON.stringify(item.area)}`);
        }
        if (item.props !== undefined)
            validateJsonValue(item.props, `props for ${item.id}`);
        return Object.freeze({
            ...item,
            ...(item.props ? { props: Object.freeze({ ...item.props }) } : {}),
        });
    });
    return Object.freeze({
        layout: Object.freeze({ ...surface.layout }),
        components: Object.freeze(components),
    });
}
/** Build the serializable value advertised in `AppConfig.capabilities.experimental`. */
function componentCatalogCapabilities(registry) {
    return {
        [contracts_1.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY]: advertisedComponentCatalog(registry),
    };
}
function advertisedComponentCatalog(registry) {
    const components = Object.fromEntries(Object.entries(registry.components).map(([id, definition]) => [
        id,
        normalizedDescriptor(definition.descriptor),
    ]));
    return Object.freeze({
        components: Object.freeze(components),
        ...(registry.defaultSurface ? { defaultSurface: registry.defaultSurface } : {}),
    });
}
/** Expose only surface identity/status for CSS and diagnostics, never component internals. */
function applySurfaceContext(hostContext, target) {
    const surface = (0, contracts_1.readSurfaceContext)(hostContext);
    assignDataset(target.dataset, "casysSurfaceInstance", surface?.instanceId);
    assignDataset(target.dataset, "casysSurfaceStatus", surface?.status);
    assignDataset(target.dataset, "casysSurfaceSource", surface?.source);
}
function activeComponentSurface(registry, hostContext) {
    const context = (0, contracts_1.readSurfaceContext)(hostContext);
    return context?.status === "ready" && context.surface
        ? defineComponentSurface(context.surface)
        : registry.defaultSurface;
}
/** Mount one declarative surface and return deterministic aggregate cleanup. */
async function mountComponentSurface(options) {
    const selected = options.surface ??
        activeComponentSurface(options.registry, options.hostContext);
    if (!selected) {
        throw new TypeError("Component-only App requires a host-selected surface");
    }
    const surface = defineComponentSurface(selected);
    validateSurfaceComponents(surface, new Set(Object.keys(options.registry.components)));
    const container = document.createElement("div");
    container.className = `mcp-view-surface mcp-view-surface-${surface.layout.type}`;
    container.dataset.surfaceLayout = surface.layout.type;
    applySurfaceLayout(container, surface.layout);
    const cleanups = [];
    try {
        for (const item of surface.components) {
            const definition = options.registry.components[item.component];
            const slot = document.createElement("section");
            slot.className = "mcp-view-component";
            slot.dataset.component = item.component;
            slot.dataset.componentId = item.id;
            if (item.area)
                slot.style.gridArea = item.area;
            container.append(slot);
            const cleanup = await definition.mount(slot, {
                data: options.data,
                props: item.props ?? {},
                instanceId: item.id,
                appContext: options.appContext,
                hostContext: options.hostContext,
            });
            if (typeof cleanup === "function")
                cleanups.push(cleanup);
        }
    }
    catch (error) {
        await disposeAll(cleanups);
        throw error;
    }
    options.root.replaceChildren(container);
    let disposed = false;
    return {
        surface,
        async dispose() {
            if (disposed)
                return;
            disposed = true;
            await disposeAll(cleanups);
            if (container.parentNode === options.root)
                options.root.replaceChildren();
        },
    };
}
function applySurfaceLayout(target, layout) {
    const gaps = {
        none: "0",
        xs: "0.25rem",
        sm: "0.5rem",
        md: "1rem",
        lg: "1.5rem",
    };
    target.style.display = "grid";
    // Stacked components are separated by the theme's hairlines; rows and grids keep a gap.
    target.style.gap = gaps[layout.gap ?? (layout.type === "stack" ? "none" : "md")];
    target.style.minWidth = "0";
    if (layout.type === "row") {
        target.style.gridAutoFlow = "column";
        target.style.gridAutoColumns = "minmax(0, 1fr)";
    }
    else if (layout.type === "grid") {
        target.style.gridTemplateColumns = `repeat(${layout.columns ?? 2}, minmax(0, 1fr))`;
    }
    else {
        target.style.gridTemplateColumns = "minmax(0, 1fr)";
    }
}
function validateLayout(layout) {
    if (!layout || !["stack", "row", "grid"].includes(layout.type)) {
        throw new TypeError("Surface layout type must be stack, row, or grid");
    }
    if (layout.columns !== undefined &&
        (!Number.isInteger(layout.columns) || layout.columns < 1 || layout.columns > 12)) {
        throw new TypeError("Surface grid columns must be an integer from 1 to 12");
    }
    if (layout.type !== "grid" && layout.columns !== undefined) {
        throw new TypeError("Surface columns are valid only for grid layouts");
    }
    if (layout.gap !== undefined && !["none", "xs", "sm", "md", "lg"].includes(layout.gap)) {
        throw new TypeError("Surface gap must be none, xs, sm, md, or lg");
    }
}
function validateSurfaceComponents(surface, known) {
    const missing = [
        ...new Set(surface.components
            .map((item) => item.component)
            .filter((component) => !known.has(component))),
    ];
    if (missing.length > 0) {
        throw new TypeError(`Unknown surface components: ${missing.join(", ")}`);
    }
}
function validateDescriptor(descriptor) {
    if (!descriptor || typeof descriptor.title !== "string" || !descriptor.title.trim()) {
        throw new TypeError("View component descriptor must have a non-empty title");
    }
    if (descriptor.description !== undefined && typeof descriptor.description !== "string") {
        throw new TypeError("View component description must be a string");
    }
    validateEventPorts(descriptor.events);
}
function normalizedDescriptor(descriptor) {
    validateDescriptor(descriptor);
    const events = descriptor.events === undefined ? undefined : Object.freeze({
        ...(descriptor.events.emits ? { emits: Object.freeze([...descriptor.events.emits]) } : {}),
        ...(descriptor.events.accepts
            ? { accepts: Object.freeze([...descriptor.events.accepts]) }
            : {}),
    });
    return Object.freeze({
        title: descriptor.title,
        ...(descriptor.description !== undefined ? { description: descriptor.description } : {}),
        ...(events ? { events } : {}),
    });
}
function validateEventPorts(ports) {
    if (ports === undefined)
        return;
    if (!ports || typeof ports !== "object" || Array.isArray(ports)) {
        throw new TypeError("View component events must be an object");
    }
    validateEventNames(ports.emits, "emits");
    validateEventNames(ports.accepts, "accepts");
}
function validateEventNames(names, field) {
    if (names === undefined)
        return;
    if (!Array.isArray(names)) {
        throw new TypeError(`View component ${field} must be an array`);
    }
    const seen = new Set();
    for (const name of names) {
        if (typeof name !== "string" || !name.trim()) {
            throw new TypeError(`View component ${field} names must be non-empty strings`);
        }
        if (seen.has(name)) {
            throw new TypeError(`Duplicate View component ${field} name ${JSON.stringify(name)}`);
        }
        seen.add(name);
    }
}
function validateComponentId(value, label) {
    if (typeof value !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._:/-]*$/.test(value)) {
        throw new TypeError(`${label} is invalid: ${JSON.stringify(value)}`);
    }
}
function validateJsonValue(value, label) {
    if (value === null || typeof value === "string" || typeof value === "boolean" ||
        (typeof value === "number" && Number.isFinite(value)))
        return;
    if (Array.isArray(value)) {
        for (const entry of value)
            validateJsonValue(entry, label);
        return;
    }
    if (value && typeof value === "object") {
        for (const entry of Object.values(value))
            validateJsonValue(entry, label);
        return;
    }
    throw new TypeError(`${label} must contain only JSON values`);
}
async function disposeAll(cleanups) {
    const errors = [];
    for (const cleanup of [...cleanups].reverse()) {
        try {
            await cleanup();
        }
        catch (error) {
            errors.push(error);
        }
    }
    if (errors.length === 1)
        throw errors[0];
    if (errors.length > 1)
        throw new AggregateError(errors, "Component cleanup failed");
}
function assignDataset(dataset, key, value) {
    if (value === undefined)
        delete dataset[key];
    else
        dataset[key] = value;
}
