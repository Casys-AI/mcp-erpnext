"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contextBasketMessages = exports.CONTEXT_BASKET_MESSAGES_FR = exports.CONTEXT_BASKET_MESSAGES_EN = void 0;
exports.contextBasketLabels = contextBasketLabels;
const i18n_js_1 = require("./i18n.js");
/** Interface text only; selection labels and group summaries remain caller data. */
exports.CONTEXT_BASKET_MESSAGES_EN = {
    active: "Active context",
    items: "Context items",
    remove: "Remove {label} from context",
    clearAll: "Clear context",
    pending: "Updating context…",
    error: "Context update failed",
    retry: "Retry",
    evicted: "Removed oldest item: {label}",
};
exports.CONTEXT_BASKET_MESSAGES_FR = {
    active: "Contexte actif",
    items: "Éléments du contexte",
    remove: "Retirer {label} du contexte",
    clearAll: "Vider le contexte",
    pending: "Mise à jour du contexte…",
    error: "Échec de la mise à jour du contexte",
    retry: "Réessayer",
    evicted: "Élément le plus ancien retiré : {label}",
};
exports.contextBasketMessages = (0, i18n_js_1.createTranslator)({
    messages: exports.CONTEXT_BASKET_MESSAGES_EN,
    translations: { fr: exports.CONTEXT_BASKET_MESSAGES_FR },
});
/** Optional EN/FR kit labels. Pass your own labels to customize any interface text. */
function contextBasketLabels(locale) {
    const t = (0, exports.contextBasketMessages)(locale);
    return {
        active: t("active"),
        items: t("items"),
        clearAll: t("clearAll"),
        pending: t("pending"),
        error: t("error"),
        retry: t("retry"),
        remove: (label) => t("remove", { label }),
        evicted: (label) => t("evicted", { label }),
    };
}
