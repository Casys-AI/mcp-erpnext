"use strict";
/** The families the shared theme names first; the generator and the entry share them. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MCP_VIEW_FONT_FAMILIES = void 0;
/**
 * The three families `MCP_VIEW_THEME_CSS` names first in its stacks. The theme
 * falls back to system faces without them; embedding is what keeps a viewer
 * rendering the same inside a host iframe with no network or a strict CSP.
 */
exports.MCP_VIEW_FONT_FAMILIES = [
    { family: "Space Grotesk", weights: "500..600", role: "heading" },
    { family: "Work Sans", weights: "400..500", role: "body" },
    { family: "JetBrains Mono", weights: "400..600", role: "mono" },
];
