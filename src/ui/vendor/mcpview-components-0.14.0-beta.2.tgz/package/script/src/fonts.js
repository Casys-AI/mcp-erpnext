"use strict";
/** Opt-in embedded webfaces for the shared theme. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MCP_VIEW_FONTS_STYLE_ID = exports.MCP_VIEW_FONTS_CSS = exports.MCP_VIEW_FONT_FAMILIES = void 0;
exports.installMcpViewFonts = installMcpViewFonts;
const font_families_js_1 = require("./font-families.js");
Object.defineProperty(exports, "MCP_VIEW_FONT_FAMILIES", { enumerable: true, get: function () { return font_families_js_1.MCP_VIEW_FONT_FAMILIES; } });
const fonts_data_js_1 = require("./fonts-data.js");
Object.defineProperty(exports, "MCP_VIEW_FONTS_CSS", { enumerable: true, get: function () { return fonts_data_js_1.MCP_VIEW_FONTS_CSS; } });
exports.MCP_VIEW_FONTS_STYLE_ID = "mcp-view-fonts";
/**
 * Install the embedded `@font-face` rules once per document. Independent of
 * `installMcpViewTheme`: call both, in either order, for a fully offline viewer.
 */
function installMcpViewFonts(target = document) {
    const existing = target.getElementById(exports.MCP_VIEW_FONTS_STYLE_ID);
    if (existing)
        return existing;
    const style = target.createElement("style");
    style.id = exports.MCP_VIEW_FONTS_STYLE_ID;
    style.textContent = fonts_data_js_1.MCP_VIEW_FONTS_CSS;
    target.head.append(style);
    return style;
}
