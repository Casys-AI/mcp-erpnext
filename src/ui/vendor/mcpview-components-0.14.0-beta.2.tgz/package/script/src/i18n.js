"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mcpViewMessages = exports.MCP_VIEW_MESSAGES_FR = exports.MCP_VIEW_MESSAGES_EN = void 0;
exports.createTranslator = createTranslator;
/**
 * Select messages by exact locale, then language parents, then the base dictionary.
 * Missing entries fall back independently. Invalid host locales use the base locale.
 * Interpolation is plain text; render the returned value as text, never as HTML.
 * `.locale(hostLocale)` uses that same chain and names the dictionary actually selected.
 */
function createTranslator(catalog) {
    const fallback = canonicalLocale(catalog.defaultLocale ?? "en");
    if (!fallback)
        throw new RangeError("Invalid default message locale");
    const base = { ...catalog.messages };
    const translations = new Map();
    for (const [locale, messages] of Object.entries(catalog.translations ?? {})) {
        const normalized = canonicalLocale(locale);
        if (!normalized)
            throw new RangeError(`Invalid message locale: ${locale}`);
        if (translations.has(normalized))
            throw new RangeError(`Duplicate message locale: ${locale}`);
        translations.set(normalized, { ...messages });
    }
    const select = (locale) => {
        const candidates = [];
        for (const current of localeChain(locale, fallback)) {
            const messages = translations.get(current);
            if (messages)
                candidates.push(messages);
        }
        return (key, values) => {
            if (!Object.hasOwn(base, key))
                throw new RangeError(`Unknown message key: ${key}`);
            const translated = candidates.find((messages) => Object.hasOwn(messages, key) && typeof messages[key] === "string")?.[key];
            const message = translated ?? base[key];
            return message.replace(/\{([A-Za-z][A-Za-z0-9_]*)\}/g, (placeholder, name) => values && Object.hasOwn(values, name) ? String(values[name]) : placeholder);
        };
    };
    select.locale = (hostLocale) => {
        for (const current of localeChain(hostLocale, fallback)) {
            if (translations.has(current))
                return current;
        }
        return fallback;
    };
    return select;
}
function localeChain(locale, fallback) {
    const chain = [];
    let current = canonicalLocale(locale ?? "") ?? fallback;
    while (current) {
        chain.push(current);
        const separator = current.lastIndexOf("-");
        current = separator < 0 ? "" : current.slice(0, separator);
    }
    return chain;
}
function canonicalLocale(locale) {
    try {
        return Intl.getCanonicalLocales(locale)[0]?.toLowerCase();
    }
    catch {
        return undefined;
    }
}
/** Interface wording only: contract states and caller messages remain untouched. */
exports.MCP_VIEW_MESSAGES_EN = {
    loadingTitle: "Loading",
    loadingMessage: "Waiting for data…",
    emptyTitle: "Empty",
    emptyMessage: "No structured data received.",
    errorTitle: "Error",
    sessionRejectedTitle: "Session rejected",
    resultRejectedTitle: "Result rejected",
    surfaceRequiredTitle: "Surface required",
    surfaceRequiredMessage: "This App exposes components and requires a host-selected surface.",
    surfaceInvalidTitle: "Surface invalid",
    surfaceInvalidMessage: "The {owner} component surface is invalid: {error}",
    surfaceFailedTitle: "Surface failed",
    surfaceFailedMessage: "Component surface failed: {error}",
};
exports.MCP_VIEW_MESSAGES_FR = {
    loadingTitle: "Chargement",
    loadingMessage: "En attente des données…",
    emptyTitle: "Aucune donnée",
    emptyMessage: "Aucune donnée structurée reçue.",
    errorTitle: "Erreur",
    sessionRejectedTitle: "Session rejetée",
    resultRejectedTitle: "Résultat rejeté",
    surfaceRequiredTitle: "Composition requise",
    surfaceRequiredMessage: "Cette App expose des composants et attend une composition de l’hôte.",
    surfaceInvalidTitle: "Composition invalide",
    surfaceInvalidMessage: "La composition {owner} est invalide : {error}",
    surfaceFailedTitle: "Échec de l’affichage",
    surfaceFailedMessage: "Échec de l’affichage des composants : {error}",
};
/** Extend a locale dictionary through createTranslator; no global locale or mutable registry. */
exports.mcpViewMessages = createTranslator({
    messages: exports.MCP_VIEW_MESSAGES_EN,
    translations: { fr: exports.MCP_VIEW_MESSAGES_FR },
});
