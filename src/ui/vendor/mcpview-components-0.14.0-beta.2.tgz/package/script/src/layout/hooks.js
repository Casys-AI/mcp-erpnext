"use strict";
/**
 * Preact hooks over the layout decision. They measure the DOM and query the
 * browser, but they take the host context as a parameter: nothing here
 * imports `@mcpview/view` or the MCP Apps runtime.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.useContainerWidth = useContainerWidth;
exports.useCoarsePointer = useCoarsePointer;
exports.useViewerLayout = useViewerLayout;
const hooks_1 = require("preact/hooks");
const viewer_layout_js_1 = require("./viewer-layout.js");
/**
 * The observed width of one container, to choose a layout.
 *
 * The container is measured, not the window: a `matchMedia` on the window
 * would call a 380px panel opened in a full-screen browser "wide". The width
 * is `null` until measured, so a caller can tell an unmeasured root from a
 * real width; the decision reads an unknown width as wide — the usual case —
 * rather than flashing the narrow treatment on every first paint.
 *
 * Measurement runs in `useLayoutEffect` so the content box is known before
 * the browser paints. A `useEffect` + ResizeObserver only would paint `wide`
 * for one frame (`isNarrow(null)` is false) and then the real treatment. The
 * content box matches `contentRect` (clientWidth minus paddings); a
 * border-box `getBoundingClientRect` is 2px too wide on a 1px-border shell
 * and would flash the other way when the observer corrected it.
 */
function useContainerWidth() {
    const ref = (0, hooks_1.useRef)(null);
    const [width, setWidth] = (0, hooks_1.useState)(null);
    (0, hooks_1.useLayoutEffect)(() => {
        const element = ref.current;
        if (!element)
            return;
        const measured = contentWidth(element);
        // Unmeasurable: keep `null`. Do not invent 0 — that is narrow and flashes `panel`.
        if (measured !== null)
            setWidth(measured);
        if (typeof ResizeObserver === "undefined")
            return;
        const observer = new ResizeObserver((entries) => {
            const entry = entries[0];
            if (entry)
                setWidth(entry.contentRect.width);
        });
        observer.observe(element);
        return () => observer.disconnect();
    }, []);
    return [ref, width];
}
/**
 * Content width, in the same box as `contentRect` (clientWidth minus paddings).
 *
 * A missing `clientWidth` is not a 0-wide box: linkedom reports `undefined`
 * and a dummy 0×0 rect. Returning 0 would make `isNarrow` true and flash
 * `panel` on the first paint — the flash `null` exists to avoid. Leave that
 * unmeasured (caller skips `setWidth`). A numeric `clientWidth` counts; fall
 * back to `getBoundingClientRect().width` only when `clientWidth` is not a
 * number and the rect is a real (non-zero) layout.
 */
function contentWidth(element) {
    const client = element.clientWidth;
    let box;
    if (typeof client === "number") {
        box = client;
    }
    else {
        const rectWidth = element.getBoundingClientRect?.()?.width;
        if (typeof rectWidth !== "number" || rectWidth === 0)
            return null;
        box = rectWidth;
    }
    if (typeof getComputedStyle !== "function")
        return box;
    const style = getComputedStyle(element);
    return box - (parseFloat(style.paddingLeft) || 0) - (parseFloat(style.paddingRight) || 0);
}
function readCoarsePointer() {
    return typeof matchMedia === "function" && matchMedia("(pointer: coarse)").matches;
}
/**
 * Whether the browser reports a coarse pointer — a finger or a stylus.
 *
 * Browser fallback only: `matchMedia` describes the device showing the
 * window, not the context the host gives the iframe. The host's
 * `deviceCapabilities` win whenever they are declared (see `useViewerLayout`).
 *
 * The initial value is read synchronously so the first paint already has the
 * right treatment: a `useState(false)` that is corrected in `useEffect` would
 * first paint `panel` (stacked rows) and then `mobile` (touch table) — two
 * structures, not two densities of the same table.
 */
function useCoarsePointer() {
    const [coarse, setCoarse] = (0, hooks_1.useState)(readCoarsePointer);
    (0, hooks_1.useEffect)(() => {
        if (typeof matchMedia !== "function")
            return;
        const query = matchMedia("(pointer: coarse)");
        const onChange = (event) => setCoarse(event.matches);
        // A hybrid device switches when the user moves from trackpad to screen.
        query.addEventListener("change", onChange);
        return () => query.removeEventListener("change", onChange);
    }, []);
    return coarse;
}
/**
 * One layout decision for one viewer root: the host's word first, the
 * browser's measure as fallback, an explicit override on top.
 */
function useViewerLayout(hints, options = {}) {
    const [ref, measured] = useContainerWidth();
    const coarse = useCoarsePointer();
    const forced = options.forced !== undefined
        ? options.forced
        : typeof location === "undefined"
            ? null
            : (0, viewer_layout_js_1.layoutFromSearch)(location.search);
    const width = (0, viewer_layout_js_1.layoutWidth)(hints, measured);
    const layout = (0, viewer_layout_js_1.resolveViewerLayout)({
        width,
        touch: (0, viewer_layout_js_1.touchInput)(hints, coarse),
        forced,
    });
    return { ref, width, layout, boundsStyle: (0, viewer_layout_js_1.viewerBoundsStyle)(hints?.containerDimensions) };
}
