"use strict";
/** Responsive viewer layout for `@mcpview/components` Apps. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.useViewerLayout = exports.useContainerWidth = exports.useCoarsePointer = exports.viewerBoundsStyle = exports.VIEWER_LAYOUTS = exports.touchInput = exports.resolveViewerLayout = exports.NARROW_BREAKPOINT = exports.layoutWidth = exports.layoutFromSearch = exports.isNarrow = void 0;
var viewer_layout_js_1 = require("./viewer-layout.js");
Object.defineProperty(exports, "isNarrow", { enumerable: true, get: function () { return viewer_layout_js_1.isNarrow; } });
Object.defineProperty(exports, "layoutFromSearch", { enumerable: true, get: function () { return viewer_layout_js_1.layoutFromSearch; } });
Object.defineProperty(exports, "layoutWidth", { enumerable: true, get: function () { return viewer_layout_js_1.layoutWidth; } });
Object.defineProperty(exports, "NARROW_BREAKPOINT", { enumerable: true, get: function () { return viewer_layout_js_1.NARROW_BREAKPOINT; } });
Object.defineProperty(exports, "resolveViewerLayout", { enumerable: true, get: function () { return viewer_layout_js_1.resolveViewerLayout; } });
Object.defineProperty(exports, "touchInput", { enumerable: true, get: function () { return viewer_layout_js_1.touchInput; } });
Object.defineProperty(exports, "VIEWER_LAYOUTS", { enumerable: true, get: function () { return viewer_layout_js_1.VIEWER_LAYOUTS; } });
Object.defineProperty(exports, "viewerBoundsStyle", { enumerable: true, get: function () { return viewer_layout_js_1.viewerBoundsStyle; } });
var hooks_js_1 = require("./hooks.js");
Object.defineProperty(exports, "useCoarsePointer", { enumerable: true, get: function () { return hooks_js_1.useCoarsePointer; } });
Object.defineProperty(exports, "useContainerWidth", { enumerable: true, get: function () { return hooks_js_1.useContainerWidth; } });
Object.defineProperty(exports, "useViewerLayout", { enumerable: true, get: function () { return hooks_js_1.useViewerLayout; } });
