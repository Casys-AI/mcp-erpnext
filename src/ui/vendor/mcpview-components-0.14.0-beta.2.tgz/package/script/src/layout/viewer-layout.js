"use strict";
/**
 * Responsive layout decision for one MCP App viewer, without Preact or the
 * MCP Apps runtime: every input is a value the caller already holds.
 *
 * A viewer renders inside a host iframe whose width says nothing about the
 * screen, so the decision starts from the width the host grants (or the
 * measured container), never from `matchMedia` on the window. Three
 * treatments exist and they are not a scale of widths: a 380px desktop side
 * panel stacks its rows, a 390px phone keeps its table with 40px touch rows.
 * What separates the two narrow treatments is the pointer, not the space.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.NARROW_BREAKPOINT = exports.VIEWER_LAYOUTS = void 0;
exports.isNarrow = isNarrow;
exports.layoutFromSearch = layoutFromSearch;
exports.layoutWidth = layoutWidth;
exports.touchInput = touchInput;
exports.resolveViewerLayout = resolveViewerLayout;
exports.viewerBoundsStyle = viewerBoundsStyle;
exports.VIEWER_LAYOUTS = Object.freeze(["wide", "panel", "mobile"]);
/** Below this container width the wide treatment gives way to a narrow one. */
exports.NARROW_BREAKPOINT = 480;
/** True once a width is known and it is under the breakpoint. */
function isNarrow(width) {
    return width !== null && width < exports.NARROW_BREAKPOINT;
}
/** `?layout=mobile` in a query string, for reviewing a treatment without the matching device. */
function layoutFromSearch(search) {
    const value = new URLSearchParams(search).get("layout");
    return exports.VIEWER_LAYOUTS.includes(value) ? value : null;
}
/**
 * The width to judge: what the host grants, else what was measured.
 *
 * A declared width describes the room actually given, where a
 * `ResizeObserver` only measures what the iframe happened to take.
 */
function layoutWidth(hints, measured) {
    return positive(hints?.containerDimensions?.width) ??
        positive(hints?.containerDimensions?.maxWidth) ?? measured;
}
/**
 * Whether a finger drives the viewer, by the host's word or the browser's.
 *
 * `touch` alone is not enough: a laptop with a touch screen driven by a mouse
 * declares `touch: true, hover: true` and is no phone. Only a finger without
 * hover justifies 40px targets. When the host says nothing, the browser's
 * coarse-pointer query decides.
 */
function touchInput(hints, browserCoarsePointer) {
    const capabilities = hints?.deviceCapabilities;
    if (capabilities?.touch !== undefined) {
        return capabilities.touch && capabilities.hover !== true;
    }
    return browserCoarsePointer;
}
/**
 * The treatment for these inputs. A tablet under a finger but with room keeps
 * the wide layout: room is what mobile lacks; the finger only chooses between
 * the two narrow treatments.
 */
function resolveViewerLayout(inputs) {
    if (inputs.forced)
        return inputs.forced;
    if (!isNarrow(inputs.width))
        return "wide";
    return inputs.touch ? "mobile" : "panel";
}
/**
 * Bound the root on the host's real container instead of `100vh`. Without a
 * declared height the viewer stays intrinsic and lets the host auto-resize.
 */
function viewerBoundsStyle(dimensions) {
    const height = positive(dimensions?.height);
    if (height !== undefined)
        return { height: `${height}px` };
    const maxHeight = positive(dimensions?.maxHeight);
    return maxHeight !== undefined ? { maxHeight: `${maxHeight}px` } : undefined;
}
function positive(value) {
    return typeof value === "number" && Number.isFinite(value) && value > 0 ? value : undefined;
}
