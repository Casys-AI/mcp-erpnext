"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Stack = Stack;
exports.Row = Row;
exports.Card = Card;
exports.BadgeGroup = BadgeGroup;
exports.Badge = Badge;
exports.Metric = Metric;
exports.MetricGrid = MetricGrid;
exports.KeyValueList = KeyValueList;
exports.DataTable = DataTable;
exports.Button = Button;
exports.TextInput = TextInput;
exports.CodeBlock = CodeBlock;
exports.InlineCode = InlineCode;
exports.Toolbar = Toolbar;
exports.EmptyState = EmptyState;
exports.Skeleton = Skeleton;
exports.Message = Message;
exports.NoticeGroup = NoticeGroup;
exports.renderStatusMessage = renderStatusMessage;
exports.CrossSelection = CrossSelection;
exports.StateMessage = StateMessage;
const preact_1 = require("preact");
const jsx_runtime_1 = require("preact/jsx-runtime");
/** @jsxImportSource preact */
/** Shared Preact presentation primitives for composable MCP Apps. */
const interactive_child_js_1 = require("./interactive-child.js");
const preact_2 = require("preact");
const interaction_controls_js_1 = require("./interaction-controls.js");
/** Simple vertical composition primitive; it carries no domain semantics. */
function Stack({ gap = "md", className, children }) {
    return ((0, jsx_runtime_1.jsx)("div", { class: classes("mcp-view-stack", className), "data-gap": gap, children: children }));
}
/** Horizontal fact or control row; its contents and meaning remain caller-owned. */
function Row({ label, responsive = false, className, children, }) {
    return ((0, jsx_runtime_1.jsx)("div", { "aria-label": label, class: classes("mcp-view-row", responsive ? "mcp-view-row-responsive" : undefined, className), role: label ? "group" : undefined, children: children }));
}
/** The canonical MCP component container. */
function Card({ title, eyebrow, actions, className, children, }) {
    return ((0, jsx_runtime_1.jsxs)("section", { class: classes("mcp-view-card", className), children: [(title || eyebrow || actions) && ((0, jsx_runtime_1.jsxs)("header", { class: "mcp-view-card-header", children: [(0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-card-heading", children: [eyebrow && (0, jsx_runtime_1.jsx)("p", { class: "mcp-view-card-eyebrow", children: eyebrow }), title && (0, jsx_runtime_1.jsx)("h2", { class: "mcp-view-card-title", children: title })] }), actions && (0, jsx_runtime_1.jsx)("div", { class: "mcp-view-card-actions", children: actions })] })), children] }));
}
/** Accessible wrapping group for compact status and classification badges. */
function BadgeGroup({ label, className, children, }) {
    return ((0, jsx_runtime_1.jsx)("div", { "aria-label": label, class: classes("mcp-view-badges", className), role: "group", children: children }));
}
/** Compact status or classification label. */
function Badge({ tone = "neutral", children, className }) {
    return ((0, jsx_runtime_1.jsx)("span", { class: classes("mcp-view-badge", className), "data-tone": tone, children: children }));
}
/** One unit-bearing reading. Callers remain responsible for the value and its tone. */
function Metric({ id, label, value, unit, detail, tone = "neutral", className, }) {
    return ((0, jsx_runtime_1.jsxs)("article", { class: classes("mcp-view-metric", className), "data-metric": id, "data-tone": tone, children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-metric-label", children: label }), (0, jsx_runtime_1.jsx)("strong", { class: "mcp-view-metric-value", children: value }), unit && (0, jsx_runtime_1.jsx)("small", { class: "mcp-view-metric-unit", children: unit }), detail && (0, jsx_runtime_1.jsx)("small", { class: "mcp-view-metric-detail", children: detail })] }));
}
/** Responsive, container-aware metrics with stable semantic slots. */
function MetricGrid({ items, className }) {
    return ((0, jsx_runtime_1.jsx)("div", { class: classes("mcp-view-metrics", className), children: items.map((metric) => (0, preact_1.createElement)(Metric, { ...metric, key: metric.id })) }));
}
/** Provenance and identity facts with safe wrapping for hashes and URIs. */
function KeyValueList({ items, layout = "inspector", className, }) {
    return ((0, jsx_runtime_1.jsx)("dl", { class: classes("mcp-view-key-values", className), "data-layout": layout === "inspector" ? undefined : layout, children: items.map((item) => ((0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-key-value", children: [(0, jsx_runtime_1.jsx)("dt", { children: item.label }), (0, jsx_runtime_1.jsx)("dd", { children: item.value })] }, item.id))) }));
}
/** Accessible compact table; selection behavior is opt-in and keyboard-safe. */
function DataTable({ label, rows, columns, rowKey, selected, onSelect, getDisclosure, emptyLabel = "No matching data", className, }) {
    if (rows.length === 0) {
        return ((0, jsx_runtime_1.jsx)("div", { "aria-label": label, class: classes("mcp-view-table-wrap", className), role: "status", children: (0, jsx_runtime_1.jsx)(EmptyState, { children: emptyLabel }) }));
    }
    return ((0, jsx_runtime_1.jsx)("div", { class: classes("mcp-view-table-wrap", className), children: (0, jsx_runtime_1.jsxs)("table", { class: "mcp-view-table", "aria-label": label, children: [(0, jsx_runtime_1.jsx)("thead", { children: (0, jsx_runtime_1.jsx)("tr", { children: columns.map((column) => ((0, jsx_runtime_1.jsx)("th", { scope: "col", "data-align": column.align ?? "left", children: column.label }, column.id))) }) }), (0, jsx_runtime_1.jsx)("tbody", { children: rows.map((row) => {
                        const disclosure = getDisclosure?.(row);
                        const interactive = disclosure !== undefined || onSelect !== undefined;
                        const isSelected = selected?.(row);
                        const choose = disclosure ? disclosure.onOpen : () => onSelect?.(row);
                        return ((0, jsx_runtime_1.jsx)("tr", { "aria-selected": selected ? isSelected : undefined, class: isSelected ? "mcp-view-selected" : undefined, "data-interactive": interactive ? "true" : undefined, tabIndex: interactive && !disclosure ? 0 : undefined, onClick: interactive
                                ? (event) => {
                                    if ((0, interactive_child_js_1.eventStartedInInteractiveChild)(event.currentTarget, event.target))
                                        return;
                                    choose();
                                }
                                : undefined, onKeyDown: interactive
                                ? (event) => {
                                    if (event.target !== event.currentTarget)
                                        return;
                                    if (event.key !== "Enter" && event.key !== " ")
                                        return;
                                    event.preventDefault();
                                    choose();
                                }
                                : undefined, children: columns.map((column, index) => ((0, jsx_runtime_1.jsxs)("td", { "data-align": column.align ?? "left", children: [index === 0 && disclosure && ((0, jsx_runtime_1.jsx)("button", { type: "button", class: "mcp-view-table-disclosure", "aria-label": disclosure.label, "aria-expanded": disclosure.expanded, "aria-controls": disclosure.controls, onClick: (event) => {
                                            event.stopPropagation();
                                            disclosure.onOpen();
                                        }, children: (0, jsx_runtime_1.jsx)(interaction_controls_js_1.DisclosureChevron, { expanded: disclosure.expanded === true }) })), column.render(row)] }, column.id))) }, rowKey(row)));
                    }) })] }) }));
}
/** Small dashboard-safe action, never a product-wide navigation control. */
function Button({ type = "button", pressed, disabled, title, className, onClick, children, }) {
    return ((0, jsx_runtime_1.jsx)("button", { "aria-pressed": pressed, class: classes("mcp-view-button", className), disabled: disabled, onClick: onClick, title: title, type: type, children: children }));
}
/** Compact controlled text input with a mandatory accessible label. */
function TextInput({ label, value, placeholder, type = "search", disabled, className, onValueInput, }) {
    return ((0, jsx_runtime_1.jsx)("input", { "aria-label": label, class: classes("mcp-view-text-input", className), disabled: disabled, onInput: (event) => onValueInput?.(event.currentTarget.value), placeholder: placeholder, type: type, value: value }));
}
/** Bounded preformatted content for expressions, source excerpts, and exact text. */
function CodeBlock({ label, className, children }) {
    return ((0, jsx_runtime_1.jsx)("pre", { "aria-label": label, class: classes("mcp-view-code-block", className), children: (0, jsx_runtime_1.jsx)("code", { children: children }) }));
}
/** Inline exact text with safe wrapping for fingerprints, identifiers, and URIs. */
function InlineCode({ title, className, children, }) {
    return ((0, jsx_runtime_1.jsx)("code", { class: classes("mcp-view-inline-code", className), title: title, children: children }));
}
function Toolbar({ label, className, children, }) {
    return ((0, jsx_runtime_1.jsx)("div", { "aria-label": label, class: classes("mcp-view-toolbar", className), role: "group", children: children }));
}
function EmptyState({ children, className, }) {
    return (0, jsx_runtime_1.jsx)("p", { class: classes("mcp-view-empty", className), children: children });
}
/**
 * Frame-first loading placeholder: the structure of a recorded view appears
 * before its values, so nothing shifts once the values arrive.
 */
function Skeleton({ label, lines = 3, className }) {
    if (!Number.isInteger(lines) || lines < 1) {
        throw new RangeError("Skeleton lines must be a positive integer");
    }
    return ((0, jsx_runtime_1.jsx)("div", { "aria-busy": "true", "aria-label": label, class: classes("mcp-view-skeleton", className), role: "status", children: Array.from({ length: lines }, (_unused, index) => (0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-skeleton-line" }, index)) }));
}
/** Compact inline notice that keeps surrounding values visible. */
function Message({ tone = "neutral", children, className, }) {
    return ((0, jsx_runtime_1.jsx)("div", { class: classes("mcp-view-message", className), "data-tone": tone, role: tone === "danger" ? "alert" : "status", children: children }));
}
/**
 * Short notices gathered under one severity heading.
 *
 * Renders nothing when there is nothing to say, so a caller never has to guard
 * the call site. Truncation is stated by the caller: the group displays the
 * notices it was handed and never counts what it was not.
 */
function NoticeGroup({ label, items, tone = "neutral", omittedLabel, className, }) {
    // `{count && `${count} more`}` yields 0 and `{text && text}` yields "" for a
    // caller who means nothing was left out. Counting those as content would
    // render the very group this contract promises to hide.
    const omitted = omittedLabel !== undefined && omittedLabel !== null &&
        omittedLabel !== false && omittedLabel !== "" && omittedLabel !== 0;
    if (items.length === 0 && !omitted)
        return null;
    return ((0, jsx_runtime_1.jsxs)("section", { "aria-label": label, class: classes("mcp-view-notice-group", className), "data-tone": tone, 
        // One live region for the group, not one per notice. Wrapping each item
        // in Message announced N separate alerts for what reads on screen as a
        // single severity heading with its list underneath.
        role: tone === "danger" ? "alert" : "status", children: [(0, jsx_runtime_1.jsx)("strong", { class: "mcp-view-notice-group-label", children: label }), (0, jsx_runtime_1.jsx)("ul", { class: "mcp-view-notice-group-items", children: items.map((item, index) => (0, jsx_runtime_1.jsx)("li", { class: "mcp-view-notice-group-item", children: item }, index)) }), omitted && (0, jsx_runtime_1.jsx)("small", { class: "mcp-view-notice-group-omitted", children: omittedLabel })] }));
}
/**
 * Render a `StateMessage` into a real DOM node and hand that node back.
 *
 * `defineView` returns a native element, so every viewer built on it has to
 * bridge Preact to the DOM itself. Hand-written bridges drift — the tone, the
 * alert role and the class stop matching between surfaces of the same product.
 * This is that bridge, so one status looks like every other status.
 */
function renderStatusMessage(detail, options = {}) {
    const host = options.container ?? document.createElement("div");
    (0, preact_2.render)((0, preact_2.createElement)(StateMessage, {
        busy: options.busy,
        className: options.className,
        title: options.title,
        tone: options.tone,
    }, detail), host);
    // Without a container the caller mounts what comes back — typically as the
    // return of `defineView`, which hands its element straight to the router.
    // Returning the bare wrapper gave them a div carrying neither the class nor
    // the alert role, so `replaceChildren` produced a root that no viewer stylesheet
    // and no assistive technology could see. The container form returns the node
    // the caller already owns.
    if (options.container)
        return options.container;
    const rendered = host.firstElementChild;
    if (!rendered)
        throw new Error("renderStatusMessage rendered no element");
    return rendered;
}
/** Read-only projection of a selection coordinated by an owning host. */
function CrossSelection({ label, value, status, className, }) {
    return ((0, jsx_runtime_1.jsxs)("div", { class: classes("mcp-view-cross-selection", className), role: "status", children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-cross-selection-label", children: label }), (0, jsx_runtime_1.jsx)("strong", { class: "mcp-view-cross-selection-value", children: value }), status && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-cross-selection-status", children: status })] }));
}
function StateMessage({ title, tone = "neutral", busy, children, className, }) {
    return ((0, jsx_runtime_1.jsxs)("div", { "aria-busy": busy, class: classes("mcp-view-state", className), "data-tone": tone, role: tone === "danger" ? "alert" : "status", children: [busy && (0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-state-busy" }), title && (0, jsx_runtime_1.jsx)("strong", { children: title }), children && (0, jsx_runtime_1.jsx)("div", { class: "mcp-view-state-detail", children: children })] }));
}
function classes(...values) {
    return values.filter(Boolean).join(" ");
}
