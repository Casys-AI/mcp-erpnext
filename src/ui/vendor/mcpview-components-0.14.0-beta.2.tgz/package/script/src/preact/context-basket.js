"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActiveContextChip = ActiveContextChip;
const jsx_runtime_1 = require("preact/jsx-runtime");
const hooks_1 = require("preact/hooks");
const FOCUSABLE_SELECTOR = [
    "a[href]",
    "button:not([disabled])",
    "input:not([disabled])",
    "select:not([disabled])",
    "textarea:not([disabled])",
    '[tabindex]:not([tabindex="-1"])',
].join(",");
function accepted(result) {
    return result === "shared" || result === "cleared";
}
function outsideFocusable(wrapper) {
    if (!wrapper)
        return null;
    const elements = Array.from(wrapper.ownerDocument.querySelectorAll(FOCUSABLE_SELECTOR));
    const current = elements.indexOf(wrapper.ownerDocument.activeElement);
    return elements.slice(current + 1).find((element) => !wrapper.contains(element)) ??
        elements.slice(0, Math.max(0, current)).reverse().find((element) => !wrapper.contains(element)) ??
        null;
}
function entryKey(entry) {
    return entry.kind === "group"
        ? JSON.stringify(["group", entry.group.scopeKey, entry.group.id])
        : JSON.stringify(["single", entry.selection.scopeKey, entry.selection.item.id]);
}
function display(entry) {
    return entry.kind === "group" ? entry.group : entry.selection.item;
}
/** Controlled basket. Acknowledged selections and mutation results remain caller-owned. */
function ActiveContextChip({ selections, entries, labels, failed = false, pending = false, evictedLabel, onRemove, onRemoveGroup, onClear, onRetry, compact = false, popoverAlign = "end", className, classes, }) {
    const slot = (name) => [`mcp-view-context-${name}`, classes?.[name]].filter(Boolean).join(" ");
    const [open, setOpen] = (0, hooks_1.useState)(false);
    const wrapperRef = (0, hooks_1.useRef)(null);
    const triggerRef = (0, hooks_1.useRef)(null);
    const singleRemoveRef = (0, hooks_1.useRef)(null);
    const removeRefs = (0, hooks_1.useRef)(new Map());
    const mountedRef = (0, hooks_1.useRef)(true);
    const operationRef = (0, hooks_1.useRef)(0);
    const popoverId = (0, hooks_1.useId)();
    const visible = entries ??
        selections.map((selection) => ({ kind: "single", selection }));
    const visibleRef = (0, hooks_1.useRef)(visible);
    visibleRef.current = visible;
    const count = visible.length;
    (0, hooks_1.useLayoutEffect)(() => {
        mountedRef.current = true;
        return () => {
            mountedRef.current = false;
            operationRef.current++;
        };
    }, []);
    (0, hooks_1.useEffect)(() => {
        if (count <= 1)
            setOpen(false);
    }, [count]);
    (0, hooks_1.useEffect)(() => {
        if (!open)
            return;
        const doc = wrapperRef.current.ownerDocument;
        function pointer(event) {
            if (!wrapperRef.current?.contains(event.target)) {
                operationRef.current++;
                setOpen(false);
            }
        }
        function key(event) {
            if (event.key !== "Escape")
                return;
            event.preventDefault();
            operationRef.current++;
            setOpen(false);
            triggerRef.current?.focus();
        }
        doc.addEventListener("pointerdown", pointer);
        doc.addEventListener("keydown", key);
        return () => {
            doc.removeEventListener("pointerdown", pointer);
            doc.removeEventListener("keydown", key);
        };
    }, [open]);
    // Run after the controlled render, and never steal focus back from a user who moved away.
    function afterAccepted(operation, origin, callback) {
        queueMicrotask(() => {
            if (!mountedRef.current || operation !== operationRef.current)
                return;
            const current = origin?.ownerDocument.activeElement;
            // A removed button naturally loses browser focus; a deliberate focus change wins.
            if (origin && current !== origin && current !== origin.ownerDocument.body)
                return;
            callback();
        });
    }
    async function remove(entry, index) {
        const operation = ++operationRef.current;
        const origin = wrapperRef.current?.ownerDocument.activeElement ?? null;
        const external = outsideFocusable(wrapperRef.current);
        let result;
        try {
            result = await (entry.kind === "group"
                ? onRemoveGroup?.(entry.group)
                : onRemove
                    ? onRemove(entry.selection)
                    : count === 1
                        ? onClear()
                        : undefined);
        }
        catch {
            return;
        }
        if (!accepted(result))
            return;
        afterAccepted(operation, origin, () => {
            const remaining = visibleRef.current;
            if (!remaining.length) {
                if (external?.isConnected)
                    external.focus({ preventScroll: true });
            }
            else if (remaining.length === 1) {
                singleRemoveRef.current?.focus({ preventScroll: true });
            }
            else {
                const neighbour = remaining[Math.min(index, remaining.length - 1)];
                (removeRefs.current.get(entryKey(neighbour)) ?? triggerRef.current)?.focus({
                    preventScroll: true,
                });
            }
        });
    }
    async function clear() {
        const operation = ++operationRef.current;
        const origin = wrapperRef.current?.ownerDocument.activeElement ?? null;
        const external = outsideFocusable(wrapperRef.current);
        let result;
        try {
            result = await onClear();
        }
        catch {
            return;
        }
        if (!accepted(result))
            return;
        afterAccepted(operation, origin, () => {
            setOpen(false);
            if (external?.isConnected)
                external.focus({ preventScroll: true });
        });
    }
    async function retry() {
        const operation = ++operationRef.current;
        const origin = wrapperRef.current?.ownerDocument.activeElement ?? null;
        const external = outsideFocusable(wrapperRef.current);
        let result;
        try {
            result = await onRetry?.();
        }
        catch {
            return;
        }
        if (!accepted(result))
            return;
        afterAccepted(operation, origin, () => {
            // Retry may clear the basket, remove one item, or retain its confirmed list.
            // Choose from the controlled render after ACK rather than the failed intent.
            const retained = visibleRef.current.length === 1
                ? singleRemoveRef.current
                : triggerRef.current;
            if (retained?.isConnected && !retained.disabled) {
                retained.focus({ preventScroll: true });
            }
            else if (origin?.isConnected) {
                origin.focus({ preventScroll: true });
            }
            else if (external?.isConnected) {
                external.focus({ preventScroll: true });
            }
        });
    }
    function removeButton(entry, index, single = false) {
        const item = display(entry);
        return ((0, jsx_runtime_1.jsx)("button", { type: "button", class: slot("remove"), ref: (element) => {
                if (single)
                    singleRemoveRef.current = element;
                if (element)
                    removeRefs.current.set(entryKey(entry), element);
                else
                    removeRefs.current.delete(entryKey(entry));
            }, disabled: pending || (entry.kind === "group" ? !onRemoveGroup : !onRemove && count > 1), "aria-label": labels.remove(item.label), title: labels.remove(item.label), onClick: () => void remove(entry, index), children: (0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", children: "\u00D7" }) }));
    }
    if (count === 0 && !failed && !pending && !evictedLabel)
        return null;
    return ((0, jsx_runtime_1.jsxs)("span", { ref: wrapperRef, "aria-busy": pending || undefined, class: [slot("root"), className].filter(Boolean).join(" "), "data-compact": compact || undefined, children: [count === 1 && ((0, jsx_runtime_1.jsxs)("span", { class: slot("single"), "aria-live": "polite", "aria-atomic": "true", children: [(0, jsx_runtime_1.jsx)("span", { class: slot("activeLabel"), children: labels.active }), (0, jsx_runtime_1.jsx)("span", { class: slot("singleLabel"), title: display(visible[0]).label, children: display(visible[0]).label }), removeButton(visible[0], 0, true)] })), count > 1 && ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)("button", { ref: triggerRef, type: "button", class: slot("trigger"), "aria-expanded": open, "aria-controls": open ? popoverId : undefined, "aria-haspopup": "dialog", onClick: () => {
                            operationRef.current++;
                            setOpen((value) => !value);
                        }, children: [(0, jsx_runtime_1.jsxs)("span", { "aria-live": "polite", "aria-atomic": "true", children: [labels.active, " \u00B7 ", count] }), (0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: slot("chevron"), children: open ? "▴" : "▾" })] }), open && ((0, jsx_runtime_1.jsxs)("span", { id: popoverId, role: "dialog", "aria-label": labels.items, class: slot("popover"), "data-align": popoverAlign, children: [(0, jsx_runtime_1.jsx)("span", { role: "list", class: slot("list"), children: visible.map((entry, index) => {
                                    const item = display(entry);
                                    const summary = entry.kind === "group" ? entry.group.summary : undefined;
                                    return ((0, jsx_runtime_1.jsxs)("span", { role: "listitem", class: slot("item"), children: [(0, jsx_runtime_1.jsxs)("span", { class: slot("itemContent"), children: [(0, jsx_runtime_1.jsx)("span", { class: slot("itemLabel"), children: item.label }), (0, jsx_runtime_1.jsx)("span", { class: slot("itemDetail"), children: summary ?? [item.view, item.value].filter(Boolean).join(" · ") })] }), removeButton(entry, index)] }, entryKey(entry)));
                                }) }), (0, jsx_runtime_1.jsx)("button", { type: "button", class: slot("clearAll"), disabled: pending, onClick: () => void clear(), children: labels.clearAll })] }))] })), pending && ((0, jsx_runtime_1.jsxs)("span", { role: "status", "aria-live": "polite", class: slot("pending"), title: labels.pending, children: [(0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: slot("spinner"), children: "\u25CC" }), (0, jsx_runtime_1.jsx)("span", { class: slot("pendingLabel"), children: labels.pending })] })), failed && ((0, jsx_runtime_1.jsxs)("span", { role: "status", class: slot("error"), title: labels.error, children: [(0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", children: "!" }), (0, jsx_runtime_1.jsx)("span", { class: slot("errorLabel"), "data-hidden": compact && count > 0 || undefined, children: labels.error }), onRetry && ((0, jsx_runtime_1.jsx)("button", { type: "button", class: slot("retry"), disabled: pending, onClick: () => void retry(), children: labels.retry }))] })), evictedLabel && ((0, jsx_runtime_1.jsx)("span", { role: "status", "aria-live": "polite", class: slot("eviction"), title: labels.evicted(evictedLabel), children: labels.evicted(evictedLabel) }))] }));
}
