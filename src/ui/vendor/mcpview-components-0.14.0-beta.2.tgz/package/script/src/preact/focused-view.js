"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Disclosure = Disclosure;
exports.FocusedView = FocusedView;
const jsx_runtime_1 = require("preact/jsx-runtime");
const hooks_js_1 = require("../layout/hooks.js");
/** Native keyboard and disclosure semantics; never hides a caller's critical status by itself. */
function Disclosure({ label, children, open, onToggle, className, }) {
    return ((0, jsx_runtime_1.jsxs)("details", { class: classes("mcp-view-disclosure", className), open: open, onToggle: onToggle ? (event) => onToggle(event.currentTarget.open) : undefined, children: [(0, jsx_runtime_1.jsx)("summary", { class: "mcp-view-disclosure-summary", children: label }), (0, jsx_runtime_1.jsx)("div", { class: "mcp-view-disclosure-body", children: children })] }));
}
/**
 * One primary view, an overt status and a closed technical disclosure. The
 * outer MCP surface supplies the frame. The viewer owns every value and label.
 */
function FocusedView({ label, primary, status, details, detailsLabel, hostContext, layout: forced, className, }) {
    const { ref, layout, boundsStyle } = (0, hooks_js_1.useViewerLayout)(hostContext, { forced });
    return ((0, jsx_runtime_1.jsxs)("div", { ref: ref, role: "group", "aria-label": label, class: classes("mcp-view-focused-view", className), "data-layout": layout, style: boundsStyle, children: [isPresent(status) && (0, jsx_runtime_1.jsx)("div", { class: "mcp-view-focused-status", children: status }), (0, jsx_runtime_1.jsx)("div", { class: "mcp-view-focused-primary", children: primary }), isPresent(details) && detailsLabel !== undefined && ((0, jsx_runtime_1.jsx)(Disclosure, { label: detailsLabel, children: details }))] }));
}
function isPresent(value) {
    return value !== undefined && value !== null && value !== false;
}
function classes(...values) {
    return values.filter(Boolean).join(" ");
}
