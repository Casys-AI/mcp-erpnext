"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextPinButton = ContextPinButton;
exports.DisclosureChevron = DisclosureChevron;
const jsx_runtime_1 = require("preact/jsx-runtime");
/** Independent action beside a row, card, or active point. The viewer owns its selection. */
function ContextPinButton({ label, pressed, group = false, disabled, className, onToggle, }) {
    return ((0, jsx_runtime_1.jsx)("button", { type: "button", "aria-label": label, "aria-pressed": pressed, title: label, class: className ? `mcp-view-context-pin ${className}` : "mcp-view-context-pin", "data-context-pin": "", disabled: disabled, draggable: false, onPointerDown: (event) => event.stopPropagation(), onPointerUp: (event) => event.stopPropagation(), onPointerCancel: (event) => event.stopPropagation(), onMouseDown: (event) => event.stopPropagation(), onMouseUp: (event) => event.stopPropagation(), onTouchStart: (event) => event.stopPropagation(), onTouchEnd: (event) => event.stopPropagation(), onDragStart: (event) => {
            event.preventDefault();
            event.stopPropagation();
        }, onKeyDown: (event) => {
            if (event.key !== "Enter" && event.key !== " ")
                return;
            event.stopPropagation();
            if (event.repeat)
                event.preventDefault();
        }, onKeyUp: (event) => {
            if (event.key === "Enter" || event.key === " ")
                event.stopPropagation();
        }, onClick: (event) => {
            event.stopPropagation();
            if (!disabled && (event.detail ?? 0) <= 1)
                onToggle(Boolean(event.shiftKey));
        }, onDblClick: (event) => event.stopPropagation(), children: (0, jsx_runtime_1.jsxs)("svg", { "aria-hidden": "true", focusable: "false", viewBox: "0 0 24 24", width: "22", height: "22", fill: "none", stroke: "currentColor", "stroke-linecap": "round", children: [(0, jsx_runtime_1.jsx)("path", { class: "mcp-view-context-pin-stroke", d: group ? "M9 5v14" : "M12 5v14" }), group && (0, jsx_runtime_1.jsx)("path", { class: "mcp-view-context-pin-stroke", d: "M15 5v14" })] }) }));
}
/** Decorative leading glyph. The containing button supplies its label, action and expanded state. */
function DisclosureChevron({ expanded, className }) {
    return ((0, jsx_runtime_1.jsx)("svg", { "aria-hidden": "true", focusable: "false", viewBox: "0 0 16 16", width: "16", height: "16", class: className ? `mcp-view-disclosure-chevron ${className}` : "mcp-view-disclosure-chevron", "data-expanded": expanded ? "true" : "false", fill: "none", stroke: "currentColor", "stroke-linecap": "round", "stroke-linejoin": "round", "stroke-width": "1.5", children: (0, jsx_runtime_1.jsx)("path", { d: "m6 4 4 4-4 4" }) }));
}
