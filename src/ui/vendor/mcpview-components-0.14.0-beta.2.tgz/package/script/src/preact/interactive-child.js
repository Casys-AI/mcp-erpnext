"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.eventStartedInInteractiveChild = eventStartedInInteractiveChild;
const INTERACTIVE_CHILD_SELECTOR = [
    "a[href]",
    "button",
    "input",
    "select",
    "textarea",
    "[role='button']",
    "[role='link']",
].join(",");
function eventStartedInInteractiveChild(element, target) {
    const candidate = target;
    if (!candidate || typeof candidate.closest !== "function")
        return false;
    const interactive = candidate.closest(INTERACTIVE_CHILD_SELECTOR);
    return interactive !== null && interactive !== element && element.contains(interactive);
}
