"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Sparkline = Sparkline;
exports.SeriesChart = SeriesChart;
exports.IntervalPlot = IntervalPlot;
const jsx_runtime_1 = require("preact/jsx-runtime");
const SPARKLINE_VIEWBOX_HEIGHT = 24;
const SERIES_CHART_VIEWBOX_HEIGHT = 40;
const VIEWBOX_WIDTH = 100;
/** Compact shape of one recorded series, readable at chip and row density. */
function Sparkline({ label, values, summaryLabel, variant = "inline", tone = "info", className, }) {
    validateSamples(values, "Sparkline values");
    const min = Math.min(...values);
    const max = Math.max(...values);
    const points = values
        .map((value, index) => {
        const x = (index / (values.length - 1)) * VIEWBOX_WIDTH;
        const y = SPARKLINE_VIEWBOX_HEIGHT -
            normalize(value, min, max) * SPARKLINE_VIEWBOX_HEIGHT;
        return `${round(x)},${round(y)}`;
    })
        .join(" ");
    const plot = ((0, jsx_runtime_1.jsx)("svg", { "aria-label": variant === "inline" ? `${label}: ${summaryLabel}` : undefined, "aria-hidden": variant === "block" ? true : undefined, class: classes("mcp-view-sparkline", variant === "inline" ? className : undefined), "data-tone": tone, preserveAspectRatio: "none", role: variant === "inline" ? "img" : undefined, viewBox: `0 0 ${VIEWBOX_WIDTH} ${SPARKLINE_VIEWBOX_HEIGHT}`, children: (0, jsx_runtime_1.jsx)("polyline", { class: "mcp-view-sparkline-line", points: points, "vector-effect": "non-scaling-stroke" }) }));
    if (variant === "inline")
        return plot;
    return ((0, jsx_runtime_1.jsxs)("div", { "aria-label": `${label}: ${summaryLabel}`, class: classes("mcp-view-sparkline-block", className), role: "img", children: [(0, jsx_runtime_1.jsxs)("div", { "aria-hidden": "true", class: "mcp-view-sparkline-heading", children: [(0, jsx_runtime_1.jsx)("span", { children: label }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-sparkline-summary", children: summaryLabel })] }), plot] }));
}
/** Multi-series plot on one shared finite scale, with a declared cursor readout. */
function SeriesChart({ label, series, xMin, xMax, yMin, yMax, axisLabels, legend = true, yTicks, summary, cursor, onScrub, className, }) {
    validateSeriesChart(series, xMin, xMax, yMin, yMax, cursor);
    for (const tick of yTicks ?? []) {
        if (!Number.isFinite(tick.value) || tick.value < yMin || tick.value > yMax) {
            throw new RangeError("SeriesChart yTicks value must be within yMin and yMax");
        }
    }
    const baselineY = yMin <= 0 && 0 <= yMax
        ? SERIES_CHART_VIEWBOX_HEIGHT - normalize(0, yMin, yMax) * SERIES_CHART_VIEWBOX_HEIGHT
        : undefined;
    const cursorX = cursor === undefined
        ? undefined
        : normalize(cursor.x, xMin, xMax) * VIEWBOX_WIDTH;
    const seriesLabels = series.map((one) => one.label).join(", ");
    return ((0, jsx_runtime_1.jsxs)("figure", { class: classes("mcp-view-series-chart", className), children: [legend && series.length >= 2 && (
            // The SVG's aria-label already names every series: the visual legend
            // stays out of the accessibility tree so nothing is read twice.
            (0, jsx_runtime_1.jsx)("ul", { "aria-hidden": "true", class: "mcp-view-series-chart-legend", children: series.map((one) => ((0, jsx_runtime_1.jsxs)("li", { "data-tone": one.tone ?? "info", children: [(0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-series-chart-legend-mark", "data-mark": one.mark }), (0, jsx_runtime_1.jsx)("span", { children: one.label })] }, one.id))) })), (0, jsx_runtime_1.jsxs)("div", { class: classes("mcp-view-series-chart-frame", yTicks?.length ? "mcp-view-series-chart-frame-ticks" : undefined), children: [yTicks && yTicks.length > 0 && ((0, jsx_runtime_1.jsx)("div", { "aria-hidden": "true", class: "mcp-view-series-chart-y-axis", children: yTicks.map((tick, index) => ((0, jsx_runtime_1.jsx)("span", { style: { top: `${round((1 - normalize(tick.value, yMin, yMax)) * 100)}%` }, children: tick.label }, index))) })), (0, jsx_runtime_1.jsxs)("svg", { "aria-label": `${label}: ${seriesLabels}`, class: "mcp-view-series-chart-plot", preserveAspectRatio: "none", role: "img", viewBox: `0 0 ${VIEWBOX_WIDTH} ${SERIES_CHART_VIEWBOX_HEIGHT}`, onPointerLeave: onScrub === undefined ? undefined : () => onScrub(undefined), onPointerMove: onScrub === undefined ? undefined : (event) => {
                            const box = event.currentTarget.getBoundingClientRect();
                            if (box.width === 0)
                                return;
                            const ratio = (event.clientX - box.left) / box.width;
                            if (ratio < 0 || ratio > 1)
                                return;
                            onScrub(xMin + ratio * (xMax - xMin));
                        }, children: [yTicks?.map((tick, index) => {
                                const y = round((1 - normalize(tick.value, yMin, yMax)) * SERIES_CHART_VIEWBOX_HEIGHT);
                                return ((0, jsx_runtime_1.jsx)("line", { class: "mcp-view-series-chart-grid", "vector-effect": "non-scaling-stroke", x1: 0, x2: VIEWBOX_WIDTH, y1: y, y2: y }, index));
                            }), baselineY !== undefined && ((0, jsx_runtime_1.jsx)("line", { class: "mcp-view-series-chart-baseline", "vector-effect": "non-scaling-stroke", x1: 0, x2: VIEWBOX_WIDTH, y1: round(baselineY), y2: round(baselineY) })), cursorX !== undefined && ((0, jsx_runtime_1.jsx)("line", { class: "mcp-view-series-chart-cursor", "vector-effect": "non-scaling-stroke", x1: round(cursorX), x2: round(cursorX), y1: 0, y2: SERIES_CHART_VIEWBOX_HEIGHT })), series.map((one) => {
                                const placed = one.points.map((point) => ({
                                    x: normalize(point.x, xMin, xMax) * VIEWBOX_WIDTH,
                                    y: SERIES_CHART_VIEWBOX_HEIGHT -
                                        normalize(point.y, yMin, yMax) * SERIES_CHART_VIEWBOX_HEIGHT,
                                }));
                                if (one.mark === "line") {
                                    return ((0, jsx_runtime_1.jsx)("polyline", { class: "mcp-view-series-chart-line", "data-tone": one.tone ?? "info", points: placed.map((at) => `${round(at.x)},${round(at.y)}`).join(" "), "vector-effect": "non-scaling-stroke" }, one.id));
                                }
                                // Each recorded sample stands alone, anchored on the drawn baseline
                                // when the scale carries zero, otherwise on the floor of the scale.
                                const foot = baselineY ?? SERIES_CHART_VIEWBOX_HEIGHT;
                                return ((0, jsx_runtime_1.jsx)("g", { class: "mcp-view-series-chart-bars", "data-tone": one.tone ?? "info", children: placed.map((at, index) => ((0, jsx_runtime_1.jsx)("line", { "vector-effect": "non-scaling-stroke", x1: round(at.x), x2: round(at.x), y1: round(foot), y2: round(at.y) }, one.points[index].x))) }, one.id));
                            })] }), axisLabels && axisLabels.length > 0 && ((0, jsx_runtime_1.jsx)("div", { "aria-hidden": "true", class: "mcp-view-series-chart-axis", children: axisLabels.map((tick) => (0, jsx_runtime_1.jsx)("span", { children: tick }, tick)) }))] }), cursor && ((0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-series-chart-readout", children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-series-chart-readout-position", children: cursor.label }), (0, jsx_runtime_1.jsx)("dl", { class: "mcp-view-series-chart-readout-values", children: cursor.readouts.map((readout) => {
                            const owner = series.find((one) => one.id === readout.seriesId);
                            return ((0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-series-chart-readout-value", children: [(0, jsx_runtime_1.jsx)("dt", { "data-tone": owner?.tone ?? "info", children: owner?.label }), (0, jsx_runtime_1.jsx)("dd", { children: readout.valueLabel })] }, readout.seriesId));
                        }) })] })), summary && summary.length > 0 && ((0, jsx_runtime_1.jsx)("figcaption", { class: "mcp-view-series-chart-summary", children: summary.map((item) => ((0, jsx_runtime_1.jsxs)("span", { class: "mcp-view-series-chart-summary-item", children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-series-chart-summary-label", children: item.label }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-series-chart-summary-value", children: item.valueLabel })] }, item.id))) }))] }));
}
/** Caller-declared deviation intervals laid out against a shared zero line. */
function IntervalPlot({ label, min, max, zeroLabel, intervals, className, }) {
    validateIntervalPlot(min, max, intervals);
    const zeroOffset = `${round(normalize(0, min, max) * 100)}%`;
    return ((0, jsx_runtime_1.jsxs)("div", { "aria-label": label, class: classes("mcp-view-interval-plot", className), role: "group", children: [(0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-interval-plot-scale", children: [(0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-interval-plot-zero", style: { left: zeroOffset } }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-interval-plot-zero-label", style: { left: zeroOffset }, children: zeroLabel })] }), intervals.map((interval) => ((0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-interval-plot-row", "data-tone": interval.tone ?? "neutral", children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-interval-plot-label", children: interval.label }), (0, jsx_runtime_1.jsxs)("span", { class: "mcp-view-interval-plot-track", children: [(0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-interval-plot-zero", style: { left: zeroOffset } }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-interval-plot-box", style: {
                                    left: `${round(normalize(interval.lower, min, max) * 100)}%`,
                                    width: `${round(((interval.upper - interval.lower) / (max - min)) * 100)}%`,
                                } })] }), (0, jsx_runtime_1.jsxs)("span", { class: "mcp-view-interval-plot-bounds", children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-interval-plot-lower", children: interval.lowerLabel }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-interval-plot-upper", children: interval.upperLabel })] })] }, interval.id)))] }));
}
function validateSamples(values, subject) {
    if (values.length < 2)
        throw new RangeError(`${subject} need at least two samples`);
    for (const value of values) {
        if (!Number.isFinite(value))
            throw new TypeError(`${subject} must all be finite`);
    }
}
function validateSeriesChart(series, xMin, xMax, yMin, yMax, cursor) {
    for (const [name, candidate] of [["xMin", xMin], ["xMax", xMax], ["yMin", yMin], [
            "yMax",
            yMax,
        ]]) {
        if (!Number.isFinite(candidate))
            throw new TypeError(`SeriesChart ${name} must be finite`);
    }
    if (xMax <= xMin)
        throw new RangeError("SeriesChart xMax must be greater than xMin");
    if (yMax <= yMin)
        throw new RangeError("SeriesChart yMax must be greater than yMin");
    if (series.length === 0)
        throw new TypeError("SeriesChart series must not be empty");
    const ids = new Set();
    for (const one of series) {
        if (ids.has(one.id))
            throw new TypeError(`SeriesChart series id ${one.id} is duplicated`);
        ids.add(one.id);
        if (one.points.length < 2) {
            throw new RangeError(`SeriesChart series ${one.id} needs at least two points`);
        }
        for (const point of one.points) {
            if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) {
                throw new TypeError(`SeriesChart series ${one.id} points must be finite`);
            }
        }
    }
    if (cursor === undefined)
        return;
    if (!Number.isFinite(cursor.x))
        throw new TypeError("SeriesChart cursor x must be finite");
    if (cursor.x < xMin || cursor.x > xMax) {
        throw new RangeError("SeriesChart cursor x must be within xMin and xMax");
    }
    for (const readout of cursor.readouts) {
        if (!ids.has(readout.seriesId)) {
            throw new TypeError(`SeriesChart cursor readout ${readout.seriesId} names no declared series`);
        }
    }
}
function validateIntervalPlot(min, max, intervals) {
    for (const [name, candidate] of [["min", min], ["max", max]]) {
        if (!Number.isFinite(candidate))
            throw new TypeError(`IntervalPlot ${name} must be finite`);
    }
    if (max <= min)
        throw new RangeError("IntervalPlot max must be greater than min");
    if (min > 0 || max < 0)
        throw new RangeError("IntervalPlot scale must contain zero");
    if (intervals.length === 0)
        throw new TypeError("IntervalPlot intervals must not be empty");
    const ids = new Set();
    for (const interval of intervals) {
        if (ids.has(interval.id))
            throw new TypeError(`IntervalPlot id ${interval.id} is duplicated`);
        ids.add(interval.id);
        if (!Number.isFinite(interval.lower) || !Number.isFinite(interval.upper)) {
            throw new TypeError(`IntervalPlot interval ${interval.id} bounds must be finite`);
        }
        if (interval.upper < interval.lower) {
            throw new RangeError(`IntervalPlot interval ${interval.id} upper must not be below lower`);
        }
        if (interval.lower < min || interval.upper > max) {
            throw new RangeError(`IntervalPlot interval ${interval.id} must be within min and max`);
        }
    }
}
/** Position on a finite scale, clamped to a flat series' midpoint. */
function normalize(value, min, max) {
    if (max === min)
        return 0.5;
    return (value - min) / (max - min);
}
function round(value) {
    return Math.round(value * 100) / 100;
}
function classes(...values) {
    return values.filter(Boolean).join(" ");
}
