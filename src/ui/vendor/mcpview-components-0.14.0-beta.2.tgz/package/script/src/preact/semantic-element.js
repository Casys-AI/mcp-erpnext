"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SemanticList = SemanticList;
exports.CollectionCard = CollectionCard;
exports.ElementIdent = ElementIdent;
exports.ElementReading = ElementReading;
exports.ElementLimit = ElementLimit;
exports.ElementBody = ElementBody;
exports.ElementSection = ElementSection;
exports.ElementVerdict = ElementVerdict;
exports.ElementProvenance = ElementProvenance;
exports.SemanticElement = SemanticElement;
const jsx_runtime_1 = require("preact/jsx-runtime");
/** @jsxImportSource preact */
/** Generic, domain-neutral presentation shell for one semantic object. */
const interactive_child_js_1 = require("./interactive-child.js");
const components_js_1 = require("./components.js");
/** Bounded group for row-density semantic objects; it owns no domain ordering. */
function SemanticList({ label, scrollable = false, className, children, }) {
    return ((0, jsx_runtime_1.jsx)("div", { "aria-label": label, class: classes("mcp-view-semantic-list", className), "data-scrollable": scrollable ? "true" : undefined, role: "group", children: children }));
}
/** Card-hosted SemanticList that keeps a single outer border. */
function CollectionCard({ label, title, eyebrow, actions, scrollable = false, className, children, }) {
    return ((0, jsx_runtime_1.jsx)(components_js_1.Card, { title: title, eyebrow: eyebrow, actions: actions, className: classes("mcp-view-collection-card", className), children: (0, jsx_runtime_1.jsx)(SemanticList, { label: label, scrollable: scrollable, children: children }) }));
}
/** Required human-facing identity slot. Its content is already resolved by the caller. */
function ElementIdent({ label, detail, marker, className, }) {
    return ((0, jsx_runtime_1.jsxs)("header", { class: classes("mcp-view-element-ident", className), "data-element-slot": "ident", children: [isPresent(marker) && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-ident-marker", children: marker }), (0, jsx_runtime_1.jsxs)("span", { class: "mcp-view-element-ident-copy", children: [(0, jsx_runtime_1.jsx)("strong", { class: "mcp-view-element-ident-label", children: label }), isPresent(detail) && (0, jsx_runtime_1.jsx)("small", { class: "mcp-view-element-ident-detail", children: detail })] })] }));
}
/** Resolved measurement or documentary reading; no unit is guessed. */
function ElementReading({ value, label, unit, detail, className, }) {
    return ((0, jsx_runtime_1.jsxs)("div", { class: classes("mcp-view-element-reading", className), "data-element-slot": "reading", children: [isPresent(label) && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-reading-label", children: label }), (0, jsx_runtime_1.jsxs)("span", { class: "mcp-view-element-reading-measure", children: [(0, jsx_runtime_1.jsx)("strong", { class: "mcp-view-element-reading-value", children: value }), isPresent(unit) && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-reading-unit", children: unit })] }), isPresent(detail) && (0, jsx_runtime_1.jsx)("small", { class: "mcp-view-element-reading-detail", children: detail })] }));
}
/** Caller-declared limit statement; never infers a range, measurement, or verdict. */
function ElementLimit({ operator, value, label, unit, detail, className, }) {
    return ((0, jsx_runtime_1.jsxs)("div", { class: classes("mcp-view-element-limit", className), "data-element-slot": "reading", children: [isPresent(label) && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-limit-label", children: label }), (0, jsx_runtime_1.jsxs)("span", { class: "mcp-view-element-limit-statement", children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-limit-operator", children: operator }), (0, jsx_runtime_1.jsx)("strong", { class: "mcp-view-element-limit-value", children: value }), isPresent(unit) && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-limit-unit", children: unit })] }), isPresent(detail) && (0, jsx_runtime_1.jsx)("small", { class: "mcp-view-element-limit-detail", children: detail })] }));
}
/** Optional provider-owned visualization slot, such as a gauge or compact domain plot. */
function ElementBody({ children, className }) {
    return ((0, jsx_runtime_1.jsx)("div", { class: classes("mcp-view-element-body", className), "data-element-slot": "body", children: children }));
}
/**
 * One titled group inside an ElementBody. A datasheet body is sections, not one
 * list: each fact belongs to exactly one, and the section names what its facts are.
 */
function ElementSection({ title, className, children, }) {
    return ((0, jsx_runtime_1.jsxs)("div", { "aria-label": title, class: classes("mcp-view-element-section", className), "data-element-slot": "section", role: "group", children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-section-title", children: title }), children] }));
}
/** Caller-authored verdict. Tone remains an explicit SemanticElement concern. */
function ElementVerdict({ value, label, className, }) {
    return ((0, jsx_runtime_1.jsxs)("div", { class: classes("mcp-view-element-verdict", className), "data-element-slot": "verdict", children: [isPresent(label) && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-verdict-label", children: label }), (0, jsx_runtime_1.jsx)("strong", { class: "mcp-view-element-verdict-value", children: value })] }));
}
/** Exact caller-provided provenance such as a source, revision, or fingerprint. */
function ElementProvenance({ value, label, className, }) {
    return ((0, jsx_runtime_1.jsxs)("footer", { class: classes("mcp-view-element-provenance", className), "data-element-slot": "provenance", children: [isPresent(label) && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-provenance-label", children: label }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-element-provenance-value", children: value })] }));
}
/**
 * Render one semantic object without owning domain vocabulary or reference resolution.
 *
 * The same slots survive chip, row, and card composition. When a tone is explicitly
 * supplied, an inline-start verdict border is invariant across all three densities.
 */
function SemanticElement({ reference, density, tone, selected, ident, reading, body, verdict, provenance, activationLabel, onActivate, className, }) {
    if (!ident)
        throw new TypeError("SemanticElement requires an ElementIdent slot");
    const interactive = onActivate !== undefined;
    const activate = () => onActivate?.(reference);
    return ((0, jsx_runtime_1.jsxs)("div", { "aria-current": !interactive && selected ? "true" : undefined, "aria-label": interactive ? activationLabel : undefined, "aria-pressed": interactive && selected !== undefined ? selected : undefined, class: classes("mcp-view-semantic-element", selected ? "mcp-view-selected" : undefined, className), "data-density": density, "data-interactive": interactive ? "true" : undefined, "data-selected": selected === undefined ? undefined : String(selected), "data-semantic-domain": reference.domain, "data-semantic-id": reference.id, "data-semantic-kind": reference.kind, "data-basis-fingerprint": reference.basisFingerprint, "data-tone": tone, role: interactive ? "button" : undefined, style: tone ? { borderInlineStart: verdictBorder(tone) } : undefined, tabIndex: interactive ? 0 : undefined, onClick: interactive
            ? (event) => {
                if ((0, interactive_child_js_1.eventStartedInInteractiveChild)(event.currentTarget, event.target))
                    return;
                activate();
            }
            : undefined, onKeyDown: interactive
            ? (event) => {
                if (event.target !== event.currentTarget)
                    return;
                if (event.key !== "Enter" && event.key !== " ")
                    return;
                event.preventDefault();
                activate();
            }
            : undefined, children: [ident, isPresent(reading) && ((0, jsx_runtime_1.jsx)("div", { class: "mcp-view-element-readings", "data-element-slot": "readings", children: reading })), body, verdict, provenance] }));
}
function verdictBorder(tone) {
    const color = {
        neutral: "var(--mcp-view-muted, currentColor)",
        info: "var(--mcp-view-accent, currentColor)",
        success: "var(--mcp-view-success, currentColor)",
        warning: "var(--mcp-view-warning, currentColor)",
        danger: "var(--mcp-view-danger, currentColor)",
    }[tone];
    return `var(--mcp-view-semantic-verdict-border-width, 3px) solid ${color}`;
}
function isPresent(value) {
    if (value === undefined || value === null || value === false)
        return false;
    return !(Array.isArray(value) && value.length === 0);
}
function classes(...values) {
    return values.filter(Boolean).join(" ");
}
