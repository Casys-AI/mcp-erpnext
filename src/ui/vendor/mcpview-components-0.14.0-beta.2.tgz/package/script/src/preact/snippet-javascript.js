"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.javascriptHighlightRanges = javascriptHighlightRanges;
const acorn_1 = require("acorn");
function tokenStyle(type, text) {
    switch (type) {
        case acorn_1.tokTypes.string:
        case acorn_1.tokTypes.regexp:
        case acorn_1.tokTypes.template:
        case acorn_1.tokTypes.invalidTemplate:
        case acorn_1.tokTypes.backQuote:
            return "string";
        case acorn_1.tokTypes.num:
        case acorn_1.tokTypes._null:
        case acorn_1.tokTypes._true:
        case acorn_1.tokTypes._false:
            return "literal";
        case acorn_1.tokTypes.name:
            if (["async", "await", "let", "yield"].includes(text))
                return "keyword";
            return;
        default:
            if (type.keyword)
                return "keyword";
    }
}
/** Offset ranges leave line endings, escape sequences and all other source text untouched. */
function javascriptHighlightRanges(code) {
    const ranges = [];
    try {
        (0, acorn_1.parse)(code, {
            ecmaVersion: "latest",
            sourceType: "module",
            allowReturnOutsideFunction: true,
            onComment: (_block, _text, start, end) => {
                ranges.push({ start, end, style: "comment" });
            },
            onToken: ({ type, start, end }) => {
                const style = tokenStyle(type, code.slice(start, end));
                if (style && start < end)
                    ranges.push({ start, end, style });
            },
        });
    }
    catch {
        return [];
    }
    return ranges.sort((a, b) => a.start - b.start);
}
