"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SnippetLibrary = SnippetLibrary;
const jsx_runtime_1 = require("preact/jsx-runtime");
const hooks_1 = require("preact/hooks");
const components_js_1 = require("./components.js");
const snippet_javascript_js_1 = require("./snippet-javascript.js");
function SnippetCode({ code, language }) {
    const content = (0, hooks_1.useMemo)(() => {
        if (language !== "javascript")
            return code;
        const ranges = (0, snippet_javascript_js_1.javascriptHighlightRanges)(code);
        if (!ranges.length)
            return code;
        const children = [];
        let offset = 0;
        for (const { start, end, style } of ranges) {
            if (start > offset)
                children.push(code.slice(offset, start));
            children.push((0, jsx_runtime_1.jsx)("span", { class: `mcp-view-snippet-token-${style}`, children: code.slice(start, end) }, start));
            offset = end;
        }
        children.push(code.slice(offset));
        return children;
    }, [code, language]);
    return (0, jsx_runtime_1.jsx)(components_js_1.CodeBlock, { children: content });
}
/** Search snippet metadata and present caller-supplied source as exact, selectable text. */
function SnippetLibrary({ entries = [], source, labels, busy = false, headerAction, onInspect, onBack, }) {
    const [filter, setFilter] = (0, hooks_1.useState)("");
    const search = (0, hooks_1.useRef)(null);
    const heading = (0, hooks_1.useRef)(null);
    (0, hooks_1.useLayoutEffect)(() => {
        (source ? heading.current : search.current)?.focus();
    }, [source]);
    const query = filter.trim().toLocaleLowerCase();
    const matches = entries.filter(({ name, description }) => name.toLocaleLowerCase().includes(query) ||
        description?.toLocaleLowerCase().includes(query));
    return ((0, jsx_runtime_1.jsxs)("section", { class: "mcp-view-snippet-library", "aria-label": labels.title, "aria-busy": busy, children: [(0, jsx_runtime_1.jsxs)("header", { class: "mcp-view-snippet-header", children: [(0, jsx_runtime_1.jsx)("h2", { children: labels.title }), !source && headerAction] }), source
                ? ((0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-snippet-source", children: [(0, jsx_runtime_1.jsx)("h3", { ref: heading, tabIndex: -1, children: (0, jsx_runtime_1.jsx)("bdi", { children: source.name }) }), source.description && (0, jsx_runtime_1.jsx)("p", { dir: "auto", children: source.description }), (0, jsx_runtime_1.jsx)("div", { class: "mcp-view-snippet-code", role: "region", "aria-label": labels.viewNamed(source.name), tabIndex: 0, dir: "ltr", children: (0, jsx_runtime_1.jsx)(SnippetCode, { code: source.code, language: source.language }) }), onBack && ((0, jsx_runtime_1.jsx)(components_js_1.Button, { disabled: busy, onClick: onBack, children: labels.back }))] }))
                : ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)("label", { class: "mcp-view-snippet-search", children: [labels.search, (0, jsx_runtime_1.jsx)("input", { class: "mcp-view-text-input", type: "search", ref: search, value: filter, onInput: (event) => setFilter(event.currentTarget.value) })] }), matches.length > 0
                            ? ((0, jsx_runtime_1.jsx)("ul", { class: "mcp-view-snippet-list", children: matches.map((entry) => ((0, jsx_runtime_1.jsxs)("li", { children: [(0, jsx_runtime_1.jsxs)("div", { children: [(0, jsx_runtime_1.jsx)("strong", { children: (0, jsx_runtime_1.jsx)("bdi", { children: entry.name }) }), entry.description && (0, jsx_runtime_1.jsx)("p", { dir: "auto", children: entry.description })] }), (0, jsx_runtime_1.jsx)("button", { class: "mcp-view-button", type: "button", disabled: busy || !onInspect, "aria-label": labels.viewNamed(entry.name), onClick: () => onInspect?.(entry), children: labels.view })] }, entry.id))) }))
                            : ((0, jsx_runtime_1.jsx)("p", { class: "mcp-view-snippet-empty", role: "status", children: entries.length ? labels.noMatch : labels.empty }))] }))] }));
}
