"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PATH_BAR_DEFAULT_MAX_VISIBLE = void 0;
exports.PathBar = PathBar;
exports.DrillHint = DrillHint;
exports.TypeBadge = TypeBadge;
exports.StaleBanner = StaleBanner;
exports.Slot3D = Slot3D;
exports.TreeList = TreeList;
exports.LimitGauge = LimitGauge;
exports.ArtifactRow = ArtifactRow;
const jsx_runtime_1 = require("preact/jsx-runtime");
const interactive_child_js_1 = require("./interactive-child.js");
const interaction_controls_js_1 = require("./interaction-controls.js");
/** Trailing items kept inline before the leading ones collapse. */
exports.PATH_BAR_DEFAULT_MAX_VISIBLE = 3;
/**
 * Controlled breadcrumb-like navigation without host or MCP side effects.
 *
 * A one-item path renders nothing: the first level has nothing to leave.
 */
function PathBar({ label, items, currentId, onSelect, maxVisible = exports.PATH_BAR_DEFAULT_MAX_VISIBLE, collapsedLabel, backLabel, className, }) {
    validatePath(items, currentId, maxVisible);
    if (items.length < 2)
        return null;
    const collapsed = collapsedLabel !== undefined && items.length > maxVisible
        ? items.slice(0, items.length - maxVisible)
        : [];
    const visible = items.slice(collapsed.length);
    const currentIndex = items.findIndex((item) => item.id === currentId);
    const previous = currentIndex > 0 ? items[currentIndex - 1] : undefined;
    return ((0, jsx_runtime_1.jsxs)("nav", { "aria-label": label, class: classes("mcp-view-path-bar", className), children: [backLabel !== undefined && previous !== undefined && ((0, jsx_runtime_1.jsx)("button", { "aria-label": backLabel, class: "mcp-view-path-bar-back", onClick: () => onSelect(previous.id), type: "button", children: (0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", children: "\u2039" }) })), collapsed.length > 0 && ((0, jsx_runtime_1.jsxs)("details", { class: "mcp-view-path-bar-collapsed", children: [(0, jsx_runtime_1.jsx)("summary", { "aria-label": collapsedLabel, class: "mcp-view-path-bar-collapsed-summary", children: (0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", children: `…${collapsed.length}` }) }), (0, jsx_runtime_1.jsx)("ul", { class: "mcp-view-path-bar-kept", children: collapsed.map((item, index) => ((0, jsx_runtime_1.jsx)("li", { children: (0, jsx_runtime_1.jsxs)("button", { class: "mcp-view-path-bar-kept-button", onClick: () => onSelect(item.id), type: "button", children: [(0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-path-bar-kept-rank", children: index + 1 }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-path-bar-kept-label", children: item.label }), item.detail !== undefined && ((0, jsx_runtime_1.jsx)("small", { class: "mcp-view-path-bar-kept-detail", children: item.detail }))] }) }, item.id))) })] })), (0, jsx_runtime_1.jsx)("ol", { class: "mcp-view-path-bar-list", children: visible.map((item) => {
                    const current = item.id === currentId;
                    return ((0, jsx_runtime_1.jsx)("li", { class: "mcp-view-path-bar-item", "data-current": current ? "true" : undefined, children: current
                            ? ((0, jsx_runtime_1.jsx)("span", { "aria-current": "page", class: "mcp-view-path-bar-current", children: item.label }))
                            : ((0, jsx_runtime_1.jsx)("button", { class: "mcp-view-path-bar-button", onClick: () => onSelect(item.id), type: "button", children: item.label })) }, item.id));
                }) })] }));
}
/**
 * Affordance for one available drill-down.
 *
 * Without a callback the hint degrades to plain text and shows no glyph, so a
 * host that cannot follow it never advertises a step that does not exist.
 */
function DrillHint(props) {
    const className = classes("mcp-view-drill-hint", props.className);
    if (props.onActivate === undefined) {
        return ((0, jsx_runtime_1.jsx)("span", { class: className, "data-degraded": "true", "data-direction": props.direction, children: props.label }));
    }
    return ((0, jsx_runtime_1.jsxs)("button", { "aria-label": props.actionLabel, class: className, "data-direction": props.direction, onClick: props.onActivate, type: "button", children: [props.direction === "in-view" && (0, jsx_runtime_1.jsx)(interaction_controls_js_1.DisclosureChevron, { expanded: false }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-drill-hint-label", children: props.label }), props.direction === "to-model" && ((0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-drill-hint-glyph", children: "~" }))] }));
}
/** Names what one level is, next to the path that reached it. */
function TypeBadge({ kind, label, className }) {
    return ((0, jsx_runtime_1.jsx)("span", { class: classes("mcp-view-type-badge", className), "data-kind": kind, children: label }));
}
/**
 * Marks the surrounding values as recorded earlier without hiding them.
 *
 * The banner refetches nothing and never replaces a dated value with a gap.
 */
function StaleBanner({ message, tone = "warning", action, className, }) {
    return ((0, jsx_runtime_1.jsxs)("div", { class: classes("mcp-view-stale-banner", className), "data-tone": tone, role: tone === "danger" ? "alert" : "status", children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-stale-banner-message", children: message }), action && ((0, jsx_runtime_1.jsx)("button", { class: "mcp-view-stale-banner-action", onClick: action.onActivate, type: "button", children: action.label }))] }));
}
/** Reserved area for a provider-owned 3D pose. The kit renders no geometry. */
function Slot3D({ label, statusLabel, children, className }) {
    const reserved = children === undefined || children === null || children === false;
    return ((0, jsx_runtime_1.jsxs)("figure", { "aria-label": label, class: classes("mcp-view-slot-3d", className), "data-reserved": reserved ? "true" : undefined, role: "group", children: [(0, jsx_runtime_1.jsx)("div", { class: "mcp-view-slot-3d-frame", children: reserved ? (0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-slot-3d-mark" }) : children }), (0, jsx_runtime_1.jsx)("figcaption", { class: "mcp-view-slot-3d-status", children: statusLabel })] }));
}
/** Controlled hierarchy with caller-owned type wording and coverage. */
function TreeList({ label, nodes, expandedIds, onToggle, toggleLabel, selectedId, onSelect, className, }) {
    validateTree(nodes);
    const expanded = new Set(expandedIds);
    return ((0, jsx_runtime_1.jsx)("ul", { "aria-label": label, class: classes("mcp-view-tree-list", className), role: "tree", children: nodes.map((node) => ((0, jsx_runtime_1.jsx)(TreeListItem, { expanded: expanded, level: 1, node: node, onSelect: onSelect, onToggle: onToggle, selectedId: selectedId, toggleLabel: toggleLabel }, node.id))) }));
}
function TreeListItem({ node, level, expanded, onToggle, toggleLabel, selectedId, onSelect, }) {
    const children = node.children ?? [];
    const open = children.length > 0 && expanded.has(node.id);
    const selected = selectedId === node.id;
    return ((0, jsx_runtime_1.jsxs)("li", { "aria-expanded": children.length > 0 ? open : undefined, "aria-level": level, "aria-selected": onSelect === undefined ? undefined : selected, class: "mcp-view-tree-list-item", "data-tone": node.tone, role: "treeitem", children: [(0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-tree-list-row", style: { paddingInlineStart: `${(level - 1) * 0.9}rem` }, onClick: children.length > 0 && !onSelect
                    ? (event) => {
                        if ((0, interactive_child_js_1.eventStartedInInteractiveChild)(event.currentTarget, event.target))
                            return;
                        onToggle(node.id);
                    }
                    : undefined, children: [children.length > 0
                        ? ((0, jsx_runtime_1.jsx)("button", { "aria-expanded": open, "aria-label": toggleLabel, class: "mcp-view-tree-list-twisty", onClick: (event) => {
                                event.stopPropagation();
                                onToggle(node.id);
                            }, type: "button", children: (0, jsx_runtime_1.jsx)(interaction_controls_js_1.DisclosureChevron, { expanded: open }) }))
                        : (0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-tree-list-twisty", "data-empty": "true" }), node.typeLabel !== undefined && ((0, jsx_runtime_1.jsx)("span", { class: "mcp-view-tree-list-type", children: node.typeLabel })), onSelect === undefined
                        ? (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-tree-list-label", children: node.label })
                        : ((0, jsx_runtime_1.jsx)("button", { class: "mcp-view-tree-list-label", onClick: () => onSelect(node.id), type: "button", children: node.label })), node.detail !== undefined && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-tree-list-detail", children: node.detail }), node.coverageLabel !== undefined && ((0, jsx_runtime_1.jsx)("span", { class: "mcp-view-tree-list-coverage", "data-tone": node.tone, children: node.coverageLabel }))] }), open && ((0, jsx_runtime_1.jsx)("ul", { class: "mcp-view-tree-list-group", role: "group", children: children.map((child) => ((0, jsx_runtime_1.jsx)(TreeListItem, { expanded: expanded, level: level + 1, node: child, onSelect: onSelect, onToggle: onToggle, selectedId: selectedId, toggleLabel: toggleLabel }, child.id))) }))] }));
}
/** Finite meter with an optional caller-supplied limit marker and explicit status text. */
function LimitGauge({ label, min, max, value, valueLabel, statusLabel, tone, limit, className, }) {
    validateGaugeRange(min, max, value, limit);
    const markerPosition = limit === undefined
        ? undefined
        : `${((limit.value - min) / (max - min)) * 100}%`;
    return ((0, jsx_runtime_1.jsxs)("div", { class: classes("mcp-view-limit-gauge", className), "data-tone": tone, children: [(0, jsx_runtime_1.jsx)("span", { class: "mcp-view-limit-gauge-label", children: label }), (0, jsx_runtime_1.jsxs)("div", { class: "mcp-view-limit-gauge-track", children: [(0, jsx_runtime_1.jsx)("meter", { "aria-label": label, "aria-valuetext": `${valueLabel}; ${statusLabel}`, class: "mcp-view-limit-gauge-meter", min: min, max: max, value: value }), limit && ((0, jsx_runtime_1.jsx)("span", { "aria-hidden": "true", class: "mcp-view-limit-gauge-marker", style: { left: markerPosition } }))] }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-limit-gauge-reading", children: valueLabel }), (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-limit-gauge-status", "data-tone": tone, children: statusLabel }), limit && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-limit-gauge-limit", children: limit.label })] }));
}
/** Immutable-artifact presentation; verification is displayed, never inferred or performed. */
function ArtifactRow(props) {
    const content = ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)("span", { class: "mcp-view-artifact-row-identity", children: [props.kind && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-artifact-row-kind", children: props.kind }), (0, jsx_runtime_1.jsx)("strong", { class: "mcp-view-artifact-row-label", children: props.label })] }), (0, jsx_runtime_1.jsx)("code", { class: "mcp-view-artifact-row-uri", children: props.uri }), props.fingerprint && ((0, jsx_runtime_1.jsxs)("span", { class: "mcp-view-artifact-row-fingerprint", children: [(0, jsx_runtime_1.jsx)("span", { children: props.fingerprint.algorithm }), (0, jsx_runtime_1.jsx)("code", { children: props.fingerprint.digest })] })), props.sizeLabel && (0, jsx_runtime_1.jsx)("span", { class: "mcp-view-artifact-row-size", children: props.sizeLabel }), props.verification && ((0, jsx_runtime_1.jsx)("span", { class: "mcp-view-artifact-row-verification", "data-tone": props.verification.tone, children: props.verification.label }))] }));
    const className = classes("mcp-view-artifact-row", props.className);
    if (props.onActivate) {
        return ((0, jsx_runtime_1.jsx)("button", { "aria-label": props.actionLabel, class: className, onClick: props.onActivate, type: "button", children: content }));
    }
    return (0, jsx_runtime_1.jsx)("article", { class: className, children: content });
}
function validatePath(items, currentId, maxVisible) {
    if (items.length === 0)
        throw new TypeError("PathBar items must not be empty");
    if (!Number.isInteger(maxVisible) || maxVisible < 1) {
        throw new RangeError("PathBar maxVisible must be a positive integer");
    }
    const ids = new Set();
    for (const item of items) {
        if (!item.id.trim())
            throw new TypeError("PathBar item ids must be non-empty");
        if (ids.has(item.id))
            throw new TypeError(`PathBar item id ${item.id} is duplicated`);
        ids.add(item.id);
    }
    if (!ids.has(currentId))
        throw new TypeError("PathBar currentId must identify one item");
}
function validateTree(nodes) {
    if (nodes.length === 0)
        throw new TypeError("TreeList nodes must not be empty");
    const ids = new Set();
    const walk = (candidates) => {
        for (const node of candidates) {
            if (!node.id.trim())
                throw new TypeError("TreeList node ids must be non-empty");
            if (ids.has(node.id))
                throw new TypeError(`TreeList node id ${node.id} is duplicated`);
            ids.add(node.id);
            if (node.children)
                walk(node.children);
        }
    };
    walk(nodes);
}
function validateGaugeRange(min, max, value, limit) {
    for (const [name, candidate] of [["min", min], ["max", max], ["value", value]]) {
        if (!Number.isFinite(candidate))
            throw new TypeError(`LimitGauge ${name} must be finite`);
    }
    if (max <= min)
        throw new RangeError("LimitGauge max must be greater than min");
    if (value < min || value > max) {
        throw new RangeError("LimitGauge value must be within min and max");
    }
    if (limit === undefined)
        return;
    if (!Number.isFinite(limit.value))
        throw new TypeError("LimitGauge limit must be finite");
    if (limit.value < min || limit.value > max) {
        throw new RangeError("LimitGauge limit must be within min and max");
    }
}
function classes(...values) {
    return values.filter(Boolean).join(" ");
}
