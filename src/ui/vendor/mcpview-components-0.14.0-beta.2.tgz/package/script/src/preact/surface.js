"use strict";
/** Preact bindings for result-driven MCP App component surfaces. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.preactSurfaceRenderer = exports.SurfaceAppError = void 0;
exports.definePreactComponent = definePreactComponent;
exports.startPreactSurfaceApp = startPreactSurfaceApp;
const preact_1 = require("preact");
const components_js_1 = require("../components.js");
const surface_app_js_1 = require("../surface-app.js");
const components_js_2 = require("./components.js");
var surface_app_js_2 = require("../surface-app.js");
Object.defineProperty(exports, "SurfaceAppError", { enumerable: true, get: function () { return surface_app_js_2.SurfaceAppError; } });
exports.preactSurfaceRenderer = {
    mount(component, props, target) {
        (0, preact_1.render)((0, preact_1.createElement)(component, props), target);
    },
    unmount(target) {
        (0, preact_1.render)(null, target);
    },
};
/** Turn one Preact component into a renderer-neutral mcp-view component. */
function definePreactComponent(descriptor, component, renderer = exports.preactSurfaceRenderer) {
    return (0, components_js_1.defineViewComponent)({
        descriptor,
        mount(target, context) {
            renderer.mount(component, {
                data: context.data,
                context: context.appContext,
                instanceId: context.instanceId,
                props: context.props,
            }, target);
            return () => renderer.unmount(target);
        },
    });
}
/**
 * Start a result-driven MCP App whose statuses render through the Preact
 * `StateMessage`. Everything else is `startSurfaceApp`; the shell keeps the
 * `mcp-view-preact-surface` class 0.5 viewers style.
 */
async function startPreactSurfaceApp(options, runtime) {
    const { statusClassName, renderStatus, surfaceClassName = "mcp-view-preact-surface", ...rest } = options;
    return await (0, surface_app_js_1.startSurfaceApp)({
        ...rest,
        surfaceClassName,
        renderStatus: renderStatus ?? ((status) => (0, components_js_2.renderStatusMessage)(status.message, {
            title: status.title,
            tone: status.tone,
            busy: status.busy,
            className: statusClassName,
        })),
    }, runtime);
}
