"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useActiveContext = useActiveContext;
const hooks_1 = require("preact/hooks");
/**
 * Subscribe to a controller owned outside the render tree. Surface remounts only
 * unsubscribe; they never clear, dispose or recreate the App's context queue.
 * Changing scope invalidates old handlers immediately, then queues the root clear.
 */
function useActiveContext(controller, scopeKey) {
    const [observed, setObserved] = (0, hooks_1.useState)(() => ({ controller, state: controller.getSnapshot() }));
    controller.setScope(scopeKey);
    const actions = (0, hooks_1.useMemo)(() => controller.actionsForScope(scopeKey), [controller, scopeKey]);
    (0, hooks_1.useLayoutEffect)(() => {
        const update = () => setObserved({ controller, state: controller.getSnapshot() });
        const unsubscribe = controller.subscribe(update);
        update();
        return unsubscribe;
    }, [controller]);
    (0, hooks_1.useLayoutEffect)(() => {
        void controller.clearPreviousScope();
    }, [controller, scopeKey]);
    const state = observed.controller === controller ? observed.state : controller.getSnapshot();
    return {
        ...state,
        ...actions,
        retry: controller.retry,
        dismissFailure: controller.dismissFailure,
        dismissEviction: controller.dismissEviction,
    };
}
