"use strict";
/**
 * Result-driven MCP App over one component registry, renderer-neutral.
 *
 * Every componentized viewer repeats the same lifecycle: install the theme,
 * show a status until the host sends a result, project that result into a
 * data model, mount the host-selected surface, remount it when the host
 * context changes, and make sure only the latest mount survives. Copies of
 * that loop drifted — one lost the generation guard in its error path,
 * another buffered recorded sessions by hand. This module is the loop, once.
 * Renderers plug in through `renderStatus`; `startPreactSurfaceApp` binds it
 * to the Preact `StateMessage`.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SurfaceAppError = void 0;
exports.startSurfaceApp = startSurfaceApp;
const view_1 = require("@mcpview/view");
const components_js_1 = require("./components.js");
const theme_js_1 = require("./theme.js");
const i18n_js_1 = require("./i18n.js");
/** Options refused at the boundary. Match on `code`, not on `message`. */
class SurfaceAppError extends TypeError {
    code;
    data;
    constructor(code, message, data = {}) {
        super(message);
        this.name = "SurfaceAppError";
        this.code = code;
        this.data = Object.freeze({ ...data });
    }
}
exports.SurfaceAppError = SurfaceAppError;
const DEFAULT_RUNTIME = { createApp: view_1.createMcpApp };
/**
 * Start a result-driven MCP App backed by a component registry.
 *
 * The registry may expose a default surface or be component-only. In the
 * latter case a host-selected surface is required and no artificial
 * standalone composition is invented.
 */
async function startSurfaceApp(options, runtime = DEFAULT_RUNTIME) {
    if (options.fromToolResult && options.validate) {
        throw new SurfaceAppError("SURFACE_APP_PROJECTION_CONFLICT", "startSurfaceApp accepts either fromToolResult or validate, not both", { recovery: "Keep fromToolResult and validate inside it, or drop it and keep validate." });
    }
    if (options.theme !== false)
        (0, theme_js_1.installMcpViewTheme)();
    const state = {};
    const project = options.fromToolResult ?? defaultProjection(options.validate);
    const session = options.viewerSession;
    let mounted;
    let pendingMount;
    let mountGeneration = 0;
    let navigation = Promise.resolve();
    let renderedHostContext;
    let hostLocale;
    let renderedStatusLocale;
    let activeStatus = { kind: "loading" };
    let closed = false;
    let removeHostContextListener;
    const reportError = (error) => {
        if (options.onError)
            options.onError(error);
        else
            console.error("[mcp-view-components] Surface App failed", error);
    };
    const message = (key, values) => (options.messages ?? i18n_js_1.mcpViewMessages)(hostLocale)(key, values);
    const resolveLabel = (value) => typeof value === "function" ? value(hostLocale) : value;
    const label = (override, key) => override === undefined ? message(key) : resolveLabel(override);
    const resolve = (display) => {
        switch (display.kind) {
            case "loading":
                return {
                    kind: "loading",
                    title: message("loadingTitle"),
                    message: label(options.loadingLabel, "loadingMessage"),
                    tone: "info",
                    busy: true,
                };
            case "empty":
                return {
                    kind: "empty",
                    title: message("emptyTitle"),
                    message: label(options.emptyLabel, "emptyMessage"),
                    tone: "neutral",
                    busy: false,
                };
            case "error":
                return {
                    kind: "error",
                    title: display.title === undefined
                        ? message(display.rejectionTitleKey ?? "errorTitle")
                        : resolveLabel(display.title),
                    message: resolveLabel(display.message),
                    tone: "danger",
                    busy: false,
                    ...(display.code === undefined ? {} : { code: display.code }),
                };
            case "notice":
                return {
                    kind: "notice",
                    title: display.title === undefined ? undefined : resolveLabel(display.title),
                    message: resolveLabel(display.message),
                    tone: display.tone ?? "neutral",
                    busy: display.busy ?? false,
                    ...(display.code === undefined ? {} : { code: display.code }),
                };
        }
    };
    const failure = (title, message) => ({
        kind: "error",
        title,
        message,
        tone: "danger",
        busy: false,
    });
    /**
     * Every navigation the App issues is chained here. The router serializes
     * navigations too, but a step chained behind the last one observes the
     * router settled — never a view mid-transition, when `currentView` throws
     * and `currentData` still names a result on its way out.
     */
    const enqueue = (step) => {
        const next = navigation.then(step);
        navigation = next.catch(() => { });
        return next;
    };
    const show = (navigate, display) => enqueue(() => {
        activeStatus = display.kind === "result" ? undefined : display;
        return display.kind === "result"
            ? navigate("surface", display.result)
            : navigate("status", resolve(display));
    });
    /** A projection that throws shows its failure; it never breaks the lifecycle. */
    const settle = async (compute, rejectionTitleKey) => {
        try {
            return await compute();
        }
        catch (error) {
            reportError(error);
            return { kind: "error", message: errorMessage(error), rejectionTitleKey };
        }
    };
    const hostAccess = (app) => ({
        locale: app.ctx.hostContext.locale,
        readServerResource: (uri) => app.ctx.app.readServerResource({ uri }),
    });
    const disposeSurface = async () => {
        mountGeneration += 1;
        await pendingMount;
        pendingMount = undefined;
        const active = mounted;
        mounted = undefined;
        await active?.dispose();
    };
    const status = (0, view_1.defineView)({
        onEnter(_context, next) {
            state.currentData = undefined;
            return next;
        },
        render: (context, next) => {
            hostLocale = context.hostContext.locale;
            renderedStatusLocale = hostLocale;
            return options.renderStatus(activeStatus ? resolve(activeStatus) : next);
        },
        onLeave: disposeSurface,
    });
    const surface = (0, view_1.defineView)({
        onEnter(_context, data) {
            state.currentData = data;
            return data;
        },
        render(context, data) {
            hostLocale = context.hostContext.locale;
            renderedHostContext = context.hostContext;
            const shell = document.createElement("div");
            shell.className = options.surfaceClassName ?? "mcp-view-surface-shell";
            let selected;
            // Named before the call: a `surfaceFor` that throws is the data-owned
            // path failing, not the host selection it was asked to replace.
            let owner = options.surfaceFor ? "data-owned" : "host-selected";
            try {
                const owned = options.surfaceFor?.(data);
                if (!owned)
                    owner = "host-selected";
                selected = owned
                    ? (0, components_js_1.defineComponentSurface)(owned)
                    : (0, components_js_1.activeComponentSurface)(options.registry, context.hostContext);
            }
            catch (error) {
                // A malformed surface must not unmount the route: the App stays on
                // its surface view and says why nothing is composed.
                reportError(error);
                shell.replaceChildren(options.renderStatus(failure(message("surfaceInvalidTitle"), message("surfaceInvalidMessage", { owner, error: errorMessage(error) }))));
                return shell;
            }
            if (!selected) {
                shell.replaceChildren(options.renderStatus({
                    kind: "surface-required",
                    title: message("surfaceRequiredTitle"),
                    message: label(options.surfaceRequiredLabel, "surfaceRequiredMessage"),
                    tone: "warning",
                    busy: false,
                }));
                return shell;
            }
            const generation = ++mountGeneration;
            pendingMount = (0, components_js_1.mountComponentSurface)({
                root: shell,
                registry: options.registry,
                data,
                appContext: context,
                hostContext: context.hostContext,
                surface: selected,
            }).then(async (next) => {
                if (generation !== mountGeneration) {
                    await next.dispose();
                    return;
                }
                mounted = next;
            }).catch((error) => {
                reportError(error);
                // A superseded mount that fails must not overwrite the newer route.
                if (generation !== mountGeneration)
                    return;
                shell.replaceChildren(options.renderStatus(failure(message("surfaceFailedTitle"), message("surfaceFailedMessage", { error: errorMessage(error) }))));
            });
            return shell;
        },
        onLeave: disposeSurface,
    });
    const handle = await runtime.createApp({
        info: options.info,
        root: options.root,
        ...(options.strict === undefined ? {} : { strict: options.strict }),
        views: { status, surface },
        initialView: "status",
        initialArgs: resolve({ kind: "loading" }),
        initialState: state,
        ...(session
            ? {
                viewerSession: {
                    validate: session.validate,
                    onSession: async (value, _payload, app) => {
                        hostLocale = app.ctx.hostContext.locale;
                        const next = await settle(() => session.toState(value, hostAccess(app)), "sessionRejectedTitle");
                        await show(app.navigate, next);
                    },
                    onInvalid: (payload) => session.onInvalid?.(payload.data),
                    onError: reportError,
                },
            }
            : {}),
        capabilities: {
            experimental: (0, components_js_1.componentCatalogCapabilities)(options.registry),
        },
        // Either notification means a run is under way: a host that does not
        // stream arguments sends only the complete `tool-input`.
        onToolInput: async (_params, app) => {
            await show(app.navigate, { kind: "loading" });
        },
        onToolInputPartial: async (_params, app) => {
            await show(app.navigate, { kind: "loading" });
        },
        onToolResult: async (result, app) => {
            hostLocale = app.ctx.hostContext.locale;
            const next = await settle(() => project(result, hostAccess(app)), "resultRejectedTitle");
            await show(app.navigate, next);
        },
        onTeardown: async () => {
            // The router runs the active view's onLeave, which disposes the surface.
            closed = true;
            removeHostContextListener?.();
            removeHostContextListener = undefined;
            try {
                await options.onTeardown?.();
            }
            catch (error) {
                reportError(error);
            }
        },
    });
    const surfaceHandle = {
        show: (display) => closed
            ? Promise.reject(new SurfaceAppError("SURFACE_APP_CLOSED", "The surface App has been torn down", {
                recovery: "Start a new App with startSurfaceApp; this handle cannot show anything.",
            }))
            : show(handle.navigate, display),
        dispose: () => handle.dispose(),
    };
    // A host teardown buffered during the handshake has already run: there is
    // no App left to listen to.
    if (closed)
        return surfaceHandle;
    /** Remount the displayed result when the host context moved since it rendered. */
    const remountIfStale = () => enqueue(async () => {
        const data = state.currentData;
        if (closed)
            return;
        if (data === undefined) {
            if (activeStatus && hostLocale !== renderedStatusLocale) {
                await handle.navigate("status", resolve(activeStatus));
            }
            return;
        }
        if (handle.ctx.hostContext === renderedHostContext) {
            return;
        }
        if (options.themeUpdates === "in-place" && renderedHostContext &&
            onlyThemeChanged(renderedHostContext, handle.ctx.hostContext)) {
            renderedHostContext = handle.ctx.hostContext;
            return;
        }
        await handle.navigate("surface", data);
    });
    const onHostContextChanged = () => {
        hostLocale = handle.ctx.hostContext.locale;
        if (options.documentLanguage) {
            document.documentElement.lang = options.documentLanguage(hostLocale);
        }
        (0, components_js_1.applySurfaceContext)(handle.ctx.hostContext, document.documentElement);
        remountIfStale().catch(reportError);
    };
    handle.ctx.app.addEventListener("hostcontextchanged", onHostContextChanged);
    removeHostContextListener = () => {
        handle.ctx.app.removeEventListener("hostcontextchanged", onHostContextChanged);
    };
    // Host notifications replayed by `createMcpApp` may have rendered a result
    // and then moved the host context before this listener existed.
    onHostContextChanged();
    return surfaceHandle;
}
/**
 * Conservative: only `theme` is exempt. Any other field whose JSON-shaped value
 * changed retains the normal remount behavior. Object key order is ignored;
 * array order is kept. No stringify, no coercion.
 */
function onlyThemeChanged(previous, next) {
    const keys = new Set([...Object.keys(previous), ...Object.keys(next)]);
    return [...keys].every((key) => key === "theme" || jsonValueEqual(previous[key], next[key]));
}
function jsonValueEqual(left, right) {
    if (left === right)
        return true;
    if (left === null || right === null)
        return false;
    if (Array.isArray(left) || Array.isArray(right)) {
        if (!Array.isArray(left) || !Array.isArray(right) || left.length !== right.length) {
            return false;
        }
        return left.every((item, index) => jsonValueEqual(item, right[index]));
    }
    if (!isPlainJsonObject(left) || !isPlainJsonObject(right))
        return false;
    const leftKeys = Object.keys(left);
    const rightKeys = Object.keys(right);
    if (leftKeys.length !== rightKeys.length)
        return false;
    return leftKeys.every((key) => Object.hasOwn(right, key) && jsonValueEqual(left[key], right[key]));
}
function isPlainJsonObject(value) {
    if (typeof value !== "object" || value === null)
        return false;
    const proto = Object.getPrototypeOf(value);
    return proto === Object.prototype || proto === null;
}
function defaultProjection(validate) {
    return (result) => {
        const data = (0, view_1.readResultData)(result, {
            fallback: "json-text",
            ...(validate ? { validate: (value) => validate(value) } : {}),
        });
        return data === undefined
            ? { kind: "empty" }
            : { kind: "result", result: data };
    };
}
function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
