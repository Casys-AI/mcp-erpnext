"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SurfaceAppError = exports.startSurfaceApp = void 0;
/**
 * Result-driven MCP App lifecycle over one component registry.
 *
 * Import as `@mcpview/components/surface`. This entry carries the
 * `@mcpview/view` App runtime (ext-apps); the package root stays free of it.
 *
 * @module
 */
require("./_dnt.polyfills.js");
var surface_app_js_1 = require("./src/surface-app.js");
Object.defineProperty(exports, "startSurfaceApp", { enumerable: true, get: function () { return surface_app_js_1.startSurfaceApp; } });
Object.defineProperty(exports, "SurfaceAppError", { enumerable: true, get: function () { return surface_app_js_1.SurfaceAppError; } });
