declare global {
    interface Object {
        /**
         * Determines whether an object has a property with the specified name.
         * @param o An object.
         * @param v A property name.
         */
        hasOwn(o: object, v: PropertyKey): boolean;
    }
}
export {};
declare global {
    interface Error {
        cause?: unknown;
    }
}
export {};
//# sourceMappingURL=_dnt.polyfills.d.ts.map