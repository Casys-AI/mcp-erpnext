"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SNIPPET_PANELS_META_KEY = exports.SNIPPET_SYNC_META_KEY = void 0;
exports.readSnippetPanels = readSnippetPanels;
exports.readSnippetSyncRules = readSnippetSyncRules;
exports.composeSnippetBoard = composeSnippetBoard;
exports.emitSnippetBoardEvent = emitSnippetBoardEvent;
/**
 * Browser-side composition of completed Code Mode results.
 * @module
 */
require("../../_dnt.polyfills.js");
const collector_js_1 = require("../core/collector/collector.js");
const extractor_js_1 = require("../core/collector/extractor.js");
const composer_js_1 = require("../core/composer/composer.js");
const sync_js_1 = require("./sync.js");
Object.defineProperty(exports, "SNIPPET_SYNC_META_KEY", { enumerable: true, get: function () { return sync_js_1.SNIPPET_SYNC_META_KEY; } });
/** MCP App result metadata containing the receipts selected by the program. */
exports.SNIPPET_PANELS_META_KEY = "io.mcpview/snippet-panels";
function record(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
}
function isPanel(value) {
    return record(value) &&
        typeof value.id === "string" && value.id.length > 0 &&
        typeof value.provider === "string" && value.provider.length > 0 &&
        typeof value.name === "string" && value.name.length > 0 &&
        typeof value.title === "string" && record(value.result);
}
/**
 * Return selected receipts in display order from the App-only MCP result metadata.
 * Invalid entries and repeated receipt IDs are ignored. Distinct receipts can
 * point to the same snippet and viewer.
 *
 * @example
 * ```ts
 * for (const panel of readSnippetPanels(toolResult)) {
 *   console.log(panel.provider, panel.name, panel.title);
 * }
 * ```
 */
function readSnippetPanels(result) {
    if (!record(result) || !record(result._meta))
        return [];
    const items = result._meta[exports.SNIPPET_PANELS_META_KEY];
    if (!Array.isArray(items))
        return [];
    const seen = new Set();
    const panels = [];
    for (const item of items) {
        if (isPanel(item) && !seen.has(item.id)) {
            panels.push(item);
            seen.add(item.id);
        }
    }
    return panels;
}
/** Read unique, declared Compose routes between panels in this result. */
function readSnippetSyncRules(result) {
    if (!record(result) || !record(result._meta))
        return [];
    const routes = result._meta[sync_js_1.SNIPPET_SYNC_META_KEY];
    const items = result._meta[exports.SNIPPET_PANELS_META_KEY];
    if (!Array.isArray(routes) || !Array.isArray(items))
        return [];
    const panels = new Map();
    const duplicates = new Set();
    for (const item of items) {
        if (!isPanel(item))
            continue;
        if (panels.has(item.id))
            duplicates.add(item.id);
        panels.set(item.id, (0, sync_js_1.readSnippetEventPorts)(item.events));
    }
    for (const id of duplicates)
        panels.delete(id);
    const rules = new Map();
    for (const item of routes) {
        const rule = (0, sync_js_1.parseSnippetSyncRule)(item);
        if (rule && (0, sync_js_1.supportsSnippetSync)(rule, panels))
            rules.set((0, sync_js_1.snippetSyncKey)(rule), rule);
    }
    return [...rules.values()];
}
/**
 * Build a Compose descriptor from the current execution, without making any provider calls.
 * Each child keeps its receipt in `context.panel` and adapter data in `context.view`.
 * The returned summary is shared as `sharedContext.value` when the execution has a value.
 * A data-only receipt needs a local view adapter to produce a child.
 *
 * @example
 * ```ts
 * const board = composeSnippetBoard(toolResult, {
 *   layout: "split",
 *   resolveView: (panel) => panel.provider === "metrics"
 *     ? { resourceUri: "ui://my-board/metrics" }
 *     : undefined,
 * });
 * ```
 */
function composeSnippetBoard(result, options = {}) {
    const summary = record(result) && record(result.structuredContent)
        ? result.structuredContent
        : {};
    const collector = (0, collector_js_1.createCollector)();
    const mountedPorts = new Map();
    for (const panel of readSnippetPanels(result)) {
        const view = options.resolveView?.(panel);
        const resourceUri = view?.resourceUri ?? (0, extractor_js_1.extractUiMeta)(panel.result)?.resourceUri;
        if (!resourceUri || !/^ui:\/\/[^\s]+$/.test(resourceUri))
            continue;
        const declared = (0, sync_js_1.readSnippetEventPorts)(panel.events);
        const viewEvents = (0, sync_js_1.readSnippetEventPorts)(view?.events);
        const panelEvents = view
            ? {
                emits: declared?.emits?.filter((name) => viewEvents?.emits?.includes(name)),
                accepts: declared?.accepts?.filter((name) => viewEvents?.accepts?.includes(name)),
            }
            : declared;
        mountedPorts.set(panel.id, panelEvents);
        collector.collect(`${panel.provider}:${panel.name}`, { _meta: { ui: { resourceUri } } }, {
            panel,
            panelEvents,
            ...(view?.context === undefined ? {} : { view: view.context }),
            ...(Object.hasOwn(summary, "value") ? { value: summary.value } : {}),
        }, { componentId: panel.id, surface: view?.surface });
    }
    const resources = collector.getResources();
    const layout = typeof options.layout === "function"
        ? options.layout(resources.length)
        : options.layout;
    const sync = readSnippetSyncRules(result).filter((rule) => (0, sync_js_1.supportsSnippetSync)(rule, mountedPorts));
    return (0, composer_js_1.buildCompositeUi)(resources, { layout: layout ?? "stack", sharedContext: ["value"], sync });
}
/**
 * Deliver a JSON event through the current board's declared routes to mounted views.
 * The board owns dispatch and supplies the receipts and data from its active UI.
 */
function emitSnippetBoardEvent(descriptor, sourceReceiptId, event, data, deliver) {
    const source = descriptor.children.find((child) => child.componentId === sourceReceiptId);
    if (!source || !(0, sync_js_1.readSnippetEventPorts)(source.context?.panelEvents)?.emits?.includes(event)) {
        return;
    }
    let payload;
    try {
        payload = JSON.stringify(data);
    }
    catch {
        return;
    }
    if (payload === undefined || payload.length > 128 * 1024)
        return;
    for (const rule of descriptor.sync) {
        if (rule.from !== source.slot || rule.event !== event || rule.to === "*")
            continue;
        const target = descriptor.children.find((child) => child.slot === rule.to);
        const ports = (0, sync_js_1.readSnippetEventPorts)(target?.context?.panelEvents);
        if (target?.componentId && ports?.accepts?.includes(rule.action)) {
            deliver(target.componentId, rule.action, JSON.parse(payload));
        }
    }
}
