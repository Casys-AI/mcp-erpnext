/**
 * mcp-compose — MCP Apps UI Orchestrator
 *
 * Lightweight library for composing and synchronizing multiple MCP Apps UIs
 * into composite dashboards.
 *
 * Pipeline: Collector -> Composer -> Renderer
 *
 * @module mcp-compose
 *
 * @example Basic usage
 * ```typescript
 * import { createCollector, buildCompositeUi, renderComposite } from "@mcpview/compose";
 *
 * // 1. Collect UI resources from MCP tool results
 * const collector = createCollector();
 * collector.collect("postgres:query", toolResult1, { query: "SELECT *" });
 * collector.collect("viz:render", toolResult2);
 *
 * // 2. Compose into a descriptor
 * const descriptor = buildCompositeUi(collector.getResources(), {
 *   layout: "split",
 *   sync: [{ from: "postgres:query", event: "filter", to: "viz:render", action: "update" }],
 * });
 *
 * // 3. Render to HTML
 * const html = renderComposite(descriptor);
 * ```
 */
import "./_dnt.polyfills.js";
export type { AdvertisedComponentCatalog, CollectedUiResource, ComponentSurface, ComponentSurfaceItem, ComponentSurfaceLayout, ComponentSurfaceResolution, CompositeUiDescriptor, JsonValue, McpToolResult, McpUiCsp, McpUiPermissions, McpUiResourceMeta, McpUiToolMeta, ReadyComponentSurface, ResolvedSyncRule, SurfaceGap, SurfaceLayoutType, UiLayout, UiOrchestration, UiPortSyncRule, UiSyncRule, UnresolvedComponentSurface, ValidationIssue, ValidationResult, ViewComponentDescriptor, ViewComponentEventPorts, } from "./src/core/types/mod.js";
export { ErrorCode, isValidLayout, UI_LAYOUT_PRESETS } from "./src/core/types/mod.js";
export { createCollector, extractUiMeta } from "./src/core/collector/mod.js";
export type { UiCollector } from "./src/core/collector/mod.js";
export { resolveSyncRules, validateSyncRules } from "./src/core/sync/mod.js";
export type { ResolutionResult } from "./src/core/sync/mod.js";
export { buildCompositeUi } from "./src/core/composer/mod.js";
export { resolveComponentSurface } from "./src/core/components/mod.js";
export { renderComposite } from "./src/host/renderer/mod.js";
export { createMcpSdkCollector } from "./src/sdk/mod.js";
export type { McpSdkCallToolResult, McpSdkCollector } from "./src/sdk/mod.js";
export { uiMeta } from "./src/sdk/mod.js";
export type { UiMetaOptions, UiMetaResult, UiMetaUi } from "./src/sdk/mod.js";
export { validateComposition } from "./src/sdk/mod.js";
export type { CompositionIssue, CompositionIssueCode, CompositionValidationResult, } from "./src/sdk/mod.js";
export { COMPOSE_EVENT_METHOD, composeEvents } from "./src/sdk/mod.js";
export type { ComposeEventHandler, ComposeEventPayload, ComposeEvents, ComposeSource, ComposeTarget, } from "./src/sdk/mod.js";
export type { CompositeUiHost, HostConfig } from "./src/host/mod.js";
//# sourceMappingURL=mod.d.ts.map