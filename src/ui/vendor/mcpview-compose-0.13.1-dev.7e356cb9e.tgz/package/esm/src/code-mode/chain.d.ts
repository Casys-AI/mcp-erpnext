import type { CallToolResult } from "@modelcontextprotocol/client";
import type { SnippetCatalog } from "@mcpview/server/snippets";
import type { ViewComponentEventPorts } from "../core/types/components.js";
import { type SnippetChainContext, type SnippetProvider } from "./providers.js";
/** Selected native result, available only to the MCP App in result metadata. */
export interface SnippetPanelReceipt {
    id: string;
    provider: string;
    name: string;
    title: string;
    result: CallToolResult;
    events?: ViewComponentEventPorts;
}
/** Execute input from the MCP tool using trusted context supplied separately by the host. */
export type SnippetChainExecutor = (input: Record<string, unknown>, context?: SnippetChainContext) => Promise<CallToolResult>;
/**
 * Run JavaScript against host-configured snippet providers. Selected results stay
 * out of guest memory except for their declared JSON value. Supplying a catalog
 * enables named chains for calls with a trusted scope.
 */
export declare function createSnippetChain(providers: ReadonlyMap<string, SnippetProvider>, catalog?: SnippetCatalog): SnippetChainExecutor;
//# sourceMappingURL=chain.d.ts.map