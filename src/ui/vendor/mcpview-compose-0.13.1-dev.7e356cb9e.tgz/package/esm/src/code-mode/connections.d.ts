import { Client } from "@modelcontextprotocol/client";
import { type SnippetChainContext, type SnippetProvider } from "./providers.js";
/** The MCP operation used by a snippet binding. The host retains ownership of supplied clients. */
export type SnippetMcpClient = Pick<Client, "callTool">;
/** Use an explicit HTTP endpoint or a client already authorized by the host. */
export type SnippetProviderBinding = {
    readonly alias: string;
    readonly snippets: readonly string[];
    readonly events?: SnippetProvider["events"];
} & ({
    readonly url: URL | string;
    readonly requestInit?: RequestInit;
    readonly client?: never;
} | {
    /** A resolver can select a borrowed client using the trusted request scope. */
    readonly client: SnippetMcpClient | ((context: SnippetChainContext) => SnippetMcpClient | Promise<SnippetMcpClient>);
    readonly url?: never;
    readonly requestInit?: never;
});
/** Connections available to a snippet chain. Close once the containing MCP server is stopped. */
export interface SnippetProviderConnections {
    readonly providers: ReadonlyMap<string, SnippetProvider>;
    close(): Promise<void>;
}
/**
 * Connect the explicitly configured upstream MCPs. HTTP bindings share one host-owned
 * upstream identity for the lifetime of this pool. For different authorities in a
 * multi-user server, supply a client resolver keyed by the authenticated request context.
 * A partial startup closes every connection opened by the pool.
 */
export declare function connectSnippetProviders(bindings: readonly SnippetProviderBinding[], options?: {
    readonly signal?: AbortSignal;
}): Promise<SnippetProviderConnections>;
//# sourceMappingURL=connections.d.ts.map