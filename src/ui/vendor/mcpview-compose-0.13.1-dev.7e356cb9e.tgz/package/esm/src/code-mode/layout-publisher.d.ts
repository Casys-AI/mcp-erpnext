/** Browser-side transport for user-edited Code Mode dashboard layouts. @module */
import { capturePanelLayout } from "../host/renderer/panel-controls.js";
import type { PanelLayoutSnapshot } from "./layout.js";
/** The conversation receives a reference to the staged geometry. */
export interface SnippetLayoutReceipt {
    /** Execution reference supplied by the server that owns the snippet. */
    runId: string;
    /** Monotonic revision within this mounted board. */
    revision: number;
    /** Whether the server has acknowledged this revision for saving. */
    status: "pending" | "ready" | "failed";
}
/** State available to an App's translated layout feedback and retry controls. */
export type SnippetLayoutStatus = SnippetLayoutReceipt["status"] | "local" | "restore-failed";
/** MCP Apps host methods and the board's context writer, which can aggregate panel selections. */
export interface SnippetBoardLayoutOptions {
    /** Connected MCP App providing the negotiated capabilities and the staging callback. */
    host: {
        getHostCapabilities(): {
            serverTools?: unknown;
            updateModelContext?: {
                structuredContent?: unknown;
                text?: unknown;
            };
        } | undefined;
        callServerTool(params: {
            name: string;
            arguments: {
                runId: string;
                revision: number;
                layout: PanelLayoutSnapshot;
            };
        }, options: {
            signal: AbortSignal;
        }): Promise<{
            structuredContent?: unknown;
            isError?: boolean;
        }>;
    };
    /** The board's context writer, shared with the panels in this App. */
    updateContext(update: {
        structuredContent: {
            snippetLayout: SnippetLayoutReceipt;
        };
    } | {
        content: {
            type: "text";
            text: string;
        }[];
    }): Promise<object>;
    /** App-only callback that stages the geometry and returns the matching run ID and revision. */
    stageTool: string;
    /** Execution metadata from the tool result. Without a reference, edits stay local. */
    runId?: unknown;
    /** Previously saved geometry supplied on replay. */
    savedLayout?: unknown;
    /** Signals the end of this board's display lifetime. */
    signal: AbortSignal;
    /** Receives updates for the App's own feedback, including recoverable errors. */
    onStatus?(status: SnippetLayoutStatus): void;
}
/**
 * Install the controls and restore a saved layout on a mounted board. Each
 * committed gesture stages its geometry and publishes an acknowledgement for
 * the next model turn. Pass the board's context writer when other panels share
 * its context. The returned callback retries the current layout after an error.
 */
export declare function connectSnippetBoardLayout(board: Parameters<typeof capturePanelLayout>[0], { host, updateContext, stageTool, runId, savedLayout, signal, onStatus }: SnippetBoardLayoutOptions): () => Promise<void>;
//# sourceMappingURL=layout-publisher.d.ts.map