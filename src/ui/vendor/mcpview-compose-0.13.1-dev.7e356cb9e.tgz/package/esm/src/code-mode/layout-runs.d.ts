/** Scoped layout drafts for saved Code Mode dashboards. @module */
import "../../_dnt.polyfills.js";
import { type PanelLayoutSnapshot } from "./layout.js";
/** Accepted widths per stable panel ID. Use an empty list for a fixed-width viewer. */
export type PanelWidths = ReadonlyMap<string, readonly number[]>;
/** Correlate app gestures and explicit snippet saves within a trusted execution scope. */
export declare class BoardLayoutRuns<Receipt = void> {
    private readonly runs;
    private readonly referenceTtlMs;
    private readonly maxPendingReferences;
    /** Pass the reference lifetime and capacity used by the snippet catalog. */
    constructor(options?: {
        referenceTtlMs?: number;
        maxPendingReferences?: number;
    });
    /** Register a successful run and return the saved layout if it fits today's panel declarations. */
    open(scope: string, runId: string, panels: PanelWidths, replayedName?: string, savedLayout?: unknown): PanelLayoutSnapshot | undefined;
    private find;
    /** Bind the name only after the scoped catalog has successfully saved the program. */
    saved(scope: string, runId: string, name: string): void;
    /** Acknowledge a committed layout, including an identical retry after a lost response. */
    stage(scope: string, runId: unknown, revision: unknown, snapshot: unknown): {
        runId: string;
        revision: number;
    };
    /** Return only acknowledged geometry for save or update. An update must target a bound name. */
    selected(scope: string, runId: string, revision?: unknown, updateName?: string): PanelLayoutSnapshot | undefined;
    /**
     * Apply the explicit update once per named board revision. Retain only the
     * latest receipt per bound name until this execution expires. A failed
     * write can be retried, and an older in-flight write finishes before a newer one.
     */
    commitUpdate(scope: string, runId: string, revision: number, name: string, write: (layout: PanelLayoutSnapshot) => Promise<Receipt>): Promise<Receipt>;
}
//# sourceMappingURL=layout-runs.d.ts.map