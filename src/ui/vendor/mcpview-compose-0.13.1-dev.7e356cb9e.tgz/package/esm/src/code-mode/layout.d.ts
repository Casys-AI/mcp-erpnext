/** Versioned layout preferences for a Code Mode dashboard. @module */
/** User-selected panel positions and supported widths, independent of ERP data and chat context. */
import "../../_dnt.polyfills.js";
export type PanelLayoutSnapshot = {
    readonly version: 1;
    /** Panel IDs in the template's original slot order. */
    readonly order: readonly string[];
    readonly widths: readonly {
        readonly panel: string;
        readonly width: number;
    }[];
    readonly placements: readonly {
        readonly panel: string;
        readonly beside: string;
        readonly side: "left" | "right" | "below";
    }[];
};
/** Validate an untrusted JSON snapshot, including placement anchors and their dependencies. */
export declare function isPanelLayoutSnapshot(value: unknown): value is PanelLayoutSnapshot;
//# sourceMappingURL=layout.d.ts.map