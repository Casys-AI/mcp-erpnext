/** Run selected snippets across host-configured MCP providers in one Code Mode call. */
import "../../_dnt.polyfills.js";
export { createSnippetChain, type SnippetChainExecutor, type SnippetPanelReceipt, } from "./chain.js";
export { connectSnippetProviders, type SnippetMcpClient, type SnippetProviderBinding, type SnippetProviderConnections, } from "./connections.js";
export type { SnippetChainContext, SnippetProvider } from "./providers.js";
export { createSnippetExecuteTool, type SnippetExecuteToolOptions } from "./tool.js";
export { type ProviderSnippetDefinition, registerSnippetProvider, type SnippetProviderOptions, } from "./provider-tools.js";
export { parseSnippetSyncRule, SNIPPET_SYNC_META_KEY, snippetSyncKey, supportsSnippetSync, } from "./sync.js";
//# sourceMappingURL=mod.d.ts.map