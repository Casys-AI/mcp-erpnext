/** Aggregate panel selections and board receipts for a single MCP Apps host. @module */
/** Replacement snapshot accepted by the host in its negotiated content formats. */
export interface PanelContextUpdate<Block> {
    /** Content blocks offered to hosts that accept text or resources. */
    content?: Block[];
    /** Structured context offered to hosts that accept JSON. */
    structuredContent?: Record<string, unknown>;
}
/** Send one context replacement and return the host acknowledgement. */
export type SendPanelContext<Block, Options, Response> = (update: PanelContextUpdate<Block>, options?: Options) => Promise<Response>;
/** Writers share a serialized host update queue and retain only acknowledged contributions. */
export interface PanelContexts<Block, Options, Response> {
    /** Bind a panel's selection to its identity and lifetime. */
    forPanel(id: string, title: string, signal: AbortSignal): SendPanelContext<Block, Options, Response>;
    /**
     * Publish board metadata using its own lifetime and top-level structured keys.
     * Compose reserves the `panels` key to group panel selections.
     */
    forBoard(signal: AbortSignal): SendPanelContext<Block, Options, Response>;
    /** Send a replacement snapshot after one or more contributor lifetimes end. */
    clear(): Promise<void>;
}
/** One host snapshot contains the acknowledged selections of every mounted panel. */
export declare function createPanelContexts<Block, Options, Response extends object>(send: SendPanelContext<Block, Options, Response>, clearErrorMessage?: () => string): PanelContexts<Block, Options, Response>;
//# sourceMappingURL=panel-contexts.d.ts.map