import type { McpApp, MCPTool, ToolHandlerContext } from "@mcpview/server";
/** A named, host-owned snippet. The runner replays it using the current caller's authority. */
export interface ProviderSnippetDefinition {
    readonly name: string;
    readonly description: string;
    readonly inputSchema: Record<string, unknown>;
    readonly run: (input: Record<string, unknown>, context?: ToolHandlerContext) => Record<string, unknown> | Promise<Record<string, unknown>>;
}
/** Discovery and replay policy for one upstream Code Mode provider. */
export interface SnippetProviderOptions {
    readonly snippets: readonly ProviderSnippetDefinition[];
    /** Evaluated for each listing and again for each replay, before reading the snippet input. */
    readonly authorize?: (name: string, context?: ToolHandlerContext) => boolean | Promise<boolean>;
    /** OAuth scopes enforced on both discovery and replay by the MCPView host. */
    readonly requiredScopes?: readonly string[];
    readonly runAnnotations?: MCPTool["annotations"];
    /** Static native MCP App resource if all served snippets use the same viewer. */
    readonly runResourceUri?: string;
}
/**
 * Register `list_snippets` and `run_snippet`. Expose selected saved programs by name.
 * A successful runner returns its native MCP response with a JSON projection at
 * `structuredContent.value`. Provider-only view metadata is forwarded intact.
 *
 * @example
 * ```ts
 * registerSnippetProvider(app, {
 *   snippets: [{
 *     name: "overdue", description: "List overdue invoices",
 *     inputSchema: { type: "object" },
 *     run: (input, context) => replayInvoiceSnippet("overdue", input, context),
 *   }],
 *   requiredScopes: ["invoices:read"],
 * });
 * ```
 */
export declare function registerSnippetProvider(server: Pick<McpApp, "registerTool" | "getToolNames">, options: SnippetProviderOptions): void;
//# sourceMappingURL=provider-tools.d.ts.map