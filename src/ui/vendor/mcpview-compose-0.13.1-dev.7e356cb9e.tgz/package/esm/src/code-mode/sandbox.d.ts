/** Maximum source length accepted by the code-mode execute tool. */
export declare const maxCodeLength = 16384;
/** Serialize data crossing the QuickJS boundary within the supplied limit. */
export declare function encodeValue(value: unknown, limit?: number): string;
/**
 * Run a function body in an isolated QuickJS context. Only JSON and explicit snippet
 * operations cross into the host. Execute host requests when the guest yields.
 */
export declare function runProgram(code: string, params: Record<string, unknown>, invoke: (operation: string, args: unknown[], signal: AbortSignal) => Promise<unknown>, callerSignal?: AbortSignal): Promise<unknown>;
//# sourceMappingURL=sandbox.d.ts.map