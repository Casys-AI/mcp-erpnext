import type { ViewComponentEventPorts } from "../core/types/components.js";
import type { UiSyncRule } from "../core/types/sync-rules.js";
/** App-only metadata for explicit, receipt-scoped Compose rules. */
export declare const SNIPPET_SYNC_META_KEY = "io.mcpview/snippet-sync";
export declare function isPortName(value: unknown): value is string;
export declare function snippetPorts(events: Readonly<Record<string, ViewComponentEventPorts>> | undefined, name: string): ViewComponentEventPorts | undefined;
export declare function readSnippetEventPorts(value: unknown): ViewComponentEventPorts | undefined;
export declare function parseSnippetSyncRule(value: unknown): UiSyncRule | undefined;
export declare function supportsSnippetSync(rule: UiSyncRule, panels: ReadonlyMap<string, ViewComponentEventPorts | undefined>): boolean;
export declare function snippetSyncKey({ from, event, to, action }: UiSyncRule): string;
//# sourceMappingURL=sync.d.ts.map