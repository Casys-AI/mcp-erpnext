import type { MCPTool } from "@mcpview/server";
import type { SnippetProvider } from "./providers.js";
/** Configure the single model-facing tool and its MCP Apps board resource. */
export interface SnippetExecuteToolOptions {
    readonly resourceUri: string;
    readonly providers: ReadonlyMap<string, Pick<SnippetProvider, "names" | "events">>;
    /** Enable this when the chain uses a catalog and the host supplies a trusted scope. */
    readonly savedChains?: boolean;
    readonly annotations?: MCPTool["annotations"];
}
/** Build the tool declaration for registration with an MCPView server. */
export declare function createSnippetExecuteTool(options: SnippetExecuteToolOptions): MCPTool;
//# sourceMappingURL=tool.d.ts.map