/**
 * UI metadata extractor — extracts `_meta.ui` from MCP tool results.
 *
 * @module collector/extractor
 */
import type { McpUiToolMeta } from "../types/mcp-apps.js";
/**
 * Extract UI metadata from an MCP tool call result.
 *
 * Looks for `_meta.ui.resourceUri` in the result object.
 * Returns `null` if the result is not an object, has no `_meta`,
 * or has no `ui.resourceUri`.
 *
 * @param result - Raw MCP tool call result (unknown shape)
 * @returns Extracted UI metadata, or `null` if none found
 *
 * @example
 * ```typescript
 * const meta = extractUiMeta({
 *   content: [{ type: "text", text: "OK" }],
 *   _meta: { ui: { resourceUri: "ui://pg/table/1" } },
 * });
 * // meta === { resourceUri: "ui://pg/table/1" }
 * ```
 *
 * @example No UI metadata
 * ```typescript
 * const meta = extractUiMeta({ content: [{ type: "text", text: "OK" }] });
 * // meta === null
 * ```
 */
export declare function extractUiMeta(result: unknown): McpUiToolMeta | null;
//# sourceMappingURL=extractor.d.ts.map