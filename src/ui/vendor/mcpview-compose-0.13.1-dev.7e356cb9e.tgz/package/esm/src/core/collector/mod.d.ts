/**
 * UI resource collector module.
 *
 * @module collector
 */
export { createCollector } from "./collector.js";
export type { UiCollector } from "./collector.js";
export { extractUiMeta } from "./extractor.js";
//# sourceMappingURL=mod.d.ts.map