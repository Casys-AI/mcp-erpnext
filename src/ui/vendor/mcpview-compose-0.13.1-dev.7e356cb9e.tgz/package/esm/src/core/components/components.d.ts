/** Pure resolution of a requested small-component surface against an App catalog. */
import type { AdvertisedComponentCatalog, ComponentSurface, ComponentSurfaceResolution } from "../types/components.js";
export declare function resolveComponentSurface(catalog: AdvertisedComponentCatalog, requested?: ComponentSurface): ComponentSurfaceResolution;
//# sourceMappingURL=components.d.ts.map