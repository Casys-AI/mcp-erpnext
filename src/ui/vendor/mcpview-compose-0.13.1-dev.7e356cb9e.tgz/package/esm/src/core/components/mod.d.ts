export { resolveComponentSurface } from "./components.js";
//# sourceMappingURL=mod.d.ts.map