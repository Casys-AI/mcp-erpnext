/**
 * Composite UI builder — assembles descriptor from resources + orchestration.
 *
 * @module composer/composer
 */
import type { CollectedUiResource } from "../types/resources.js";
import type { CompositeUiDescriptor } from "../types/descriptor.js";
import type { UiOrchestration } from "../types/orchestration.js";
/**
 * Build a composite UI descriptor from collected resources.
 *
 * Resolves tool names in sync rules to slot indices, extracts shared context,
 * and generates a unique workflow ID.
 *
 * @param resources - UI resources collected during tool execution
 * @param orchestration - Optional layout, sync, and shared context configuration
 * @returns Composite UI descriptor ready for rendering
 *
 * @example
 * ```typescript
 * const descriptor = buildCompositeUi(
 *   [
 *     { source: "postgres:query", resourceUri: "ui://pg/table/1", slot: 0 },
 *     { source: "viz:render", resourceUri: "ui://viz/chart/2", slot: 1 },
 *   ],
 *   {
 *     layout: "split",
 *     sync: [{ from: "postgres:query", event: "filter", to: "viz:render", action: "update" }],
 *   },
 * );
 * // descriptor.sync[0] === { from: 0, event: "filter", to: 1, action: "update" }
 * ```
 */
export declare function buildCompositeUi(resources: CollectedUiResource[], orchestration?: UiOrchestration): CompositeUiDescriptor;
//# sourceMappingURL=composer.d.ts.map