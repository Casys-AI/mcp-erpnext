/**
 * Composite UI builder module.
 *
 * @module composer
 */
export { buildCompositeUi } from "./composer.js";
//# sourceMappingURL=mod.d.ts.map