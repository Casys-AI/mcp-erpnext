/**
 * Core composition primitives — types, collector, sync, composer, renderer.
 *
 * @module core
 */
import "../../_dnt.polyfills.js";
export type { AdvertisedComponentCatalog, CollectedUiResource, ComponentSurface, ComponentSurfaceItem, ComponentSurfaceLayout, ComponentSurfaceResolution, CompositeUiDescriptor, JsonValue, McpToolResult, McpUiCsp, McpUiPermissions, McpUiResourceMeta, McpUiToolMeta, ReadyComponentSurface, ResolvedSyncRule, SurfaceGap, SurfaceLayoutType, UiLayout, UiOrchestration, UiPortSyncRule, UiSyncRule, UnresolvedComponentSurface, ValidationIssue, ValidationResult, ViewComponentDescriptor, ViewComponentEventPorts, } from "./types/mod.js";
export { ErrorCode, isLayoutAreas, isLayoutPreset, isValidLayout, UI_LAYOUT_PRESETS, } from "./types/mod.js";
export { createCollector, extractUiMeta } from "./collector/mod.js";
export type { UiCollector } from "./collector/mod.js";
export { resolveSyncRules, validateSyncRules } from "./sync/mod.js";
export type { ResolutionResult } from "./sync/mod.js";
export { buildCompositeUi } from "./composer/mod.js";
export { resolveComponentSurface } from "./components/mod.js";
//# sourceMappingURL=mod.d.ts.map