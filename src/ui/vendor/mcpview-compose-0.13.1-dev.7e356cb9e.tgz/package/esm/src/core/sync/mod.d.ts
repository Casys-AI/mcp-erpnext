/**
 * Sync rule engine — resolution and validation.
 *
 * @module sync
 */
export { resolveSyncRules } from "./resolver.js";
export type { ResolutionResult } from "./resolver.js";
export { validateSyncRules } from "./validator.js";
//# sourceMappingURL=mod.d.ts.map