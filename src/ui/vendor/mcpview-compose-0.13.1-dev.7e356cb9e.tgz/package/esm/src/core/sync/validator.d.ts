/**
 * Sync rule validator — checks rules for structural issues.
 *
 * @module sync/validator
 */
import type { UiSyncRule } from "../types/sync-rules.js";
import type { ValidationResult } from "../types/errors.js";
/**
 * Validate sync rules against known tool sources.
 *
 * Checks for:
 * - Orphan references (tool names not in `knownSources`)
 * - Circular routes (`from === to` for non-broadcast rules)
 *
 * @param rules - Sync rules to validate
 * @param knownSources - Known tool names from collected resources
 * @returns Validation result with any issues found
 *
 * @example
 * ```typescript
 * const result = validateSyncRules(
 *   [{ from: "a", event: "click", to: "b", action: "update" }],
 *   ["a", "b"],
 * );
 * // result.valid === true
 * ```
 *
 * @example Detecting orphan references
 * ```typescript
 * const result = validateSyncRules(
 *   [{ from: "unknown", event: "click", to: "a", action: "update" }],
 *   ["a"],
 * );
 * // result.valid === false
 * // result.issues[0].code === ErrorCode.ORPHAN_SYNC_REFERENCE
 * ```
 */
export declare function validateSyncRules(rules: UiSyncRule[], knownSources: string[]): ValidationResult;
//# sourceMappingURL=validator.d.ts.map