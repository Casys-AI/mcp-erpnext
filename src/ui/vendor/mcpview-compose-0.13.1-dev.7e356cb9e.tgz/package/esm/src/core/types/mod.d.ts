/**
 * Type definitions for mcp-compose.
 *
 * @module types
 */
export type { UiLayout } from "./layout.js";
export { isLayoutAreas, isLayoutPreset, isValidLayout, UI_LAYOUT_PRESETS } from "./layout.js";
export type { UiLayoutAreas, UiLayoutGap, UiLayoutPreset } from "./layout.js";
export type { ResolvedSyncRule, UiPortSyncRule, UiSyncRule } from "./sync-rules.js";
export type { UiOrchestration } from "./orchestration.js";
export type { CollectedUiResource } from "./resources.js";
export type { AdvertisedComponentCatalog, ComponentSurface, ComponentSurfaceItem, ComponentSurfaceLayout, ComponentSurfaceResolution, JsonValue, ReadyComponentSurface, SurfaceGap, SurfaceLayoutType, UnresolvedComponentSurface, ViewComponentDescriptor, ViewComponentEventPorts, } from "./components.js";
export type { CompositeUiDescriptor } from "./descriptor.js";
export type { McpToolResult, McpUiCsp, McpUiPermissions, McpUiResourceMeta, McpUiToolMeta, } from "./mcp-apps.js";
export { ErrorCode } from "./errors.js";
export type { ValidationIssue, ValidationResult } from "./errors.js";
//# sourceMappingURL=mod.d.ts.map