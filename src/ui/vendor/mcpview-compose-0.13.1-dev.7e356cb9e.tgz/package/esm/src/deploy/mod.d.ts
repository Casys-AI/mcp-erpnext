/**
 * Deploy module — publish dashboards as shareable links on Deno Deploy.
 *
 * Handles cloud deployment of relay workers, MCP servers, and
 * WebSocket tunnels for local-data MCPs.
 *
 * @module deploy
 */
import "../../_dnt.polyfills.js";
export type { DeployCredentials, DeployError, DeployManifestEntry, DeployRequest, DeployResult, DeployTransport, TunnelConnection, } from "./types.js";
export { DeployErrorCode } from "./types.js";
//# sourceMappingURL=mod.d.ts.map