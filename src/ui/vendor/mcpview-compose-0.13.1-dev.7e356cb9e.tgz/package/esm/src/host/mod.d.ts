/**
 * Host integration layer for mcp-compose.
 *
 * Defines the contracts for host applications that embed composite UIs,
 * and provides the HTML/CSS/JS renderer for generating self-contained dashboards.
 *
 * @module host
 */
import "../../_dnt.polyfills.js";
export type { CompositeUiHost, HostConfig } from "./types.js";
export { CASYS_COMPONENT_CATALOG_CAPABILITY_KEY, CASYS_SURFACE_CONTEXT_KEY, } from "./components-contract.js";
export { renderComposite } from "./renderer/mod.js";
export { serveDashboard } from "./serve.js";
export type { ServeDashboardHandle, ServeDashboardOptions } from "./serve.js";
//# sourceMappingURL=mod.d.ts.map