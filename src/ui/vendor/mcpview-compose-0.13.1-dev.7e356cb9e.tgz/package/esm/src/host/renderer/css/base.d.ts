/**
 * Base CSS with theme variables for light/dark mode.
 *
 * @module renderer/css/base
 */
/**
 * Generate base CSS with theme CSS custom properties.
 *
 * Supports:
 * - Light mode (default)
 * - Dark mode via `body.dark` class
 * - System preference via `prefers-color-scheme: dark`
 *
 * @returns CSS string
 *
 * @example
 * ```typescript
 * const css = getBaseCss();
 * // Contains --mcc-border-color, --mcc-bg-primary, etc.
 * ```
 */
export declare function getBaseCss(): string;
//# sourceMappingURL=base.d.ts.map