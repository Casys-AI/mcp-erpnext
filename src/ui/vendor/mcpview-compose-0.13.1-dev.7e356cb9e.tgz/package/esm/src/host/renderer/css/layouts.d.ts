/**
 * Layout-specific CSS generators.
 *
 * Supports preset layouts (split, tabs, grid, stack) and
 * agent-composed area grids.
 *
 * @module renderer/css/layouts
 */
import type { UiLayout } from "../../../core/types/layout.js";
/**
 * Generate CSS for a layout configuration.
 *
 * @param layout - Layout preset or areas grid
 * @returns CSS string
 *
 * @example Preset
 * ```typescript
 * getLayoutCss("split");
 * ```
 *
 * @example Areas grid
 * ```typescript
 * getLayoutCss({
 *   areas: [["filter", "list"], ["filter", "chart"]],
 *   columns: [1, 3],
 *   gap: "compact",
 * });
 * ```
 */
export declare function getLayoutCss(layout: UiLayout): string;
//# sourceMappingURL=layouts.d.ts.map