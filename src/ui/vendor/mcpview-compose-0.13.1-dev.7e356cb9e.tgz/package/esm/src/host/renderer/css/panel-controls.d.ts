/** Shared styles for the controls around mounted Compose viewers. */
export declare function getPanelControlsCss(): string;
//# sourceMappingURL=panel-controls.d.ts.map