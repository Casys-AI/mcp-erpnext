/**
 * HTML generator — renders a CompositeUiDescriptor to a self-contained HTML document.
 *
 * @module renderer/html-generator
 */
import type { CompositeUiDescriptor } from "../../core/types/descriptor.js";
import type { RenderCompositeOptions, ResolvedRendererSlotOptions } from "./options.js";
/**
 * Generate a self-contained HTML document from a composite UI descriptor.
 *
 * Produces valid HTML5 with:
 * - Layout CSS for the specified mode (split/tabs/grid/stack)
 * - Dark/light theme support via CSS variables
 * - Iframes for each child UI with `data-slot` and `data-source` attributes
 * - JavaScript event bus for cross-UI communication (JSON-RPC 2.0)
 *
 * @param descriptor - Composite UI descriptor from `buildCompositeUi`
 * @param options - Optional browser-host bridge configuration. With no options,
 *   child `resourceUri` values remain the iframe source and no server proxy
 *   capabilities are advertised.
 * @returns Complete HTML document string
 *
 * @example
 * ```typescript
 * const descriptor = buildCompositeUi(resources, { layout: "split" });
 * const html = renderComposite(descriptor);
 * // html is a complete HTML document ready to serve
 * ```
 */
export declare function renderComposite(descriptor: CompositeUiDescriptor, options?: RenderCompositeOptions): string;
/**
 * Resolve pure renderer options into one serialisable record per descriptor
 * child. This does not inspect the network or make runtime assumptions.
 */
export declare function resolveRendererSlots(descriptor: CompositeUiDescriptor, options?: RenderCompositeOptions): ReadonlyMap<number, ResolvedRendererSlotOptions>;
//# sourceMappingURL=html-generator.d.ts.map