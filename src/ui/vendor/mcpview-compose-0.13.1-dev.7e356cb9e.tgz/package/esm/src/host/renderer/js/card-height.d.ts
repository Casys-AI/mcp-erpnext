/** Connect the generated dashboard to its enclosing MCP Apps host as an App. */
export declare function generateCardHeightScript(): string;
//# sourceMappingURL=card-height.d.ts.map