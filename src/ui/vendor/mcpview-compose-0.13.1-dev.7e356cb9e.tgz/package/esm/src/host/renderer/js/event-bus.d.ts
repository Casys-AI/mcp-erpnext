/**
 * Event bus script generator for cross-UI communication.
 *
 * Generates JavaScript that implements:
 * - JSON-RPC 2.0 message handling via postMessage
 * - `ui/initialize` / `ui/notifications/initialized` MCP Apps lifecycle
 * - opt-in slot-local tools/resources proxying
 * - `ui/compose/event` dedicated cross-UI event routing
 * - Broadcast support via `to: "*"` on sync rules
 *
 * @module renderer/js/event-bus
 */
import type { CompositeUiDescriptor } from "../../../core/types/descriptor.js";
import type { ResolvedRendererSlotOptions } from "../options.js";
/**
 * Generate the event bus JavaScript for a composite UI.
 *
 * `slots` is deliberately a renderer-only value. It lets any serving runtime
 * map a child iframe to a local resource URL and local MCP proxy without the
 * browser code importing runtime types or knowing about server transports.
 *
 * @param descriptor - Composite UI descriptor with sync rules
 * @param slots - Fully-resolved browser host settings, keyed by slot
 * @returns JavaScript code string for inline `<script>` tag
 *
 * @example
 * ```typescript
 * const js = generateEventBusScript(descriptor, slots);
 * // js contains the MCP Apps lifecycle, local proxy, and sync routing
 * ```
 */
export declare function generateEventBusScript(descriptor: CompositeUiDescriptor, slots?: ReadonlyMap<number, ResolvedRendererSlotOptions>): string;
//# sourceMappingURL=event-bus.d.ts.map