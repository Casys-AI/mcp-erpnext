/**
 * HTML renderer module.
 *
 * @module renderer
 */
export { renderComposite } from "./html-generator.js";
export { resolveRendererSlots } from "./html-generator.js";
export type { RenderCompositeOptions, RendererSlotCapabilities, RendererSlotOptions, ResolvedRendererSlotOptions, } from "./options.js";
//# sourceMappingURL=mod.d.ts.map