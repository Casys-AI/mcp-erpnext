/**
 * Wire the grips on a Compose board. The standalone host embeds this function
 * as JavaScript, so its implementation must not depend on module-level values.
 * @param {HTMLElement} container
 * @param {AbortSignal} [signal]
 */
export function installPanelMovement(container: HTMLElement, signal?: AbortSignal | undefined): void;
//# sourceMappingURL=panel-movement.d.ts.map