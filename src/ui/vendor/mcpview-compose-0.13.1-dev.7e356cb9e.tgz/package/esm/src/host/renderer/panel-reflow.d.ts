/**
 * Fit each viewer's chosen width into the authored grid. Keep the actual
 * iframe mounted, and move a neighbor below when it cannot fit on its row.
 * This function is also embedded in the standalone host.
 * @param {HTMLElement} container
 */
export function createPanelReflow(container: HTMLElement): {
    layout: (choices: ReadonlyMap<HTMLElement, number>, preview?: {
        panel: HTMLElement;
        skeleton: HTMLElement;
    } | undefined, placements?: ReadonlyMap<HTMLElement, {
        beside: HTMLElement;
        side: "left" | "right" | "below";
    }> | undefined) => boolean;
    reset: () => void;
};
//# sourceMappingURL=panel-reflow.d.ts.map