/**
 * Choose one of a viewer's declared viewport widths from its bottom-right corner.
 * The standalone host embeds this function as JavaScript and supplies the layout
 * factory as the third argument. A viewer always owns its intrinsic height.
 * @param {HTMLElement} container
 * @param {AbortSignal} [signal]
 * @param {typeof createPanelReflow} [createReflow]
 */
export function installPanelResizing(container: HTMLElement, signal?: AbortSignal | undefined, createReflow?: typeof createPanelReflow | undefined): void;
import { createPanelReflow } from "./panel-reflow.js";
//# sourceMappingURL=panel-resizing.d.ts.map