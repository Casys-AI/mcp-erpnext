/** Read only the last committed layout preferences.
 * @param {HTMLElement} board
 * @returns {import("../../code-mode/layout.ts").PanelLayoutSnapshot | undefined}
 */
export function capturePanelLayout(board: HTMLElement): import("../../code-mode/layout.ts").PanelLayoutSnapshot | undefined;
/** Apply a saved preference only to matching panels and current viewer width declarations.
 * @param {HTMLElement} board
 * @param {unknown} snapshot
 */
export function restorePanelLayout(board: HTMLElement, snapshot: unknown): boolean;
//# sourceMappingURL=panel-snapshot.d.ts.map