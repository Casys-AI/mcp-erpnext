/**
 * Local dashboard server — serves composed HTML on localhost.
 *
 * Provides a simple `Deno.serve()` wrapper that serves the composed
 * dashboard HTML and opens it in the default browser.
 *
 * ## AX
 *
 * - **Single function**: `serveDashboard()` does everything.
 * - **Auto-open**: Opens the browser by default (configurable).
 * - **Graceful shutdown**: Returns a `shutdown()` handle.
 * - **Dynamic port**: Defaults to port 0 (OS picks a free port).
 *
 * @module host/serve
 */
/**
 * Options for `serveDashboard()`.
 */
export interface ServeDashboardOptions {
    /** Port to serve on (default: 0 = dynamic). */
    port?: number;
    /** Hostname to bind to (default: "localhost"). */
    hostname?: string;
    /** Open the browser automatically (default: true). */
    open?: boolean;
}
/**
 * Handle returned by `serveDashboard()`.
 */
export interface ServeDashboardHandle {
    /** The URL where the dashboard is served. */
    url: string;
    /** Shut down the server. */
    shutdown(): Promise<void>;
}
/**
 * Serve a composed dashboard HTML on localhost.
 *
 * @param html - Complete HTML string from `renderComposite()` or `composeDashboard()`
 * @param options - Server options
 * @returns Handle with URL and shutdown function
 *
 * @example
 * ```typescript
 * import { composeDashboard } from "@mcpview/compose/runtime";
 * import { serveDashboard } from "@mcpview/compose/host";
 *
 * const result = await composeDashboard({ template, manifests, args });
 * const handle = await serveDashboard(result.html);
 * // Dashboard available at handle.url
 * // Later: await handle.shutdown();
 * ```
 */
export declare function serveDashboard(html: string, options?: ServeDashboardOptions): Promise<ServeDashboardHandle>;
//# sourceMappingURL=serve.d.ts.map