/**
 * MCP server cluster — start, connect, call tools, and shut down MCP servers.
 *
 * Two transport modes:
 * - **stdio**: The cluster starts the server as a child process with `--http --port=0`.
 *   The server picks a free port and prints the URL on stderr. All communication
 *   then goes through HTTP (no JSON-RPC over stdio).
 * - **http**: The cluster connects to an already-running server via its URL.
 *
 * Both modes support the modern stateless MCP HTTP protocol and legacy
 * Streamable HTTP. `auto` probes stateless `server/discover` first; only a
 * server that explicitly rejects that protocol falls back to the official SDK
 * client, which performs initialization and retains its session.
 *
 * ## AX (Agent Experience)
 *
 * - **Fast fail**: Invalid manifests, connection failures, and tool call errors
 *   produce structured `RuntimeError` objects with machine-readable codes.
 * - **Deterministic cleanup**: `stopAll()` always runs in a `finally` block
 *   pattern. Process handles are tracked and killed on shutdown.
 * - **Timeout-aware**: Tool calls and server startup have configurable timeouts
 *   with clear error messages on expiry.
 * - **No magic**: The cluster does not retry failed calls or silently swallow
 *   errors. Callers decide retry policy.
 *
 * @module runtime/cluster
 */
import type { McpCluster, McpConnection, McpManifest } from "./types.js";
/**
 * Connect to an already-running MCP server via HTTP.
 *
 * Performs MCP protocol discovery/initialization rather than relying on a
 * non-standard `/health` endpoint.
 *
 * @param manifest - Server manifest with http transport
 * @returns Active connection
 * @throws RuntimeError if health check fails
 *
 * @example
 * ```typescript
 * const conn = await connectHttp({
 *   name: "einvoice",
 *   transport: { type: "http", url: "http://localhost:3015" },
 *   tools: [...],
 * });
 * const result = await conn.callTool("invoice_search", { customer_id: "C-1" });
 * ```
 */
export declare function connectHttp(manifest: McpManifest): Promise<McpConnection>;
/**
 * Start an MCP server as a child process and connect via HTTP.
 *
 * Launches the server with `--http --port=0` (dynamic port),
 * reads stderr to detect the listening URL, then communicates via HTTP.
 *
 * @param manifest - Server manifest with stdio transport
 * @param options - Startup options
 * @returns Active connection (with process handle for cleanup)
 * @throws RuntimeError if startup times out or fails
 *
 * @example
 * ```typescript
 * const conn = await startServer({
 *   name: "einvoice",
 *   transport: { type: "stdio", command: "deno", args: ["run", "server.ts"] },
 *   tools: [...],
 * });
 * ```
 */
export declare function startServer(manifest: McpManifest, options?: {
    timeoutMs?: number;
}): Promise<McpConnection>;
/**
 * Create a cluster manager for multiple MCP servers.
 *
 * @param manifests - All available manifests (keyed by name)
 * @param serverNames - Which servers to include in the cluster
 * @returns Cluster manager with startAll/stopAll/callTool
 *
 * @example
 * ```typescript
 * const cluster = createCluster(manifests, ["mcp-einvoice", "mcp-dataviz"]);
 * await cluster.startAll();
 * try {
 *   const result = await cluster.callTool("mcp-einvoice", "invoice_search", { id: "1" });
 * } finally {
 *   await cluster.stopAll();
 * }
 * ```
 */
export declare function createCluster(manifests: Map<string, McpManifest>, serverNames: string[]): McpCluster;
//# sourceMappingURL=cluster.d.ts.map