/**
 * Dashboard composition orchestrator.
 *
 * Wires together manifest loading, template parsing, arg injection,
 * server startup, tool calling, and the core pipeline to produce
 * a self-contained composite dashboard.
 *
 * ## AX (Agent Experience)
 *
 * - **Single entry point**: `composeDashboard()` does everything.
 *   `composeDashboardFromFiles()` adds file loading on top.
 * - **Structured warnings**: Non-fatal issues (tool without UI metadata)
 *   are collected as warnings, not thrown. The dashboard renders with
 *   whatever UIs were successfully collected.
 * - **Guaranteed cleanup**: Server processes are always stopped in `finally`,
 *   even on errors.
 * - **URI resolution**: `ui://server/...` URIs are automatically resolved
 *   to the server's actual HTTP base URL before rendering.
 *
 * @module runtime/compose
 */
import type { ComposeRequest, ComposeResult } from "./types.js";
/**
 * Compose a dashboard from a template + manifests + runtime args.
 *
 * Full flow:
 * 1. Validate template against manifests
 * 2. Start/connect MCP server cluster
 * 3. Call tools with injected args, collect UI resources
 * 4. Resolve `ui://` URIs to real HTTP URLs
 * 5. Build composite descriptor + render HTML (core pipeline)
 * 6. Shut down cluster
 *
 * @param request - Template, manifests, and runtime args
 * @returns Composite descriptor, rendered HTML, and warnings
 *
 * @example
 * ```typescript
 * const result = await composeDashboard({
 *   template,
 *   manifests,
 *   args: { customer_id: "CUST-001" },
 * });
 * // result.html is a complete dashboard
 * ```
 */
export declare function composeDashboard(request: ComposeRequest): Promise<ComposeResult>;
/**
 * Convenience: load manifests + template from files, then compose.
 *
 * @param manifestDir - Directory containing `.json` manifest files
 * @param templatePath - Path to `.yaml` template file
 * @param args - Runtime arguments (injected into `{{placeholder}}` values)
 * @returns Composite result
 *
 * @example
 * ```typescript
 * const result = await composeDashboardFromFiles(
 *   "./manifests/",
 *   "./dashboards/sales.yaml",
 *   { customer_id: "CUST-001" },
 * );
 * await Deno.writeTextFile("dashboard.html", result.html);
 * ```
 */
export declare function composeDashboardFromFiles(manifestDir: string, templatePath: string, args?: Record<string, unknown>): Promise<ComposeResult>;
//# sourceMappingURL=compose.d.ts.map