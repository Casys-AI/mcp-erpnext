/**
 * Interactive local MCP Apps dashboard host.
 *
 * A composed dashboard is a parent MCP Apps host, not an upstream `/ui`
 * shortcut. Each panel is served on a distinct loopback origin so the parent
 * can verify `postMessage` origins even if an iframe later navigates away.
 * The parent owns the only MCP proxy endpoint and applies the panel's
 * captured server/resource/tool allow-lists before calling the cluster.
 *
 * @module runtime/host-dashboard
 */
import type { ComposeRequest, ComposeResult } from "./types.js";
import type { ComposedDashboardHandle, ServeComposedDashboardOptions } from "./host-dashboard-types.js";
/**
 * Compose and immediately serve an interactive local MCP Apps dashboard.
 *
 * This is the preferred lifecycle entry point. It retains the cluster only
 * while the returned handle is alive, and rolls it back if host startup fails.
 */
export declare function composeAndServeDashboard(request: ComposeRequest, options?: ServeComposedDashboardOptions): Promise<ComposedDashboardHandle>;
/**
 * Serve a previously composed, keep-alive result as an interactive dashboard.
 *
 * The returned main URL and every iframe listener bind to `127.0.0.1` only.
 * There is deliberately no hostname option: remote exposure requires an
 * authenticated, separately-designed deployment adapter.
 */
export declare function serveComposedDashboard(result: ComposeResult, options?: ServeComposedDashboardOptions): Promise<ComposedDashboardHandle>;
//# sourceMappingURL=host-dashboard.d.ts.map