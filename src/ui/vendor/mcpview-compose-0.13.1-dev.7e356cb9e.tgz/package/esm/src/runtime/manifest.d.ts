/**
 * Manifest parsing and validation.
 *
 * Reads static MCP server manifests from JSON files.
 * No server startup needed — manifests are generated at build time.
 *
 * @module runtime/manifest
 */
import type { McpManifest } from "./types.js";
/**
 * Validate a raw object as a manifest. Returns errors if invalid.
 *
 * @example
 * ```typescript
 * const { valid, errors } = validateManifest(data);
 * if (!valid) console.error(errors);
 * ```
 */
export declare function validateManifest(data: unknown): {
    valid: boolean;
    errors: string[];
};
/**
 * Parse a JSON string into a validated McpManifest.
 *
 * @param json - Raw JSON string
 * @param filePath - Optional file path for error messages
 * @returns Parsed manifest
 * @throws RuntimeError on invalid JSON or validation failure
 *
 * @example
 * ```typescript
 * const manifest = parseManifest('{"name":"pg","command":"pg-mcp","tools":[{"name":"query"}]}');
 * ```
 */
export declare function parseManifest(json: string, filePath?: string): McpManifest;
/**
 * Load a manifest from a file path.
 *
 * @example
 * ```typescript
 * const manifest = await loadManifest("./manifests/postgres.json");
 * ```
 */
export declare function loadManifest(path: string): Promise<McpManifest>;
/**
 * Load all manifests from a directory (all `.json` files).
 *
 * @returns Map keyed by manifest name
 *
 * @example
 * ```typescript
 * const manifests = await loadManifests("./manifests/");
 * // manifests.get("postgres") → McpManifest
 * ```
 */
export declare function loadManifests(dirPath: string): Promise<Map<string, McpManifest>>;
//# sourceMappingURL=manifest.d.ts.map