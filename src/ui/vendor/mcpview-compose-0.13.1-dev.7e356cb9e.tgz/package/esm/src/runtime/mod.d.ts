/**
 * Runtime module — dashboard composition from manifests + templates.
 *
 * Handles I/O: reading manifests/templates, starting MCP servers,
 * calling tools, and feeding results into the core pipeline.
 *
 * @module runtime
 */
import "../../_dnt.polyfills.js";
export type { ComposeRequest, ComposeResult, DashboardTemplate, HttpTransport, McpCluster, McpConnection, McpHttpProtocol, McpListedResource, McpListedTool, McpListResourcesResult, McpListToolsResult, McpManifest, McpReadResourceResult, McpToolDeclaration, McpTransport, RuntimeError, StdioTransport, TemplateSource, TemplateToolCall, } from "./types.js";
export type { ComposedDashboardCsp, ComposedDashboardHandle, ComposedDashboardPanel, ComposedDashboardTool, ServeComposedDashboardOptions, } from "./host-dashboard-types.js";
export { RuntimeErrorCode } from "./types.js";
export { loadManifest, loadManifests, parseManifest, validateManifest } from "./manifest.js";
export { injectArgs, loadTemplate, parseTemplate, parseTemplateJson, validateTemplate, } from "./template.js";
export { connectHttp, createCluster, startServer } from "./cluster.js";
export { composeDashboard, composeDashboardFromFiles } from "./compose.js";
export { composeAndServeDashboard, serveComposedDashboard } from "./host-dashboard.js";
//# sourceMappingURL=mod.d.ts.map