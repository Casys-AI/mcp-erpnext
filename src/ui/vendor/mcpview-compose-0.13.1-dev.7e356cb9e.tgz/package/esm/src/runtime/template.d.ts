/**
 * Dashboard template parsing, validation, and arg injection.
 *
 * Canonical agent-authored templates are JSON. YAML remains supported for existing human-authored
 * dashboards. Both define which MCP servers to start, which tools to call, and how to arrange the
 * resulting UIs.
 * Runtime args are injected via `{{placeholder}}` syntax.
 *
 * @module runtime/template
 */
import type { DashboardTemplate, McpManifest, TemplateSource, TemplateToolCall } from "./types.js";
/**
 * Validate a template against available manifests.
 *
 * Checks that each source references an existing manifest
 * and each tool call references a tool in that manifest.
 *
 * @example
 * ```typescript
 * const { valid, errors } = validateTemplate(template, manifests);
 * ```
 */
export declare function validateTemplate(template: DashboardTemplate, manifests: Map<string, McpManifest>): {
    valid: boolean;
    errors: string[];
};
/** Resolve the stable component identity used by slots, routes, and layout areas. */
export declare function resolveTemplateComponentId(source: TemplateSource, _sourceIndex: number, call: TemplateToolCall, callIndex: number): string;
/**
 * Parse a YAML string into a DashboardTemplate.
 *
 * @param yaml - Raw YAML string
 * @param filePath - Optional file path for error messages
 * @returns Parsed template
 * @throws RuntimeError on invalid YAML or structure
 *
 * @example
 * ```typescript
 * const template = parseTemplate(`
 *   name: My Dashboard
 *   sources:
 *     - manifest: postgres
 *       calls:
 *         - tool: query
 *   orchestration:
 *     layout: split
 * `);
 * ```
 */
export declare function parseTemplate(yaml: string, filePath?: string): DashboardTemplate;
/** Parse the canonical agent-facing JSON dashboard manifest. */
export declare function parseTemplateJson(json: string, filePath?: string): DashboardTemplate;
/**
 * Load a template from a file path.
 *
 * @example
 * ```typescript
 * const template = await loadTemplate("./dashboards/sales.yaml");
 * ```
 */
export declare function loadTemplate(path: string): Promise<DashboardTemplate>;
/**
 * Inject runtime args into tool call arguments.
 *
 * Replaces `{{key}}` placeholders in string values with the corresponding
 * runtime arg. If the entire value is a `{{key}}` placeholder, the replacement
 * preserves the original type. Partial placeholders produce string concatenation.
 *
 * Does not mutate the input — returns new TemplateToolCall objects.
 *
 * @example
 * ```typescript
 * const calls = [{ tool: "query", args: { id: "{{customer_id}}" } }];
 * const result = injectArgs(calls, { customer_id: "C-123" });
 * // result[0].args.id === "C-123"
 * ```
 */
export declare function injectArgs(calls: TemplateToolCall[], args: Record<string, unknown>): TemplateToolCall[];
//# sourceMappingURL=template.d.ts.map