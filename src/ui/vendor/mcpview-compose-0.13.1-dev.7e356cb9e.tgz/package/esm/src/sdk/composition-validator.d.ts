/**
 * Composition validator — validates tool definitions with _meta.ui against sync rules.
 *
 * Performs both structural validation (delegated to core/sync/validator) and
 * semantic validation (emits/accepts coherence with sync rules).
 *
 * @module sdk/composition-validator
 */
import type { UiPortSyncRule, UiSyncRule } from "../core/types/sync-rules.js";
import type { UiMetaUi } from "./ui-meta-builder.js";
/**
 * Issue codes for composition validation.
 *
 * Extends core ErrorCode with SDK-level semantic checks.
 */
export type CompositionIssueCode = "ORPHAN_SYNC_REFERENCE" | "CIRCULAR_SYNC_RULE" | "ORPHAN_EMIT" | "ORPHAN_ACCEPT" | "PORT_SYNC_NO_COMPATIBLE_PEER" | "SYNC_EVENT_NOT_EMITTED" | "SYNC_ACTION_NOT_ACCEPTED";
/**
 * A composition validation issue.
 *
 * @example
 * ```typescript
 * const issue: CompositionIssue = {
 *   code: "ORPHAN_EMIT",
 *   message: 'Tool "erp:customers" emits "filterChanged" but no sync rule routes it',
 *   tool: "erp:customers",
 *   event: "filterChanged",
 * };
 * ```
 */
export interface CompositionIssue {
    /** Machine-readable issue code. */
    code: CompositionIssueCode;
    /** Human-readable description. */
    message: string;
    /** Tool name involved (if applicable). */
    tool?: string;
    /** Event or action name involved (if applicable). */
    event?: string;
    /** Path to the problematic value (for structural issues from core). */
    path?: string;
}
/**
 * Result of composition validation.
 */
export interface CompositionValidationResult {
    /** Whether the composition is valid (no issues). */
    valid: boolean;
    /** List of issues found. */
    issues: CompositionIssue[];
}
/**
 * Minimal shape of a tool definition with `_meta.ui`.
 */
interface ToolWithMeta {
    name: string;
    _meta: {
        ui: UiMetaUi;
    };
}
/**
 * Validate a set of tool definitions against sync rules.
 *
 * Performs two levels of validation:
 * 1. **Structural** (via core `validateSyncRules`): unknown tool names, circular routes
 * 2. **Semantic**: emits/accepts coherence with sync rule events and actions
 *
 * Tools without `emits`/`accepts` declarations skip semantic checks — they are
 * treated as permissive for backwards compatibility.
 *
 * @param tools - Tool definitions with `_meta.ui` (from `uiMeta()`)
 * @param syncRules - Sync rules to validate against
 * @param portSyncRules - Dynamic policies resolved from active component ports
 * @returns Validation result with issues
 *
 * @example
 * ```typescript
 * import { uiMeta, validateComposition } from "@mcpview/compose";
 *
 * const tools = [
 *   { name: "erp:customers", ...uiMeta({ resourceUri: "ui://erp/customers", emits: ["rowSelected"] }) },
 *   { name: "viz:chart", ...uiMeta({ resourceUri: "ui://viz/chart", accepts: ["rowSelected"] }) },
 * ];
 * const syncRules = [
 *   { from: "erp:customers", event: "rowSelected", to: "viz:chart", action: "highlight" },
 * ];
 *
 * const result = validateComposition(tools, syncRules);
 * if (!result.valid) {
 *   for (const issue of result.issues) {
 *     console.warn(`[${issue.code}] ${issue.message}`);
 *   }
 * }
 * ```
 */
export declare function validateComposition(tools: ToolWithMeta[], syncRules: UiSyncRule[], portSyncRules?: UiPortSyncRule[]): CompositionValidationResult;
export {};
//# sourceMappingURL=composition-validator.d.ts.map