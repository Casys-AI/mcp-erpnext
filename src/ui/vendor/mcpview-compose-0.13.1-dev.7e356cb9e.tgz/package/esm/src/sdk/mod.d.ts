/**
 * MCP SDK adapters — optional convenience wrappers for MCP client SDKs.
 *
 * @module sdk
 */
import "../../_dnt.polyfills.js";
export { createMcpSdkCollector } from "./mcp-sdk.js";
export type { McpSdkCallToolResult, McpSdkCollector } from "./mcp-sdk.js";
export { uiMeta } from "./ui-meta-builder.js";
export type { UiMetaOptions, UiMetaResult, UiMetaUi } from "./ui-meta-builder.js";
export { validateComposition } from "./composition-validator.js";
export type { CompositionIssue, CompositionIssueCode, CompositionValidationResult, } from "./composition-validator.js";
export { COMPOSE_EVENT_METHOD, composeEvents } from "./compose-events.js";
export type { ComposeEventHandler, ComposeEventPayload, ComposeEvents, ComposeSource, ComposeTarget, } from "./compose-events.js";
//# sourceMappingURL=mod.d.ts.map