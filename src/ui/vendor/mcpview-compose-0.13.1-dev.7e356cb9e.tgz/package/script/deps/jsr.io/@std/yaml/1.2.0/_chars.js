"use strict";
// Ported from js-yaml v3.13.1:
// https://github.com/nodeca/js-yaml/commit/665aadda42349dcae869f12040d9b10ef18d12da
// Copyright 2011-2015 by Vitaly Puzrin. All rights reserved. MIT license.
// Copyright 2018-2026 the Deno authors. MIT license.
Object.defineProperty(exports, "__esModule", { value: true });
exports.RIGHT_CURLY_BRACKET = exports.VERTICAL_LINE = exports.LEFT_CURLY_BRACKET = exports.GRAVE_ACCENT = exports.RIGHT_SQUARE_BRACKET = exports.BACKSLASH = exports.LEFT_SQUARE_BRACKET = exports.COMMERCIAL_AT = exports.QUESTION = exports.GREATER_THAN = exports.SMALLER_THAN = exports.COLON = exports.DOT = exports.MINUS = exports.COMMA = exports.PLUS = exports.ASTERISK = exports.SINGLE_QUOTE = exports.AMPERSAND = exports.PERCENT = exports.SHARP = exports.DOUBLE_QUOTE = exports.EXCLAMATION = exports.SPACE = exports.CARRIAGE_RETURN = exports.LINE_FEED = exports.TAB = exports.BOM = void 0;
exports.isEOL = isEOL;
exports.isWhiteSpace = isWhiteSpace;
exports.isWhiteSpaceOrEOL = isWhiteSpaceOrEOL;
exports.isFlowIndicator = isFlowIndicator;
exports.BOM = 0xfeff; /* BOM */
exports.TAB = 0x09; /* Tab */
exports.LINE_FEED = 0x0a; /* LF */
exports.CARRIAGE_RETURN = 0x0d; /* CR */
exports.SPACE = 0x20; /* Space */
exports.EXCLAMATION = 0x21; /* ! */
exports.DOUBLE_QUOTE = 0x22; /* " */
exports.SHARP = 0x23; /* # */
exports.PERCENT = 0x25; /* % */
exports.AMPERSAND = 0x26; /* & */
exports.SINGLE_QUOTE = 0x27; /* ' */
exports.ASTERISK = 0x2a; /* * */
exports.PLUS = 0x2b; /* + */
exports.COMMA = 0x2c; /* , */
exports.MINUS = 0x2d; /* - */
exports.DOT = 0x2e; /* . */
exports.COLON = 0x3a; /* : */
exports.SMALLER_THAN = 0x3c; /* < */
exports.GREATER_THAN = 0x3e; /* > */
exports.QUESTION = 0x3f; /* ? */
exports.COMMERCIAL_AT = 0x40; /* @ */
exports.LEFT_SQUARE_BRACKET = 0x5b; /* [ */
exports.BACKSLASH = 0x5c; /* \ */
exports.RIGHT_SQUARE_BRACKET = 0x5d; /* ] */
exports.GRAVE_ACCENT = 0x60; /* ` */
exports.LEFT_CURLY_BRACKET = 0x7b; /* { */
exports.VERTICAL_LINE = 0x7c; /* | */
exports.RIGHT_CURLY_BRACKET = 0x7d; /* } */
function isEOL(c) {
    return c === exports.LINE_FEED || c === exports.CARRIAGE_RETURN;
}
function isWhiteSpace(c) {
    return c === exports.TAB || c === exports.SPACE;
}
function isWhiteSpaceOrEOL(c) {
    return isWhiteSpace(c) || isEOL(c);
}
function isFlowIndicator(c) {
    return (c === exports.COMMA ||
        c === exports.LEFT_SQUARE_BRACKET ||
        c === exports.RIGHT_SQUARE_BRACKET ||
        c === exports.LEFT_CURLY_BRACKET ||
        c === exports.RIGHT_CURLY_BRACKET);
}
