"use strict";
// Ported from js-yaml v3.13.1:
// https://github.com/nodeca/js-yaml/commit/665aadda42349dcae869f12040d9b10ef18d12da
// Copyright 2011-2015 by Vitaly Puzrin. All rights reserved. MIT license.
// Copyright 2018-2026 the Deno authors. MIT license.
// This module is browser compatible.
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCHEMA_MAP = exports.DEFAULT_SCHEMA = void 0;
exports.getSchema = getSchema;
const binary_js_1 = require("./_type/binary.js");
const bool_js_1 = require("./_type/bool.js");
const float_js_1 = require("./_type/float.js");
const int_js_1 = require("./_type/int.js");
const map_js_1 = require("./_type/map.js");
const merge_js_1 = require("./_type/merge.js");
const nil_js_1 = require("./_type/nil.js");
const omap_js_1 = require("./_type/omap.js");
const pairs_js_1 = require("./_type/pairs.js");
const regexp_js_1 = require("./_type/regexp.js");
const seq_js_1 = require("./_type/seq.js");
const set_js_1 = require("./_type/set.js");
const str_js_1 = require("./_type/str.js");
const timestamp_js_1 = require("./_type/timestamp.js");
const undefined_js_1 = require("./_type/undefined.js");
function createTypeMap(implicitTypes, explicitTypes) {
    const result = {
        fallback: new Map(),
        mapping: new Map(),
        scalar: new Map(),
        sequence: new Map(),
    };
    const fallbackMap = result.fallback;
    for (const type of [...implicitTypes, ...explicitTypes]) {
        const map = result[type.kind];
        map.set(type.tag, type);
        fallbackMap.set(type.tag, type);
    }
    return result;
}
function createSchema({ explicitTypes = [], implicitTypes = [], include }) {
    if (include) {
        implicitTypes.push(...include.implicitTypes);
        explicitTypes.push(...include.explicitTypes);
    }
    const typeMap = createTypeMap(implicitTypes, explicitTypes);
    return { implicitTypes, explicitTypes, typeMap };
}
/**
 * Standard YAML's failsafe schema.
 *
 * @see {@link http://www.yaml.org/spec/1.2/spec.html#id2802346}
 */
const FAILSAFE_SCHEMA = createSchema({
    explicitTypes: [str_js_1.str, seq_js_1.seq, map_js_1.map],
});
/**
 * Standard YAML's JSON schema.
 *
 * @see {@link http://www.yaml.org/spec/1.2/spec.html#id2803231}
 */
const JSON_SCHEMA = createSchema({
    implicitTypes: [nil_js_1.nil, bool_js_1.bool, int_js_1.int, float_js_1.float],
    include: FAILSAFE_SCHEMA,
});
/**
 * Standard YAML's core schema.
 *
 * @see {@link http://www.yaml.org/spec/1.2/spec.html#id2804923}
 */
const CORE_SCHEMA = createSchema({
    include: JSON_SCHEMA,
});
/**
 * Default YAML schema. It is not described in the YAML specification.
 */
exports.DEFAULT_SCHEMA = createSchema({
    explicitTypes: [binary_js_1.binary, omap_js_1.omap, pairs_js_1.pairs, set_js_1.set],
    implicitTypes: [timestamp_js_1.timestamp, merge_js_1.merge],
    include: CORE_SCHEMA,
});
/***
 * Extends JS-YAML default schema with additional JavaScript types
 * It is not described in the YAML specification.
 * Functions are no longer supported for security reasons.
 *
 * @example
 * ```ts
 * import { parse } from "@std/yaml";
 *
 * const data = parse(
 *   `
 *   regexp:
 *     simple: !!js/regexp foobar
 *     modifiers: !!js/regexp /foobar/mi
 *   undefined: !!js/undefined ~
 * `,
 *   { schema: "extended" },
 * );
 * ```
 */
const EXTENDED_SCHEMA = createSchema({
    explicitTypes: [regexp_js_1.regexp, undefined_js_1.undefinedType],
    include: exports.DEFAULT_SCHEMA,
});
exports.SCHEMA_MAP = new Map([
    ["core", CORE_SCHEMA],
    ["default", exports.DEFAULT_SCHEMA],
    ["failsafe", FAILSAFE_SCHEMA],
    ["json", JSON_SCHEMA],
    ["extended", EXTENDED_SCHEMA],
]);
function getSchema(schema = "default", types) {
    const schemaObj = exports.SCHEMA_MAP.get(schema);
    if (!types) {
        return schemaObj;
    }
    return createSchema({
        implicitTypes: [...types, ...schemaObj.implicitTypes],
        explicitTypes: [...schemaObj.explicitTypes],
    });
}
