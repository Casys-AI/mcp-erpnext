"use strict";
// Ported from js-yaml v3.13.1:
// https://github.com/nodeca/js-yaml/commit/665aadda42349dcae869f12040d9b10ef18d12da
// Copyright 2018-2026 the Deno authors. MIT license.
Object.defineProperty(exports, "__esModule", { value: true });
exports.str = void 0;
exports.str = {
    tag: "tag:yaml.org,2002:str",
    kind: "scalar",
    resolve: () => true,
    construct: (data) => data !== null ? data : "",
};
