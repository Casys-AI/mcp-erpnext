"use strict";
/**
 * mcp-compose — MCP Apps UI Orchestrator
 *
 * Lightweight library for composing and synchronizing multiple MCP Apps UIs
 * into composite dashboards.
 *
 * Pipeline: Collector -> Composer -> Renderer
 *
 * @module mcp-compose
 *
 * @example Basic usage
 * ```typescript
 * import { createCollector, buildCompositeUi, renderComposite } from "@mcpview/compose";
 *
 * // 1. Collect UI resources from MCP tool results
 * const collector = createCollector();
 * collector.collect("postgres:query", toolResult1, { query: "SELECT *" });
 * collector.collect("viz:render", toolResult2);
 *
 * // 2. Compose into a descriptor
 * const descriptor = buildCompositeUi(collector.getResources(), {
 *   layout: "split",
 *   sync: [{ from: "postgres:query", event: "filter", to: "viz:render", action: "update" }],
 * });
 *
 * // 3. Render to HTML
 * const html = renderComposite(descriptor);
 * ```
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.composeEvents = exports.COMPOSE_EVENT_METHOD = exports.validateComposition = exports.uiMeta = exports.createMcpSdkCollector = exports.renderComposite = exports.resolveComponentSurface = exports.buildCompositeUi = exports.validateSyncRules = exports.resolveSyncRules = exports.extractUiMeta = exports.createCollector = exports.UI_LAYOUT_PRESETS = exports.isValidLayout = exports.ErrorCode = void 0;
// Core — types, collector, sync, composer, renderer
require("./_dnt.polyfills.js");
var mod_js_1 = require("./src/core/types/mod.js");
Object.defineProperty(exports, "ErrorCode", { enumerable: true, get: function () { return mod_js_1.ErrorCode; } });
Object.defineProperty(exports, "isValidLayout", { enumerable: true, get: function () { return mod_js_1.isValidLayout; } });
Object.defineProperty(exports, "UI_LAYOUT_PRESETS", { enumerable: true, get: function () { return mod_js_1.UI_LAYOUT_PRESETS; } });
var mod_js_2 = require("./src/core/collector/mod.js");
Object.defineProperty(exports, "createCollector", { enumerable: true, get: function () { return mod_js_2.createCollector; } });
Object.defineProperty(exports, "extractUiMeta", { enumerable: true, get: function () { return mod_js_2.extractUiMeta; } });
var mod_js_3 = require("./src/core/sync/mod.js");
Object.defineProperty(exports, "resolveSyncRules", { enumerable: true, get: function () { return mod_js_3.resolveSyncRules; } });
Object.defineProperty(exports, "validateSyncRules", { enumerable: true, get: function () { return mod_js_3.validateSyncRules; } });
var mod_js_4 = require("./src/core/composer/mod.js");
Object.defineProperty(exports, "buildCompositeUi", { enumerable: true, get: function () { return mod_js_4.buildCompositeUi; } });
var mod_js_5 = require("./src/core/components/mod.js");
Object.defineProperty(exports, "resolveComponentSurface", { enumerable: true, get: function () { return mod_js_5.resolveComponentSurface; } });
var mod_js_6 = require("./src/host/renderer/mod.js");
Object.defineProperty(exports, "renderComposite", { enumerable: true, get: function () { return mod_js_6.renderComposite; } });
// SDK — MCP client adapters (optional convenience wrappers)
var mod_js_7 = require("./src/sdk/mod.js");
Object.defineProperty(exports, "createMcpSdkCollector", { enumerable: true, get: function () { return mod_js_7.createMcpSdkCollector; } });
var mod_js_8 = require("./src/sdk/mod.js");
Object.defineProperty(exports, "uiMeta", { enumerable: true, get: function () { return mod_js_8.uiMeta; } });
var mod_js_9 = require("./src/sdk/mod.js");
Object.defineProperty(exports, "validateComposition", { enumerable: true, get: function () { return mod_js_9.validateComposition; } });
var mod_js_10 = require("./src/sdk/mod.js");
Object.defineProperty(exports, "COMPOSE_EVENT_METHOD", { enumerable: true, get: function () { return mod_js_10.COMPOSE_EVENT_METHOD; } });
Object.defineProperty(exports, "composeEvents", { enumerable: true, get: function () { return mod_js_10.composeEvents; } });
