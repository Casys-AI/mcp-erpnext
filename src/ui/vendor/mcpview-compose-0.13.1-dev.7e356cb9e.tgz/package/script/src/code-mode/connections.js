"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectSnippetProviders = connectSnippetProviders;
const client_1 = require("@modelcontextprotocol/client");
const providers_js_1 = require("./providers.js");
/**
 * Connect the explicitly configured upstream MCPs. HTTP bindings share one host-owned
 * upstream identity for the lifetime of this pool. For different authorities in a
 * multi-user server, supply a client resolver keyed by the authenticated request context.
 * A partial startup closes every connection opened by the pool.
 */
async function connectSnippetProviders(bindings, options = {}) {
    options.signal?.throwIfAborted();
    if (!bindings.length)
        throw new Error("Configure at least one snippet provider.");
    const aliases = new Set();
    const prepared = bindings.map((binding) => {
        const { alias, snippets } = binding;
        if (!(0, providers_js_1.isSnippetIdentifier)(alias) || aliases.has(alias)) {
            throw new Error("Provider aliases must be valid and unique.");
        }
        aliases.add(alias);
        if (!Array.isArray(snippets) || !snippets.length || !snippets.every(providers_js_1.isSnippetName) ||
            new Set(snippets).size !== snippets.length)
            throw new Error("A provider needs a list of unique approved snippet names.");
        if ((binding.url === undefined) === (binding.client === undefined)) {
            throw new Error("Supply exactly one provider URL or client.");
        }
        let url;
        if (binding.url !== undefined) {
            url = new URL(binding.url);
            if (!["http:", "https:"].includes(url.protocol)) {
                throw new Error("Expected an HTTP endpoint.");
            }
        }
        else if (typeof binding.client !== "function" && typeof binding.client?.callTool !== "function") {
            throw new Error("Expected an MCP client or client resolver.");
        }
        return { alias, names: Object.freeze([...snippets]), url, binding };
    });
    const owned = [];
    let closing;
    function close() {
        return closing ??= (async () => {
            const attempts = await Promise.allSettled(owned.map((release) => release()));
            const errors = attempts.flatMap((a) => a.status === "rejected" ? [a.reason] : []);
            if (errors.length) {
                throw new AggregateError(errors, "Failed to close upstream MCP connections.");
            }
        })();
    }
    const opened = await Promise.allSettled(prepared.map(async ({ alias, names, url, binding }) => {
        let source = binding.client;
        if (url !== undefined) {
            const client = new client_1.Client({ name: "mcpview-compose-snippet-client", version: "1.0" }, {
                capabilities: {
                    extensions: {
                        "io.modelcontextprotocol/ui": { mimeTypes: ["text/html;profile=mcp-app"] },
                    },
                },
                versionNegotiation: { mode: "auto" },
            });
            const transport = new client_1.StreamableHTTPClientTransport(url, {
                requestInit: { ...binding.requestInit, redirect: "error" },
            });
            owned.push(async () => {
                // Closing the client also aborts the HTTP request if DELETE never returns.
                const timer = setTimeout(() => {
                    void client.close().catch(() => { });
                }, 3000);
                try {
                    await transport.terminateSession();
                }
                finally {
                    clearTimeout(timer);
                    await client.close();
                }
            });
            await client.connect(transport, { timeout: 15_000, signal: options.signal });
            source = client;
        }
        if (!source)
            throw new Error("Missing snippet provider client.");
        const clientSource = source;
        const provider = {
            names,
            events: binding.events,
            async call(tool, args, signal, context) {
                signal.throwIfAborted();
                if (closing)
                    throw new Error("Upstream MCP connections are closed.");
                if (tool !== "list_snippets" &&
                    !(tool === "run_snippet" && typeof args.name === "string" && names.includes(args.name))) {
                    throw new Error("Choose an approved provider snippet.");
                }
                try {
                    const client = typeof clientSource === "function"
                        ? await clientSource(context)
                        : clientSource;
                    signal.throwIfAborted();
                    if (closing)
                        throw new Error("Upstream MCP connections are closed.");
                    return await client.callTool({ name: tool, arguments: args }, {
                        signal,
                        timeout: 25_000,
                    });
                }
                catch {
                    signal.throwIfAborted();
                    throw new Error(`The ${alias} snippet provider could not complete the request.`);
                }
            },
        };
        return [alias, provider];
    }));
    const failure = opened.find((entry) => entry.status === "rejected");
    if (failure || options.signal?.aborted) {
        await close().catch(() => { });
        options.signal?.throwIfAborted();
        throw failure?.reason;
    }
    const providers = new Map(opened.flatMap((entry) => entry.status === "fulfilled" ? [entry.value] : []));
    return { providers, close };
}
