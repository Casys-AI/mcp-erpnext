"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectSnippetBoardLayout = connectSnippetBoardLayout;
/** Browser-side transport for user-edited Code Mode dashboard layouts. @module */
const panel_controls_js_1 = require("../host/renderer/panel-controls.js");
/**
 * Install the controls and restore a saved layout on a mounted board. Each
 * committed gesture stages its geometry and publishes an acknowledgement for
 * the next model turn. Pass the board's context writer when other panels share
 * its context. The returned callback retries the current layout after an error.
 */
function connectSnippetBoardLayout(board, { host, updateContext, stageTool, runId, savedLayout, signal, onStatus }) {
    (0, panel_controls_js_1.installPanelMovement)(board, signal);
    (0, panel_controls_js_1.installPanelResizing)(board, signal);
    if (!signal.aborted && savedLayout !== undefined && !(0, panel_controls_js_1.restorePanelLayout)(board, savedLayout)) {
        onStatus?.("restore-failed");
    }
    const capabilities = host.getHostCapabilities();
    const formats = capabilities?.updateModelContext;
    const structured = typeof formats?.structuredContent === "object" &&
        formats.structuredContent !== null;
    const text = typeof formats?.text === "object" && formats.text !== null;
    let latest = 0;
    let contextSent = Promise.resolve();
    function sendReceipt(receipt) {
        // Wait for the preceding context write even if the host delivers requests out of order.
        const next = contextSent.then(async () => {
            signal.throwIfAborted();
            if (receipt.status !== "pending" && receipt.revision !== latest)
                return;
            const value = { snippetLayout: receipt };
            // Once sent, an App-wide context update may include live selections from
            // other panels. Let its acknowledgement settle even if this board closes.
            const response = await updateContext(structured
                ? { structuredContent: value }
                : { content: [{ type: "text", text: JSON.stringify(value) }] });
            if ("isError" in response && response.isError)
                throw new Error("Layout receipt rejected");
        });
        contextSent = next.catch(() => { });
        return next;
    }
    async function commit() {
        if (signal.aborted)
            return;
        if (typeof runId !== "string" || !capabilities?.serverTools || !(structured || text)) {
            onStatus?.("local");
            return;
        }
        const layout = (0, panel_controls_js_1.capturePanelLayout)(board);
        if (!layout) {
            onStatus?.("local");
            return;
        }
        const revision = ++latest;
        const current = () => latest === revision && !signal.aborted;
        onStatus?.("pending");
        try {
            const [staged] = await Promise.all([
                host.callServerTool({ name: stageTool, arguments: { runId, revision, layout } }, {
                    signal,
                }),
                sendReceipt({ runId, revision, status: "pending" }),
            ]);
            const ack = staged.structuredContent;
            if (staged.isError || !ack || typeof ack !== "object" ||
                !("runId" in ack) || ack.runId !== runId ||
                !("revision" in ack) || ack.revision !== revision) {
                throw new Error("Layout revision not acknowledged");
            }
            if (!current())
                return;
            await sendReceipt({ runId, revision, status: "ready" });
            if (current())
                onStatus?.("ready");
        }
        catch {
            if (!current())
                return;
            onStatus?.("failed");
            // Leave retry available even when a disconnected host rejects the failure notice.
            await sendReceipt({ runId, revision, status: "failed" }).catch(() => { });
        }
    }
    const events = board;
    events.addEventListener("compose-panel-layout-committed", commit, { signal });
    return commit;
}
