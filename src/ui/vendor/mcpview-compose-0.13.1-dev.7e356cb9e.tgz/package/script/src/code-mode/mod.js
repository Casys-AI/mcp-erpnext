"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.supportsSnippetSync = exports.snippetSyncKey = exports.SNIPPET_SYNC_META_KEY = exports.parseSnippetSyncRule = exports.registerSnippetProvider = exports.createSnippetExecuteTool = exports.connectSnippetProviders = exports.createSnippetChain = void 0;
/** Run selected snippets across host-configured MCP providers in one Code Mode call. */
require("../../_dnt.polyfills.js");
var chain_js_1 = require("./chain.js");
Object.defineProperty(exports, "createSnippetChain", { enumerable: true, get: function () { return chain_js_1.createSnippetChain; } });
var connections_js_1 = require("./connections.js");
Object.defineProperty(exports, "connectSnippetProviders", { enumerable: true, get: function () { return connections_js_1.connectSnippetProviders; } });
var tool_js_1 = require("./tool.js");
Object.defineProperty(exports, "createSnippetExecuteTool", { enumerable: true, get: function () { return tool_js_1.createSnippetExecuteTool; } });
var provider_tools_js_1 = require("./provider-tools.js");
Object.defineProperty(exports, "registerSnippetProvider", { enumerable: true, get: function () { return provider_tools_js_1.registerSnippetProvider; } });
var sync_js_1 = require("./sync.js");
Object.defineProperty(exports, "parseSnippetSyncRule", { enumerable: true, get: function () { return sync_js_1.parseSnippetSyncRule; } });
Object.defineProperty(exports, "SNIPPET_SYNC_META_KEY", { enumerable: true, get: function () { return sync_js_1.SNIPPET_SYNC_META_KEY; } });
Object.defineProperty(exports, "snippetSyncKey", { enumerable: true, get: function () { return sync_js_1.snippetSyncKey; } });
Object.defineProperty(exports, "supportsSnippetSync", { enumerable: true, get: function () { return sync_js_1.supportsSnippetSync; } });
