"use strict";
/** Aggregate panel selections and board receipts for a single MCP Apps host. @module */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPanelContexts = createPanelContexts;
/** One host snapshot contains the acknowledged selections of every mounted panel. */
function createPanelContexts(send, clearErrorMessage = () => "Context not updated") {
    const board = Symbol("layout receipt");
    let active = new Map();
    // A lost acknowledgement leaves the host snapshot unknown. Retain only the
    // formats to clear on the next replacement, never the attempted selection.
    let uncertain;
    function liveSelections() {
        return new Map([...active].filter(([, selection]) => !selection.signal.aborted));
    }
    let queued = Promise.resolve();
    function enqueue(work) {
        const next = queued.then(work);
        queued = next.catch(() => { });
        return next;
    }
    function hasSelection(value) {
        return Boolean(value.content?.length ||
            Object.keys(value.structuredContent ?? {}).length);
    }
    function businessSelection(entries, last, boardMetadata) {
        if (entries.length === 0)
            return last;
        if (entries.length === 1) {
            const only = entries[0].value;
            const overlap = boardMetadata &&
                Object.keys(only.structuredContent ?? {}).some((key) => Object.hasOwn(boardMetadata, key));
            if (!overlap)
                return only;
        }
        const content = entries.flatMap(({ value }) => value.content ?? []);
        const panels = entries.flatMap(({ title, value }) => value.structuredContent ? [{ title, context: value.structuredContent }] : []);
        return {
            ...(entries.some(({ value }) => value.content !== undefined) ? { content } : {}),
            ...(panels.length ? { structuredContent: { panels } } : {}),
        };
    }
    function merge(next, last) {
        const receipt = next.get(board)?.value;
        if (!receipt)
            return businessSelection([...next.values()], last);
        const business = businessSelection([...next].filter(([key]) => key !== board).map(([, entry]) => entry), {}, receipt.structuredContent);
        return {
            ...(business.structuredContent || receipt.structuredContent ||
                last.structuredContent
                ? {
                    structuredContent: {
                        ...business.structuredContent,
                        ...receipt.structuredContent,
                    },
                }
                : {}),
            ...(business.content || receipt.content || last.content
                ? { content: [...(business.content ?? []), ...(receipt.content ?? [])] }
                : {}),
        };
    }
    async function replace(next, last, options) {
        const update = { ...uncertain, ...merge(next, last) };
        let response;
        try {
            response = await send(update, options);
        }
        catch (cause) {
            uncertain = {
                ...(update.content !== undefined ? { content: [] } : {}),
                ...(update.structuredContent !== undefined ? { structuredContent: {} } : {}),
            };
            throw cause;
        }
        if (!("isError" in response && response.isError)) {
            active = next;
            uncertain = undefined;
        }
        return response;
    }
    function forSource(id, title, signal) {
        return (value, options) => enqueue(async () => {
            signal.throwIfAborted();
            if (id === board && value.structuredContent &&
                Object.hasOwn(value.structuredContent, "panels")) {
                throw new TypeError('Board context reserves "panels" for panel selections');
            }
            const next = liveSelections();
            if (hasSelection(value))
                next.set(id, { title, value, signal });
            else
                next.delete(id);
            return await replace(next, value, options);
        });
    }
    return {
        forPanel: (id, title, signal) => forSource(id, title, signal),
        forBoard: (signal) => forSource(board, "", signal),
        clear() {
            return enqueue(async () => {
                const next = liveSelections();
                if (!uncertain && next.size === active.size)
                    return;
                const entries = [...active.values()];
                const empty = {
                    ...(entries.some(({ value }) => value.structuredContent !== undefined)
                        ? { structuredContent: {} }
                        : {}),
                    ...(entries.some(({ value }) => value.content !== undefined) ? { content: [] } : {}),
                };
                const response = await replace(next, empty);
                if ("isError" in response && response.isError) {
                    throw new Error(clearErrorMessage());
                }
            });
        },
    };
}
