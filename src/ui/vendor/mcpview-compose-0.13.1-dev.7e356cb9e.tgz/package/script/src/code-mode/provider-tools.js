"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerSnippetProvider = registerSnippetProvider;
/** Register the discovery and replay protocol on a snippet-owning MCP server. @module */
const _2020_js_1 = require("ajv/dist/2020.js");
const extractor_js_1 = require("../core/collector/extractor.js");
const providers_js_1 = require("./providers.js");
function failure(code, text) {
    return {
        isError: true,
        content: [{ type: "text", text }],
        structuredContent: { error: { code } },
    };
}
function object(input) {
    return typeof input === "object" && input !== null && !Array.isArray(input);
}
/**
 * Register `list_snippets` and `run_snippet`. Expose selected saved programs by name.
 * A successful runner returns its native MCP response with a JSON projection at
 * `structuredContent.value`. Provider-only view metadata is forwarded intact.
 *
 * @example
 * ```ts
 * registerSnippetProvider(app, {
 *   snippets: [{
 *     name: "overdue", description: "List overdue invoices",
 *     inputSchema: { type: "object" },
 *     run: (input, context) => replayInvoiceSnippet("overdue", input, context),
 *   }],
 *   requiredScopes: ["invoices:read"],
 * });
 * ```
 */
function registerSnippetProvider(server, options) {
    if (server.getToolNames().some((name) => name === "list_snippets" || name === "run_snippet")) {
        throw new Error("Snippet discovery or replay tools are already registered.");
    }
    const resourceUri = options.runResourceUri;
    const schemas = new _2020_js_1.Ajv2020({ strict: false, useDefaults: true });
    const definitions = options.snippets.map(({ name, description, inputSchema, run }) => {
        if (!(0, providers_js_1.isSnippetName)(name) || !object(inputSchema) || inputSchema.type !== "object") {
            throw new TypeError("Each snippet needs a valid name and an object input schema.");
        }
        const schema = structuredClone(inputSchema);
        const validate = schemas.compile(schema);
        if ("$async" in validate)
            throw new TypeError("Snippet input schemas must be synchronous.");
        return { descriptor: { name, description, inputSchema: schema }, validate, run };
    });
    const byName = new Map(definitions.map((def) => [def.descriptor.name, def]));
    if (byName.size !== definitions.length)
        throw new Error("Snippet names must be unique.");
    const authorized = async (name, context) => !options.authorize || (await options.authorize(name, context)) === true;
    const scopes = options.requiredScopes ? [...options.requiredScopes] : undefined;
    server.registerTool({
        name: "list_snippets",
        description: "List the saved snippets available to this caller and their input schemas.",
        inputSchema: { type: "object", properties: {}, additionalProperties: false },
        requiredScopes: scopes,
        annotations: {
            readOnlyHint: true,
            destructiveHint: false,
            openWorldHint: false,
            idempotentHint: true,
        },
    }, async (_args, context) => {
        const snippets = [];
        for (const { descriptor } of definitions) {
            if (await authorized(descriptor.name, context))
                snippets.push(descriptor);
        }
        return {
            content: snippets.map(({ name }) => name).join(", "),
            structuredContent: { snippets },
        };
    });
    server.registerTool({
        name: "run_snippet",
        description: "Replay a saved snippet using its declared input.",
        inputSchema: {
            type: "object",
            properties: { name: { type: "string" }, input: { type: "object" } },
            required: ["name", "input"],
            additionalProperties: false,
        },
        annotations: {
            readOnlyHint: false,
            destructiveHint: true,
            openWorldHint: true,
            idempotentHint: false,
            ...options.runAnnotations,
        },
        requiredScopes: scopes,
        ...(resourceUri ? { _meta: { ui: { resourceUri } } } : {}),
    }, async (args, context) => {
        const def = typeof args.name === "string" ? byName.get(args.name) : undefined;
        if (!def || !await authorized(def.descriptor.name, context)) {
            return failure("UNAVAILABLE", "The requested snippet is unavailable.");
        }
        if (!object(args.input) || Object.keys(args).length !== 2 || !def.validate(args.input)) {
            return failure("INVALID_INPUT", "Supply the snippet's declared input.");
        }
        const result = await def.run(args.input, context);
        if (result.isError === true)
            return result;
        if (!object(result.structuredContent) || !Object.hasOwn(result.structuredContent, "value")) {
            return failure("UPSTREAM_ERROR", "The saved snippet returned no value.");
        }
        if (!resourceUri || (0, extractor_js_1.extractUiMeta)(result))
            return result;
        const meta = object(result._meta) ? result._meta : {};
        const ui = object(meta.ui) ? meta.ui : {};
        return { ...result, _meta: { ...meta, ui: { ...ui, resourceUri } } };
    });
}
