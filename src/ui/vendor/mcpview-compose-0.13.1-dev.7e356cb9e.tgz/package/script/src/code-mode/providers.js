"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isSnippetIdentifier = isSnippetIdentifier;
exports.isSnippetName = isSnippetName;
/** Configured aliases identifying providers in a program. */
function isSnippetIdentifier(value) {
    return typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(value);
}
/** MCPView catalog names are exact, nonblank strings of at most 256 UTF-8 bytes. */
function isSnippetName(value) {
    return typeof value === "string" && value.length > 0 && value.length <= 256 &&
        value === value.trim() && new TextEncoder().encode(value).byteLength <= 256;
}
