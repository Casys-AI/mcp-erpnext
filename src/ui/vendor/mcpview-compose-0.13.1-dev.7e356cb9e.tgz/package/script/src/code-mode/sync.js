"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SNIPPET_SYNC_META_KEY = void 0;
exports.isPortName = isPortName;
exports.snippetPorts = snippetPorts;
exports.readSnippetEventPorts = readSnippetEventPorts;
exports.parseSnippetSyncRule = parseSnippetSyncRule;
exports.supportsSnippetSync = supportsSnippetSync;
exports.snippetSyncKey = snippetSyncKey;
const validator_js_1 = require("../core/sync/validator.js");
/** App-only metadata for explicit, receipt-scoped Compose rules. */
exports.SNIPPET_SYNC_META_KEY = "io.mcpview/snippet-sync";
function isPortName(value) {
    return typeof value === "string" && value.length > 0 && value.length <= 120 &&
        value.trim() === value && value !== "*";
}
function snippetPorts(events, name) {
    if (!events || !Object.hasOwn(events, name))
        return;
    return readSnippetEventPorts(events[name]);
}
function readSnippetEventPorts(value) {
    if (value === null || typeof value !== "object" || Array.isArray(value))
        return;
    const ports = value;
    const names = (values) => Array.isArray(values) ? [...new Set(values.filter(isPortName))] : [];
    const emits = names(ports.emits);
    const accepts = names(ports.accepts);
    if (emits.length || accepts.length)
        return { emits, accepts };
}
function parseSnippetSyncRule(value) {
    if (value === null || typeof value !== "object" || Array.isArray(value))
        return;
    const fields = ["from", "event", "to", "action"];
    if (Object.keys(value).length !== fields.length || !fields.every((key) => Object.hasOwn(value, key))) {
        return;
    }
    const { from, event, to, action } = value;
    if (!isPortName(from) || !isPortName(event) || !isPortName(to) || !isPortName(action))
        return;
    return { from, event, to, action };
}
function supportsSnippetSync(rule, panels) {
    return (0, validator_js_1.validateSyncRules)([rule], [rule.from, rule.to].filter((id) => panels.has(id))).valid &&
        panels.get(rule.from)?.emits?.includes(rule.event) === true &&
        panels.get(rule.to)?.accepts?.includes(rule.action) === true;
}
function snippetSyncKey({ from, event, to, action }) {
    return JSON.stringify([from, event, to, action]);
}
