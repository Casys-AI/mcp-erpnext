"use strict";
/**
 * UI resource collector — inspects MCP tool results and accumulates UI resources.
 *
 * @module collector/collector
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCollector = createCollector;
const resources_js_1 = require("../types/resources.js");
const extractor_js_1 = require("./extractor.js");
/**
 * Create a new UI resource collector.
 *
 * The collector inspects MCP tool call results for `_meta.ui.resourceUri`
 * and accumulates them with auto-incrementing slot indices.
 *
 * @returns A new `UiCollector` instance
 *
 * @example
 * ```typescript
 * const collector = createCollector();
 *
 * const r1 = collector.collect("postgres:query", {
 *   content: [{ type: "text", text: "OK" }],
 *   _meta: { ui: { resourceUri: "ui://pg/table/1" } },
 * });
 * // r1 === { source: "postgres:query", resourceUri: "ui://pg/table/1", slot: 0 }
 *
 * const r2 = collector.collect("viz:render", {
 *   content: [{ type: "text", text: "Chart" }],
 *   _meta: { ui: { resourceUri: "ui://viz/chart/2" } },
 * });
 * // r2.slot === 1
 *
 * collector.getResources().length; // 2
 * ```
 */
function createCollector() {
    let resources = [];
    return {
        collect(toolName, result, context, options) {
            const meta = (0, extractor_js_1.extractUiMeta)(result);
            if (!meta?.resourceUri) {
                return null;
            }
            const widths = options?.supportedWidths;
            if (widths !== undefined && !(0, resources_js_1.isSupportedWidths)(widths)) {
                throw new TypeError("supportedWidths must be an array of positive safe integers");
            }
            const resource = {
                ...(options?.componentId === undefined ? {} : { componentId: options.componentId }),
                source: toolName,
                resourceUri: meta.resourceUri,
                context,
                ...(options?.surface === undefined ? {} : { surface: options.surface }),
                ...(widths === undefined ? {} : { supportedWidths: [...widths] }),
                slot: resources.length,
            };
            resources.push(resource);
            return resource;
        },
        getResources() {
            return [...resources];
        },
        clear() {
            resources = [];
        },
    };
}
