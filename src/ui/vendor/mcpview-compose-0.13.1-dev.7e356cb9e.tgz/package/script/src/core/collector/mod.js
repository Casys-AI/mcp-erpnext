"use strict";
/**
 * UI resource collector module.
 *
 * @module collector
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractUiMeta = exports.createCollector = void 0;
var collector_js_1 = require("./collector.js");
Object.defineProperty(exports, "createCollector", { enumerable: true, get: function () { return collector_js_1.createCollector; } });
var extractor_js_1 = require("./extractor.js");
Object.defineProperty(exports, "extractUiMeta", { enumerable: true, get: function () { return extractor_js_1.extractUiMeta; } });
