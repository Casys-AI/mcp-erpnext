"use strict";
/** Pure resolution of a requested small-component surface against an App catalog. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveComponentSurface = resolveComponentSurface;
function resolveComponentSurface(catalog, requested) {
    const surface = requested ?? catalog.defaultSurface;
    if (!surface) {
        return {
            status: "unresolved",
            reason: "surface-required",
        };
    }
    const known = new Set(Object.keys(catalog.components));
    const missingComponents = [
        ...new Set(surface.components
            .map((item) => item.component)
            .filter((component) => !known.has(component))),
    ].sort();
    if (missingComponents.length > 0) {
        return {
            status: "unresolved",
            reason: "unknown-components",
            missingComponents,
        };
    }
    return {
        status: "ready",
        source: requested ? "requested" : "default",
        surface,
    };
}
