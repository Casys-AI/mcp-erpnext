"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveComponentSurface = void 0;
var components_js_1 = require("./components.js");
Object.defineProperty(exports, "resolveComponentSurface", { enumerable: true, get: function () { return components_js_1.resolveComponentSurface; } });
