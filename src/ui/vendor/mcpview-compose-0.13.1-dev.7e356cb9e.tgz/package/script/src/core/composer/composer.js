"use strict";
/**
 * Composite UI builder — assembles descriptor from resources + orchestration.
 *
 * @module composer/composer
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildCompositeUi = buildCompositeUi;
const resolver_js_1 = require("../sync/resolver.js");
/**
 * Build a composite UI descriptor from collected resources.
 *
 * Resolves tool names in sync rules to slot indices, extracts shared context,
 * and generates a unique workflow ID.
 *
 * @param resources - UI resources collected during tool execution
 * @param orchestration - Optional layout, sync, and shared context configuration
 * @returns Composite UI descriptor ready for rendering
 *
 * @example
 * ```typescript
 * const descriptor = buildCompositeUi(
 *   [
 *     { source: "postgres:query", resourceUri: "ui://pg/table/1", slot: 0 },
 *     { source: "viz:render", resourceUri: "ui://viz/chart/2", slot: 1 },
 *   ],
 *   {
 *     layout: "split",
 *     sync: [{ from: "postgres:query", event: "filter", to: "viz:render", action: "update" }],
 *   },
 * );
 * // descriptor.sync[0] === { from: 0, event: "filter", to: 1, action: "update" }
 * ```
 */
function buildCompositeUi(resources, orchestration) {
    const workflowId = crypto.randomUUID();
    const resolution = (0, resolver_js_1.resolveSyncRules)(orchestration?.sync ?? [], resources);
    // Invalid rules are silently excluded from the result.
    // Callers should use validateSyncRules() beforehand for upfront error detection.
    const sharedContext = extractSharedContext(resources, orchestration?.sharedContext);
    return {
        type: "composite",
        resourceUri: `ui://mcp-compose/workflow/${workflowId}`,
        layout: orchestration?.layout ?? "stack",
        children: resources,
        sync: resolution.rules,
        portSync: [...(orchestration?.portSync ?? [])],
        sharedContext,
    };
}
/**
 * Extract shared context values from collected UI resources.
 *
 * For each key in `keys`, scans resources in order and takes the first match.
 *
 * @param resources - Collected UI resources with optional context
 * @param keys - Keys to extract from each resource's context
 * @returns Merged shared context, or `undefined` if no keys specified or no matches
 */
function extractSharedContext(resources, keys) {
    if (!keys || keys.length === 0) {
        return undefined;
    }
    const ctx = {};
    for (const resource of resources) {
        if (!resource.context)
            continue;
        for (const key of keys) {
            if (key in resource.context && !(key in ctx)) {
                ctx[key] = resource.context[key];
            }
        }
    }
    return Object.keys(ctx).length > 0 ? ctx : undefined;
}
