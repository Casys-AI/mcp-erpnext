"use strict";
/**
 * Composite UI builder module.
 *
 * @module composer
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildCompositeUi = void 0;
var composer_js_1 = require("./composer.js");
Object.defineProperty(exports, "buildCompositeUi", { enumerable: true, get: function () { return composer_js_1.buildCompositeUi; } });
