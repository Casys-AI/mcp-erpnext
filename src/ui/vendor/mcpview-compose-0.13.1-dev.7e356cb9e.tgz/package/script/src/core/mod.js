"use strict";
/**
 * Core composition primitives — types, collector, sync, composer, renderer.
 *
 * @module core
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveComponentSurface = exports.buildCompositeUi = exports.validateSyncRules = exports.resolveSyncRules = exports.extractUiMeta = exports.createCollector = exports.UI_LAYOUT_PRESETS = exports.isValidLayout = exports.isLayoutPreset = exports.isLayoutAreas = exports.ErrorCode = void 0;
// Types
require("../../_dnt.polyfills.js");
var mod_js_1 = require("./types/mod.js");
Object.defineProperty(exports, "ErrorCode", { enumerable: true, get: function () { return mod_js_1.ErrorCode; } });
Object.defineProperty(exports, "isLayoutAreas", { enumerable: true, get: function () { return mod_js_1.isLayoutAreas; } });
Object.defineProperty(exports, "isLayoutPreset", { enumerable: true, get: function () { return mod_js_1.isLayoutPreset; } });
Object.defineProperty(exports, "isValidLayout", { enumerable: true, get: function () { return mod_js_1.isValidLayout; } });
Object.defineProperty(exports, "UI_LAYOUT_PRESETS", { enumerable: true, get: function () { return mod_js_1.UI_LAYOUT_PRESETS; } });
// Collector
var mod_js_2 = require("./collector/mod.js");
Object.defineProperty(exports, "createCollector", { enumerable: true, get: function () { return mod_js_2.createCollector; } });
Object.defineProperty(exports, "extractUiMeta", { enumerable: true, get: function () { return mod_js_2.extractUiMeta; } });
// Sync
var mod_js_3 = require("./sync/mod.js");
Object.defineProperty(exports, "resolveSyncRules", { enumerable: true, get: function () { return mod_js_3.resolveSyncRules; } });
Object.defineProperty(exports, "validateSyncRules", { enumerable: true, get: function () { return mod_js_3.validateSyncRules; } });
// Composer
var mod_js_4 = require("./composer/mod.js");
Object.defineProperty(exports, "buildCompositeUi", { enumerable: true, get: function () { return mod_js_4.buildCompositeUi; } });
// Small-component surfaces
var mod_js_5 = require("./components/mod.js");
Object.defineProperty(exports, "resolveComponentSurface", { enumerable: true, get: function () { return mod_js_5.resolveComponentSurface; } });
