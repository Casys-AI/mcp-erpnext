"use strict";
/**
 * Sync rule engine — resolution and validation.
 *
 * @module sync
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateSyncRules = exports.resolveSyncRules = void 0;
var resolver_js_1 = require("./resolver.js");
Object.defineProperty(exports, "resolveSyncRules", { enumerable: true, get: function () { return resolver_js_1.resolveSyncRules; } });
var validator_js_1 = require("./validator.js");
Object.defineProperty(exports, "validateSyncRules", { enumerable: true, get: function () { return validator_js_1.validateSyncRules; } });
