"use strict";
/** Declarative small-component surface contracts for composed MCP Apps. */
Object.defineProperty(exports, "__esModule", { value: true });
