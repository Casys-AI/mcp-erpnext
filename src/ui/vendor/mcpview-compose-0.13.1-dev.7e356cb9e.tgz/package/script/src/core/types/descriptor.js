"use strict";
/**
 * Composite UI descriptor types.
 *
 * @module types/descriptor
 */
Object.defineProperty(exports, "__esModule", { value: true });
