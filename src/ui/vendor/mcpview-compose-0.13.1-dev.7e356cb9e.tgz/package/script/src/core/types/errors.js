"use strict";
/**
 * Structured error types with machine-readable codes.
 *
 * @module types/errors
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorCode = void 0;
/**
 * Error codes for mcp-compose operations.
 *
 * @example
 * ```typescript
 * import { ErrorCode } from "@mcpview/compose";
 *
 * if (issue.code === ErrorCode.ORPHAN_SYNC_REFERENCE) {
 *   console.log("Sync rule references unknown tool:", issue.message);
 * }
 * ```
 */
var ErrorCode;
(function (ErrorCode) {
    /** A sync rule references a tool name not present in collected resources. */
    ErrorCode["ORPHAN_SYNC_REFERENCE"] = "ORPHAN_SYNC_REFERENCE";
    /** A sync rule creates a circular route (from === to). */
    ErrorCode["CIRCULAR_SYNC_RULE"] = "CIRCULAR_SYNC_RULE";
    /** Invalid layout value. */
    ErrorCode["INVALID_LAYOUT"] = "INVALID_LAYOUT";
    /** Tool result does not contain valid UI metadata. */
    ErrorCode["NO_UI_METADATA"] = "NO_UI_METADATA";
    /** Missing required resourceUri in UI metadata. */
    ErrorCode["MISSING_RESOURCE_URI"] = "MISSING_RESOURCE_URI";
    /** No resources provided to composer. */
    ErrorCode["EMPTY_RESOURCES"] = "EMPTY_RESOURCES";
})(ErrorCode || (exports.ErrorCode = ErrorCode = {}));
