"use strict";
/**
 * Layout types for composite UI arrangement.
 *
 * Supports simple presets (a single string) and agent-composed
 * area grids (a structured object with named regions).
 *
 * @module types/layout
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.UI_LAYOUT_PRESETS = void 0;
exports.isValidLayout = isValidLayout;
exports.isLayoutPreset = isLayoutPreset;
exports.isLayoutAreas = isLayoutAreas;
/**
 * All valid layout preset values for runtime validation.
 */
exports.UI_LAYOUT_PRESETS = [
    "split",
    "tabs",
    "grid",
    "stack",
];
/**
 * Check if a value is a valid UiLayout (preset string or areas object).
 *
 * @example
 * ```typescript
 * isValidLayout("split"); // true
 * isValidLayout({ areas: [["a", "b"]] }); // true
 * isValidLayout("unknown"); // false
 * ```
 */
function isValidLayout(value) {
    if (typeof value === "string") {
        return exports.UI_LAYOUT_PRESETS.includes(value);
    }
    if (typeof value === "object" && value !== null && "areas" in value) {
        const areas = value.areas;
        return Array.isArray(areas) && areas.length > 0 && areas.every(Array.isArray);
    }
    return false;
}
/**
 * Check if a layout is a preset string.
 */
function isLayoutPreset(layout) {
    return typeof layout === "string";
}
/**
 * Check if a layout is an areas grid.
 */
function isLayoutAreas(layout) {
    return typeof layout === "object" && "areas" in layout;
}
