"use strict";
/**
 * MCP Apps specification types (SEP-1865 / spec 2026-01-26).
 *
 * Types from the MCP Apps protocol, sourced directly from
 * `@modelcontextprotocol/ext-apps` to stay in lock-step with the official spec.
 * Compose consumes these types only — no runtime dependency on the ext-apps
 * `App` or `AppBridge` classes (those target a 1-iframe-per-client model
 * incompatible with compose's multi-iframe routing).
 *
 * Legacy aliases (`McpUiCsp`, `McpUiPermissions`) are preserved for backwards
 * compatibility and map to the official names (`McpUiResourceCsp`,
 * `McpUiResourcePermissions`). Prefer the official names in new code.
 *
 * @module types/mcp-apps
 */
Object.defineProperty(exports, "__esModule", { value: true });
