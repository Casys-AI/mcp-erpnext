"use strict";
/**
 * Type definitions for mcp-compose.
 *
 * @module types
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorCode = exports.UI_LAYOUT_PRESETS = exports.isValidLayout = exports.isLayoutPreset = exports.isLayoutAreas = void 0;
var layout_js_1 = require("./layout.js");
Object.defineProperty(exports, "isLayoutAreas", { enumerable: true, get: function () { return layout_js_1.isLayoutAreas; } });
Object.defineProperty(exports, "isLayoutPreset", { enumerable: true, get: function () { return layout_js_1.isLayoutPreset; } });
Object.defineProperty(exports, "isValidLayout", { enumerable: true, get: function () { return layout_js_1.isValidLayout; } });
Object.defineProperty(exports, "UI_LAYOUT_PRESETS", { enumerable: true, get: function () { return layout_js_1.UI_LAYOUT_PRESETS; } });
var errors_js_1 = require("./errors.js");
Object.defineProperty(exports, "ErrorCode", { enumerable: true, get: function () { return errors_js_1.ErrorCode; } });
