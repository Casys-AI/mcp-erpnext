"use strict";
/**
 * Orchestration configuration combining layout, sync rules, and shared context.
 *
 * @module types/orchestration
 */
Object.defineProperty(exports, "__esModule", { value: true });
