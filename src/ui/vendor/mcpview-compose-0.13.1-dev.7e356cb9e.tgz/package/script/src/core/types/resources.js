"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isSupportedWidths = isSupportedWidths;
/** Whether a Compose width declaration contains only positive whole CSS pixel values. */
function isSupportedWidths(value) {
    if (!Array.isArray(value))
        return false;
    for (const width of value) {
        if (!Number.isSafeInteger(width) || width <= 0)
            return false;
    }
    return true;
}
