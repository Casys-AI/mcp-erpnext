"use strict";
/**
 * Sync rule types for cross-UI event routing.
 *
 * @module types/sync-rules
 */
Object.defineProperty(exports, "__esModule", { value: true });
