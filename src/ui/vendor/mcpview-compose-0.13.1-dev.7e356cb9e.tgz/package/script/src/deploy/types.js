"use strict";
/**
 * Deploy types for cloud dashboard publication.
 *
 * @module deploy/types
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeployErrorCode = void 0;
// =============================================================================
// Error types
// =============================================================================
/** Deploy error codes. */
var DeployErrorCode;
(function (DeployErrorCode) {
    DeployErrorCode["API_ERROR"] = "DEPLOY_API_ERROR";
    DeployErrorCode["AUTH_ERROR"] = "DEPLOY_AUTH_ERROR";
    DeployErrorCode["PROJECT_CREATE_FAILED"] = "DEPLOY_PROJECT_CREATE_FAILED";
    DeployErrorCode["DEPLOYMENT_FAILED"] = "DEPLOY_DEPLOYMENT_FAILED";
    DeployErrorCode["TUNNEL_CONNECT_FAILED"] = "DEPLOY_TUNNEL_CONNECT_FAILED";
    DeployErrorCode["TUNNEL_DISCONNECTED"] = "DEPLOY_TUNNEL_DISCONNECTED";
    DeployErrorCode["TEARDOWN_FAILED"] = "DEPLOY_TEARDOWN_FAILED";
})(DeployErrorCode || (exports.DeployErrorCode = DeployErrorCode = {}));
