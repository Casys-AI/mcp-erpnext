"use strict";
/** Casys small-component extension identifiers layered on MCP Apps. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CASYS_SURFACE_CONTEXT_KEY = exports.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY = void 0;
/** App capability containing the viewer-owned component catalog. */
exports.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY = "io.casys.mcp.view-components/v1";
/** Host-context field containing the requested/default component surface. */
exports.CASYS_SURFACE_CONTEXT_KEY = "io.casys.mcp.surface/v1";
