"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serveDashboard = exports.renderComposite = exports.CASYS_SURFACE_CONTEXT_KEY = exports.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY = void 0;
/**
 * Host integration layer for mcp-compose.
 *
 * Defines the contracts for host applications that embed composite UIs,
 * and provides the HTML/CSS/JS renderer for generating self-contained dashboards.
 *
 * @module host
 */
require("../../_dnt.polyfills.js");
var components_contract_js_1 = require("./components-contract.js");
Object.defineProperty(exports, "CASYS_COMPONENT_CATALOG_CAPABILITY_KEY", { enumerable: true, get: function () { return components_contract_js_1.CASYS_COMPONENT_CATALOG_CAPABILITY_KEY; } });
Object.defineProperty(exports, "CASYS_SURFACE_CONTEXT_KEY", { enumerable: true, get: function () { return components_contract_js_1.CASYS_SURFACE_CONTEXT_KEY; } });
// Renderer
var mod_js_1 = require("./renderer/mod.js");
Object.defineProperty(exports, "renderComposite", { enumerable: true, get: function () { return mod_js_1.renderComposite; } });
// Server
var serve_js_1 = require("./serve.js");
Object.defineProperty(exports, "serveDashboard", { enumerable: true, get: function () { return serve_js_1.serveDashboard; } });
