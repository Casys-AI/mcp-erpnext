"use strict";
/**
 * HTML renderer module.
 *
 * @module renderer
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveRendererSlots = exports.renderComposite = void 0;
var html_generator_js_1 = require("./html-generator.js");
Object.defineProperty(exports, "renderComposite", { enumerable: true, get: function () { return html_generator_js_1.renderComposite; } });
var html_generator_js_2 = require("./html-generator.js");
Object.defineProperty(exports, "resolveRendererSlots", { enumerable: true, get: function () { return html_generator_js_2.resolveRendererSlots; } });
