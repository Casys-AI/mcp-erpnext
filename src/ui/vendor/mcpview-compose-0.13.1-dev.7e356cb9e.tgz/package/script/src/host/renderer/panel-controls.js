"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.installPanelResizing = exports.createPanelReflow = exports.restorePanelLayout = exports.capturePanelLayout = exports.installPanelMovement = void 0;
// @ts-self-types="./panel-controls.d.ts"
// Server consumers embed these functions in HTML. Only browsers execute their DOM code.
var panel_movement_js_1 = require("./panel-movement.js");
Object.defineProperty(exports, "installPanelMovement", { enumerable: true, get: function () { return panel_movement_js_1.installPanelMovement; } });
var panel_snapshot_js_1 = require("./panel-snapshot.js");
Object.defineProperty(exports, "capturePanelLayout", { enumerable: true, get: function () { return panel_snapshot_js_1.capturePanelLayout; } });
Object.defineProperty(exports, "restorePanelLayout", { enumerable: true, get: function () { return panel_snapshot_js_1.restorePanelLayout; } });
var panel_reflow_js_1 = require("./panel-reflow.js");
Object.defineProperty(exports, "createPanelReflow", { enumerable: true, get: function () { return panel_reflow_js_1.createPanelReflow; } });
var panel_resizing_js_1 = require("./panel-resizing.js");
Object.defineProperty(exports, "installPanelResizing", { enumerable: true, get: function () { return panel_resizing_js_1.installPanelResizing; } });
