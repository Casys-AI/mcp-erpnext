"use strict";
/**
 * Host integration types for mcp-compose.
 *
 * These types define the contracts a host application (e.g., a desktop shell,
 * web container, or IDE extension) must satisfy to embed composite UIs.
 *
 * @module host/types
 */
Object.defineProperty(exports, "__esModule", { value: true });
