"use strict";
/**
 * Runtime-facing types for serving an interactive composed dashboard.
 *
 * The renderer remains transport-agnostic; these values are the explicit
 * binding between a collected UI slot and the MCP connection that produced it.
 *
 * @module runtime/host-dashboard-types
 */
Object.defineProperty(exports, "__esModule", { value: true });
