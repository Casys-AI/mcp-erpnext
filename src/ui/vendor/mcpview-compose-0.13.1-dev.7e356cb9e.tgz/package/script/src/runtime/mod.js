"use strict";
/**
 * Runtime module — dashboard composition from manifests + templates.
 *
 * Handles I/O: reading manifests/templates, starting MCP servers,
 * calling tools, and feeding results into the core pipeline.
 *
 * @module runtime
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.serveComposedDashboard = exports.composeAndServeDashboard = exports.composeDashboardFromFiles = exports.composeDashboard = exports.startServer = exports.createCluster = exports.connectHttp = exports.validateTemplate = exports.parseTemplateJson = exports.parseTemplate = exports.loadTemplate = exports.injectArgs = exports.validateManifest = exports.parseManifest = exports.loadManifests = exports.loadManifest = exports.RuntimeErrorCode = void 0;
// Types
require("../../_dnt.polyfills.js");
var types_js_1 = require("./types.js");
Object.defineProperty(exports, "RuntimeErrorCode", { enumerable: true, get: function () { return types_js_1.RuntimeErrorCode; } });
// Manifest
var manifest_js_1 = require("./manifest.js");
Object.defineProperty(exports, "loadManifest", { enumerable: true, get: function () { return manifest_js_1.loadManifest; } });
Object.defineProperty(exports, "loadManifests", { enumerable: true, get: function () { return manifest_js_1.loadManifests; } });
Object.defineProperty(exports, "parseManifest", { enumerable: true, get: function () { return manifest_js_1.parseManifest; } });
Object.defineProperty(exports, "validateManifest", { enumerable: true, get: function () { return manifest_js_1.validateManifest; } });
// Template
var template_js_1 = require("./template.js");
Object.defineProperty(exports, "injectArgs", { enumerable: true, get: function () { return template_js_1.injectArgs; } });
Object.defineProperty(exports, "loadTemplate", { enumerable: true, get: function () { return template_js_1.loadTemplate; } });
Object.defineProperty(exports, "parseTemplate", { enumerable: true, get: function () { return template_js_1.parseTemplate; } });
Object.defineProperty(exports, "parseTemplateJson", { enumerable: true, get: function () { return template_js_1.parseTemplateJson; } });
Object.defineProperty(exports, "validateTemplate", { enumerable: true, get: function () { return template_js_1.validateTemplate; } });
// Cluster
var cluster_js_1 = require("./cluster.js");
Object.defineProperty(exports, "connectHttp", { enumerable: true, get: function () { return cluster_js_1.connectHttp; } });
Object.defineProperty(exports, "createCluster", { enumerable: true, get: function () { return cluster_js_1.createCluster; } });
Object.defineProperty(exports, "startServer", { enumerable: true, get: function () { return cluster_js_1.startServer; } });
// Compose (main entry points)
var compose_js_1 = require("./compose.js");
Object.defineProperty(exports, "composeDashboard", { enumerable: true, get: function () { return compose_js_1.composeDashboard; } });
Object.defineProperty(exports, "composeDashboardFromFiles", { enumerable: true, get: function () { return compose_js_1.composeDashboardFromFiles; } });
// Interactive local MCP Apps host
var host_dashboard_js_1 = require("./host-dashboard.js");
Object.defineProperty(exports, "composeAndServeDashboard", { enumerable: true, get: function () { return host_dashboard_js_1.composeAndServeDashboard; } });
Object.defineProperty(exports, "serveComposedDashboard", { enumerable: true, get: function () { return host_dashboard_js_1.serveComposedDashboard; } });
