"use strict";
/**
 * Runtime types for mcp-compose dashboard composition.
 *
 * These types define manifests (static MCP server metadata),
 * dashboard templates (YAML), and the compose request/result contract.
 *
 * @module runtime/types
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuntimeErrorCode = void 0;
// =============================================================================
// Error types
// =============================================================================
/** Runtime error codes. */
var RuntimeErrorCode;
(function (RuntimeErrorCode) {
    RuntimeErrorCode["MANIFEST_PARSE_ERROR"] = "MANIFEST_PARSE_ERROR";
    RuntimeErrorCode["TEMPLATE_PARSE_ERROR"] = "TEMPLATE_PARSE_ERROR";
    RuntimeErrorCode["MANIFEST_NOT_FOUND"] = "MANIFEST_NOT_FOUND";
    RuntimeErrorCode["PROCESS_START_FAILED"] = "PROCESS_START_FAILED";
    RuntimeErrorCode["TOOL_CALL_FAILED"] = "TOOL_CALL_FAILED";
    RuntimeErrorCode["TOOL_CALL_TIMEOUT"] = "TOOL_CALL_TIMEOUT";
    RuntimeErrorCode["TOOL_LIST_FAILED"] = "TOOL_LIST_FAILED";
    RuntimeErrorCode["TOOL_LIST_TIMEOUT"] = "TOOL_LIST_TIMEOUT";
    RuntimeErrorCode["RESOURCE_READ_FAILED"] = "RESOURCE_READ_FAILED";
    RuntimeErrorCode["RESOURCE_READ_TIMEOUT"] = "RESOURCE_READ_TIMEOUT";
    RuntimeErrorCode["RESOURCE_LIST_FAILED"] = "RESOURCE_LIST_FAILED";
    RuntimeErrorCode["RESOURCE_LIST_TIMEOUT"] = "RESOURCE_LIST_TIMEOUT";
    RuntimeErrorCode["PROCESS_DIED"] = "PROCESS_DIED";
})(RuntimeErrorCode || (exports.RuntimeErrorCode = RuntimeErrorCode = {}));
