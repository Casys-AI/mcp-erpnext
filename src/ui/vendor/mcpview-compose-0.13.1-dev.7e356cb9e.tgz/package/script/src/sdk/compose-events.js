"use strict";
/**
 * UI-side helpers for cross-UI event routing via mcp-compose.
 *
 * Uses a dedicated `ui/compose/event` JSON-RPC method, separate from
 * the MCP Apps protocol. No dependency on `@modelcontextprotocol/ext-apps`.
 *
 * Works alongside the MCP Apps `App` class without interfering —
 * each protocol has its own channel.
 *
 * @module sdk/compose-events
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.COMPOSE_EVENT_METHOD = void 0;
exports.composeEvents = composeEvents;
/** JSON-RPC method for compose events. */
const dntShim = __importStar(require("../../_dnt.shims.js"));
exports.COMPOSE_EVENT_METHOD = "ui/compose/event";
/**
 * Create a compose events channel for cross-UI communication.
 *
 * Uses a dedicated `ui/compose/event` JSON-RPC method via postMessage,
 * completely separate from the MCP Apps protocol. The MCP Apps `App`
 * instance handles standard protocol methods; `composeEvents` handles
 * composition events. No interference between the two.
 *
 * @param parent - The parent window to send messages to (default: `window.parent`)
 * @param source - The window to listen on (default: `window`)
 * @returns Compose events interface with `emit`, `on`, and `destroy` methods
 *
 * @example Browser usage
 * ```typescript
 * import { composeEvents } from "@mcpview/compose/sdk";
 *
 * const events = composeEvents();
 *
 * // Emit when user selects an invoice
 * events.emit("invoice.selected", { invoiceId: "INV-001" });
 *
 * // Listen for filter actions from other UIs
 * events.on("filter.apply", (payload) => {
 *   applyFilter(payload.data);
 * });
 *
 * // Cleanup when done
 * events.destroy();
 * ```
 *
 * @example With MCP Apps App (no conflict)
 * ```typescript
 * import { App } from "@modelcontextprotocol/ext-apps";
 * import { composeEvents } from "@mcpview/compose/sdk";
 *
 * // MCP Apps — standard protocol
 * const app = new App({ name: "Invoice Viewer", version: "1.0.0" });
 * await app.connect();
 * app.ontoolresult = (result) => hydrateData(result);
 *
 * // Compose — separate channel, no interference
 * const events = composeEvents();
 * events.emit("invoice.selected", { id: "INV-001" });
 * events.on("filter.apply", (p) => applyFilter(p.data));
 * ```
 */
function composeEvents(parent, source) {
    const handlers = new Map();
    let nextId = 1;
    // Resolve parent/source — use globals only when available (browser)
    const _parent = parent ??
        ("parent" in dntShim.dntGlobalThis
            ? dntShim.dntGlobalThis.parent
            : undefined);
    const _source = source ??
        ("addEventListener" in dntShim.dntGlobalThis ? dntShim.dntGlobalThis : undefined);
    // Message listener for incoming compose events
    const onMessage = (e) => {
        const msg = e.data;
        if (!msg || typeof msg !== "object")
            return;
        if (msg.jsonrpc !== "2.0")
            return;
        if (msg.method !== exports.COMPOSE_EVENT_METHOD)
            return;
        const params = msg.params;
        if (!params || typeof params.action !== "string")
            return;
        const actionHandlers = handlers.get(params.action);
        if (!actionHandlers)
            return;
        const payload = {
            data: params.data,
            sourceSlot: params.sourceSlot,
            sharedContext: params.sharedContext,
        };
        for (const handler of actionHandlers) {
            handler(payload);
        }
    };
    _source?.addEventListener("message", onMessage);
    return {
        emit(event, data) {
            if (!_parent) {
                throw new Error("[mcp-compose] No parent window available. composeEvents() must run inside an iframe.");
            }
            _parent.postMessage({
                jsonrpc: "2.0",
                method: exports.COMPOSE_EVENT_METHOD,
                id: nextId++,
                params: { event, data },
            }, "*");
        },
        on(action, handler) {
            if (!handlers.has(action)) {
                handlers.set(action, new Set());
            }
            handlers.get(action).add(handler);
            return () => {
                const set = handlers.get(action);
                if (set) {
                    set.delete(handler);
                    if (set.size === 0)
                        handlers.delete(action);
                }
            };
        },
        destroy() {
            _source?.removeEventListener("message", onMessage);
            handlers.clear();
        },
    };
}
