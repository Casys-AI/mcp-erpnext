"use strict";
/**
 * MCP SDK adapter — wraps the collector for use with `@modelcontextprotocol/client` tool call results.
 *
 * This adapter provides a convenience wrapper around the collector that accepts
 * the shape of tool call results from the official MCP SDK. It uses generic interfaces
 * to avoid importing the SDK directly (zero-dependency constraint).
 *
 * @module sdk/mcp-sdk
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createMcpSdkCollector = createMcpSdkCollector;
const collector_js_1 = require("../core/collector/collector.js");
/**
 * Create an MCP SDK-aware collector.
 *
 * Wraps the core `UiCollector` with an interface that accepts
 * `@modelcontextprotocol/client` `CallToolResult` objects directly.
 * Error results (`isError: true`) are automatically skipped.
 *
 * @returns A new `McpSdkCollector` instance
 *
 * @example
 * ```typescript
 * import { createMcpSdkCollector } from "@mcpview/compose/sdk";
 *
 * const collector = createMcpSdkCollector();
 *
 * // Collect from SDK tool call results
 * for (const [toolName, result] of toolCallResults) {
 *   collector.collectFromSdk(toolName, result, { workflowId: "wf-1" });
 * }
 *
 * // Use collected resources in the standard pipeline
 * const resources = collector.getResources();
 * ```
 */
function createMcpSdkCollector() {
    const inner = (0, collector_js_1.createCollector)();
    return {
        collectFromSdk(toolName, result, context, options) {
            if (result.isError) {
                return null;
            }
            return inner.collect(toolName, result, context, options);
        },
        getResources() {
            return inner.getResources();
        },
        clear() {
            inner.clear();
        },
        get inner() {
            return inner;
        },
    };
}
