"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.composeEvents = exports.COMPOSE_EVENT_METHOD = exports.validateComposition = exports.uiMeta = exports.createMcpSdkCollector = void 0;
/**
 * MCP SDK adapters — optional convenience wrappers for MCP client SDKs.
 *
 * @module sdk
 */
require("../../_dnt.polyfills.js");
var mcp_sdk_js_1 = require("./mcp-sdk.js");
Object.defineProperty(exports, "createMcpSdkCollector", { enumerable: true, get: function () { return mcp_sdk_js_1.createMcpSdkCollector; } });
var ui_meta_builder_js_1 = require("./ui-meta-builder.js");
Object.defineProperty(exports, "uiMeta", { enumerable: true, get: function () { return ui_meta_builder_js_1.uiMeta; } });
var composition_validator_js_1 = require("./composition-validator.js");
Object.defineProperty(exports, "validateComposition", { enumerable: true, get: function () { return composition_validator_js_1.validateComposition; } });
var compose_events_js_1 = require("./compose-events.js");
Object.defineProperty(exports, "COMPOSE_EVENT_METHOD", { enumerable: true, get: function () { return compose_events_js_1.COMPOSE_EVENT_METHOD; } });
Object.defineProperty(exports, "composeEvents", { enumerable: true, get: function () { return compose_events_js_1.composeEvents; } });
