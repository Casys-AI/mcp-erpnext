"use strict";
/**
 * uiMeta() builder — typed helper for declaring `_meta.ui` with PML extensions.
 *
 * Builds the full `_meta` object ready to spread into an MCP tool definition.
 * Supports standard SEP-1865 fields (resourceUri, visibility, csp, permissions,
 * domain, prefersBorder) plus PML extensions (emits, accepts) for cross-UI
 * event routing.
 *
 * @module sdk/ui-meta-builder
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.uiMeta = uiMeta;
/**
 * Build a typed `_meta` object for an MCP tool definition.
 *
 * Combines standard SEP-1865 UI metadata with PML composition extensions
 * (emits/accepts). Only defined fields are included in the output —
 * undefined optional fields are omitted entirely.
 *
 * @param options - UI metadata options
 * @returns Object with `_meta.ui` ready to spread into a tool definition
 *
 * @example
 * ```typescript
 * import { uiMeta } from "@mcpview/compose";
 *
 * const tool = {
 *   name: "erp:customers",
 *   ...uiMeta({
 *     resourceUri: "ui://erp/customers",
 *     emits: ["rowSelected", "filterChanged"],
 *     accepts: ["setFilter", "highlightRow"],
 *     visibility: ["model", "app"],
 *   }),
 * };
 * ```
 */
function uiMeta(options) {
    const ui = { resourceUri: options.resourceUri };
    if (options.visibility !== undefined)
        ui.visibility = options.visibility;
    if (options.csp !== undefined)
        ui.csp = options.csp;
    if (options.permissions !== undefined)
        ui.permissions = options.permissions;
    if (options.domain !== undefined)
        ui.domain = options.domain;
    if (options.prefersBorder !== undefined)
        ui.prefersBorder = options.prefersBorder;
    if (options.emits !== undefined)
        ui.emits = options.emits;
    if (options.accepts !== undefined)
        ui.accepts = options.accepts;
    return { _meta: { ui } };
}
