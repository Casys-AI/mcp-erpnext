/**
 * Browser-side composition of completed Code Mode results.
 * @module
 */
import "../../_dnt.polyfills.js";
import type { ComponentSurface, ViewComponentEventPorts } from "../core/types/components.js";
import type { CompositeUiDescriptor } from "../core/types/descriptor.js";
import type { UiLayout } from "../core/types/layout.js";
import type { UiSyncRule } from "../core/types/sync-rules.js";
import { SNIPPET_SYNC_META_KEY } from "./sync.js";
export { SNIPPET_SYNC_META_KEY };
export { getPanelControlsCss } from "../host/renderer/css/panel-controls.js";
export { isPanelLayoutSnapshot, type PanelLayoutSnapshot } from "./layout.js";
export { capturePanelLayout, installPanelMovement, installPanelResizing, restorePanelLayout, } from "../host/renderer/panel-controls.js";
/** MCP App result metadata containing the receipts selected by the program. */
export declare const SNIPPET_PANELS_META_KEY = "io.mcpview/snippet-panels";
/** A selected provider result. The receipt ID distinguishes calls to the same snippet. */
export interface SnippetPanel {
    readonly id: string;
    readonly provider: string;
    readonly name: string;
    readonly title: string;
    readonly result: Record<string, unknown>;
    readonly events?: ViewComponentEventPorts;
}
/** An App-owned view for a receipt, with optional renderer data and component selection. */
export interface SnippetPanelView {
    readonly resourceUri: string;
    readonly context?: Record<string, unknown>;
    readonly surface?: ComponentSurface;
    /** Widths offered by this local view in CSS pixels. An empty list disables resizing. */
    readonly supportedWidths?: readonly number[];
    /** Restrict routing to the ports implemented by this local view. */
    readonly events?: ViewComponentEventPorts;
}
/** Display options supplied by the board hosting the results. */
export interface SnippetBoardOptions {
    /** A Compose layout or a function of the number of mounted panels. Defaults to stack. */
    readonly layout?: UiLayout | ((count: number) => UiLayout);
    /** Provide a local view adapter or return undefined to use the result's native MCP App URI. */
    readonly resolveView?: (panel: SnippetPanel) => SnippetPanelView | undefined;
}
/**
 * Return selected receipts in display order from the App-only MCP result metadata.
 * Invalid entries and repeated receipt IDs are ignored. Distinct receipts can
 * point to the same snippet and viewer.
 *
 * @example
 * ```ts
 * for (const panel of readSnippetPanels(toolResult)) {
 *   console.log(panel.provider, panel.name, panel.title);
 * }
 * ```
 */
export declare function readSnippetPanels(result: unknown): SnippetPanel[];
/** Read unique, declared Compose routes between panels in this result. */
export declare function readSnippetSyncRules(result: unknown): UiSyncRule[];
/**
 * Build a Compose descriptor from the current execution, without making any provider calls.
 * Each child keeps its receipt in `context.panel` and adapter data in `context.view`.
 * The returned summary is shared as `sharedContext.value` when the execution has a value.
 * A data-only receipt needs a local view adapter to produce a child.
 *
 * @example
 * ```ts
 * const board = composeSnippetBoard(toolResult, {
 *   layout: "split",
 *   resolveView: (panel) => panel.provider === "metrics"
 *     ? { resourceUri: "ui://my-board/metrics" }
 *     : undefined,
 * });
 * ```
 */
export declare function composeSnippetBoard(result: unknown, options?: SnippetBoardOptions): CompositeUiDescriptor;
/**
 * Deliver a JSON event through the current board's declared routes to mounted views.
 * The board owns dispatch and supplies the receipts and data from its active UI.
 */
export declare function emitSnippetBoardEvent(descriptor: CompositeUiDescriptor, sourceReceiptId: string, event: string, data: unknown, deliver: (targetReceiptId: string, action: string, data: unknown) => void): void;
//# sourceMappingURL=board.d.ts.map